﻿using System;
using System.Collections.Generic;
using Tizen;
using Tizen.Applications;
using Tizen.Uix.VoiceControlManager;

[assembly: Xamarin.Forms.Dependency(typeof(VoiceControlPanel.Tizen.PanelControl))]
namespace VoiceControlPanel.Tizen
{
    class PanelControl : IPanelControl
    {
        const string LogTag = "PanelControl";

        private event EventHandler<SetCellTextEventArgs> SetCellText;
        private readonly VoiceCommandsGroup _commandsGroup;

        public PanelControl()
        {
            try
            {
                /* Initialize voice control manager client */
                VoiceControlManagerClient.Initialize();

                /* Set event handler for voice control manager client */
                VoiceControlManagerClient.StateChanged += StateChangedEvent;
                VoiceControlManagerClient.ServiceStateChanged += ServiceStateChangedEvent;
                VoiceControlManagerClient.ErrorOccurred += ErrorOccurredEvent;
                VoiceControlManagerClient.CurrentLanguageChanged += CurrentLanguageChangedEvent;
                VoiceControlManagerClient.PreRecognitionResultUpdated += PreRecognitionResultUpdatedEvent;
                VoiceControlManagerClient.RecognitionResultUpdated += RecognitionResultUpdatedEvent;
                VoiceControlManagerClient.AllRecognitionResultReceived += AllRecognitionResultReceivedEvent;

                VoiceControlManagerClient.SetRecognizedCommandsSelectionDelegate(SelectRecognizedCommandsDelegate);

                /* Prepare voice control manager client to start voice control service */
                VoiceControlManagerClient.Prepare();

                _commandsGroup = CreateCommandGroup();
            }
            catch (Exception e)
            {
                Log.Error(LogTag, string.Format("Exception is occurred. exception({0})", e));
            }
        }

        ~PanelControl()
        {
            try
            {
                if (VoiceControlManagerClient.ServiceState != ServiceState.Ready)
                {
                    VoiceControlManagerClient.Stop();
                }

                VoiceControlManagerClient.ClearCommands();

                /* Unprepare voice control manager client to end of voice control service */
                VoiceControlManagerClient.Unprepare();

                /* Unset event handler */
                VoiceControlManagerClient.StateChanged -= StateChangedEvent;
                VoiceControlManagerClient.ServiceStateChanged -= ServiceStateChangedEvent;
                VoiceControlManagerClient.ErrorOccurred -= ErrorOccurredEvent;
                VoiceControlManagerClient.CurrentLanguageChanged -= CurrentLanguageChangedEvent;
                VoiceControlManagerClient.PreRecognitionResultUpdated -= PreRecognitionResultUpdatedEvent;
                VoiceControlManagerClient.RecognitionResultUpdated -= RecognitionResultUpdatedEvent;
                VoiceControlManagerClient.AllRecognitionResultReceived -= AllRecognitionResultReceivedEvent;
            }
            catch (Exception e)
            {
                Log.Error(LogTag, string.Format("Fail to unprepare. exception({0})", e));
            }
            finally
            {
                _commandsGroup.Dispose();
                /* Deinitialize voice control manager client */
                VoiceControlManagerClient.Deinitialize();
            }
        }

        /* Public method implementation */
        public void StartRecording()
        {
            SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.RECOGNITION_RESULT, ""));
            SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.COMMAND_TEXT, ""));
            SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.ERROR_MESSAGE, ""));

            try
            {
                //VoiceControlManagerClient.SetCommands(_commandsGroup);
                ApplicationInfo info = new ApplicationInfo("org.tizen.example.VoiceControlPanel.Tizen");
                VoiceControlManagerClient.SetCommandsFromFile(info.SharedResourcePath + "command.json", CommandType.System);
                VoiceControlManagerClient.Start(false);
            }
            catch (Exception e)
            {
                Log.Error(LogTag, string.Format("Fail to start recording. exception({0})", e));
                SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.ERROR_MESSAGE, e.ToString()));
            }
        }

        public void StopRecording()
        {
            try
            {
                VoiceControlManagerClient.Stop();
            }
            catch (Exception e)
            {
                Log.Error(LogTag, string.Format("Fail to stop recording. exception({0})", e));
                SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.ERROR_MESSAGE, e.ToString()));
            }
        }

        /* Private method implementation */
        private VoiceCommandsGroup CreateCommandGroup()
        {
            try
            {
                // Create command group
                VoiceCommandsGroup commandsGroup = new VoiceCommandsGroup();

                // Create commands
                commandsGroup.Commands.Add(new VoiceCommand
                {
                    Command = "안녕하세요",
                    CommandType = CommandType.System,
                    Format = CommandFormat.Fixed
                });

                commandsGroup.Commands.Add(new VoiceCommand
                {
                    Command = "시작해줘",
                    CommandType = CommandType.System,
                    Format = CommandFormat.Fixed
                });

                return commandsGroup;
            }
            catch (Exception e)
            {
                Log.Error(LogTag, String.Format("Exception is occurred. exception({0})", e));
                throw e;
            }
        }

        private string CorrectRecognizedText(string recognizedText)
        {
            List<string> helloCandidates = new List<string> { "안녕하세", "안녕하", "안녕" };
            List<string> startCandidates = new List<string> { "시작해조", "시작해", "시작" };

            foreach (var item in helloCandidates)
            {
                if (item == recognizedText)
                {
                    return "안녕하세요";
                }
            }

            foreach (var item in startCandidates)
            {
                if (item == recognizedText)
                {
                    return "시작해줘";
                }
            }

            return null;
        }

        /* Implement events for VoiceControlManagerClient */
        public event EventHandler<SetCellTextEventArgs> SetCellTextEvent
        {
            add
            {
                SetCellText += value;

                // Set initial value for each cell
                SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.MANAGER_STATE, VoiceControlManagerClient.State.ToString()));
                SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.SERVICE_STATE, VoiceControlManagerClient.ServiceState.ToString()));
                SetCellText?.Invoke(this, new SetCellTextEventArgs(TextType.CURRENT_LANGUAGE, VoiceControlManagerClient.CurrentLanguage));
            }

            remove
            {
                SetCellText -= value;
            }
        }

        private void ServiceStateChangedEvent(object sender, ServiceStateChangedEventArgs e)
        {
            // This Event is occurred when the state of server is changed
            Log.Debug(LogTag, string.Format("Service state is changed from ({0}) to ({1})", e.Previous, e.Current));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.SERVICE_STATE, e.Current.ToString()));
        }

        private void StateChangedEvent(object sender, StateChangedEventArgs e)
        {
            // This Event is occurred when the state of manager is changed
            Log.Debug(LogTag, string.Format("Manager state is changed from ({0}) to ({1})", e.Previous, e.Current));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.MANAGER_STATE, e.Current.ToString()));
        }

        private void CurrentLanguageChangedEvent(object sender, CurrentLanguageChangedEventArgs e)
        {
            // This Event is occurred when current language is changed
            Log.Debug(LogTag, string.Format("Current langauge({0})", e.CurrentLanguage));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.CURRENT_LANGUAGE, e.CurrentLanguage));
        }

        private void PreRecognitionResultUpdatedEvent(object sender, PreRecognitionResultUpdatedEventArgs e)
        {
            // This Event is occurred when recognized text is updated
            Log.Debug(LogTag, string.Format("Current recognition result({0})", e.Result));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.RECOGNITION_RESULT, e.Result));
        }

        private void AllRecognitionResultReceivedEvent(object sender, AllRecognitionResultEventArgs e)
        {
            // This Event is occurred when recognition is complete
            Log.Debug(LogTag, string.Format("All recognition result({0})", e.RecognizedText));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.RECOGNITION_RESULT, e.RecognizedText));

            string commandText = e.RecognizedText;

            if (RecognizedResult.Rejected == e.Result)
            {
                // Handle rejected recognition result
                Log.Warn(LogTag, string.Format("Recognition rejected. recognized text({0})", e.RecognizedText));
                commandText = CorrectRecognizedText(e.RecognizedText);

                if (null == commandText)
                {
                    Log.Error(LogTag, string.Format("Recognition rejected. recognized text({0})", e.RecognizedText));
                    return;
                }
            }

            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.COMMAND_TEXT, commandText));
        }

        private void RecognitionResultUpdatedEvent(object sender, RecognitionResultUpdatedEventArgs e)
        {
            // This Event is occurred when manager receives the final recognition result
            Log.Debug(LogTag, string.Format("Final recognition result({0})", e.RecognizedText));
        }

        private void ErrorOccurredEvent(object sender, ErrorOccurredEventArgs e)
        {
            // This Event is occurred when error is generated from server
            Log.Error(LogTag, string.Format("Error is occurred. exception({0})", e.Why));
            SetCellText?.Invoke(sender, new SetCellTextEventArgs(TextType.ERROR_MESSAGE, e.Why.ToString()));
        }

        public IEnumerable<VoiceCommand> SelectRecognizedCommandsDelegate(IEnumerable<VoiceCommand> commands, string recognizedText, string message)
        {
            Log.Debug(LogTag, string.Format("Select commands from the result. ({0}) ({1})", recognizedText, message));
            var newCommands = new List<VoiceCommand>();

            IEnumerator<VoiceCommand> enumerator = commands.GetEnumerator();
            VoiceCommand command = null;
            if (enumerator.MoveNext())
            {
                command = enumerator.Current;
            }

            if (null != command)
            {
                newCommands.Add(command);
            }

            return newCommands;
        }
    }
}
