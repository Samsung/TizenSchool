﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoiceControlPanel
{
    public enum TextType
    {
        MANAGER_STATE,
        SERVICE_STATE,
        CURRENT_LANGUAGE,
        ERROR_MESSAGE,
        RECOGNITION_RESULT,
        COMMAND_TEXT
    }

    public class SetCellTextEventArgs
    {
        public SetCellTextEventArgs(TextType type, string text)
        {
            Type = type;
            Text = text;
        }

        public TextType Type { get; }
        public string Text { get; }
    }
}
