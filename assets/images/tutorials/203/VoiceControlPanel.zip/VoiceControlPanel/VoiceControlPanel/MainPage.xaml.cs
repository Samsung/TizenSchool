﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace VoiceControlPanel
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : ContentPage
    {
        private readonly IPanelControl _panelControl;

        private readonly Label _managerStateCell;
        private readonly Label _serviceStateCell;
        private readonly Label _currentLanguageCell;
        private readonly Label _errorMessageCell;
        private readonly Label _recognizedTextCell;
        private readonly Label _commandTextCell;

        public MainPage()
        {
            InitializeComponent();

            _managerStateCell = this.FindByName<Label>("ManagerStateCell");
            _serviceStateCell = this.FindByName<Label>("ServiceStateCell");
            _currentLanguageCell = this.FindByName<Label>("CurrentLanguageCell");
            _errorMessageCell = this.FindByName<Label>("ErrorMessageCell");
            _recognizedTextCell = this.FindByName<Label>("RecognizedTextCell");
            _commandTextCell = this.FindByName<Label>("CommandTextCell");

            _panelControl = DependencyService.Get<IPanelControl>();
            _panelControl.SetCellTextEvent += SetCellTextEvent;
        }

        private void SetCellTextEvent(object sender, SetCellTextEventArgs data)
        {
            try
            {
                switch (data.Type)
                {
                    case TextType.MANAGER_STATE:
                        _managerStateCell.Text = data.Text;
                        break;
                    case TextType.SERVICE_STATE:
                        _serviceStateCell.Text = data.Text;
                        break;
                    case TextType.CURRENT_LANGUAGE:
                        _currentLanguageCell.Text = data.Text;
                        break;
                    case TextType.ERROR_MESSAGE:
                        _errorMessageCell.Text = data.Text;
                        break;
                    case TextType.RECOGNITION_RESULT:
                        _recognizedTextCell.Text = data.Text;
                        break;
                    case TextType.COMMAND_TEXT:
                        _commandTextCell.Text = data.Text;
                        break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                if (_errorMessageCell != null)
                {
                    _errorMessageCell.Text = e.ToString();
                }
            }
        }

        private void Start_Clicked(object sender, EventArgs e)
        {
            _panelControl.StartRecording();
        }

        private void Stop_Clicked(object sender, EventArgs e)
        {
            _panelControl.StopRecording();
        }
    }
}