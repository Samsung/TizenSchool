﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoiceControlPanel
{
    public interface IPanelControl
    {
        void StartRecording();
        void StopRecording();

        event EventHandler<SetCellTextEventArgs> SetCellTextEvent;
    }
}
