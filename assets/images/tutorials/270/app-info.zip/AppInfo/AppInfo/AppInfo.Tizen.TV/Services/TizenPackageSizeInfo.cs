﻿using AppInfo.Models;
using Tizen.Applications;

namespace AppInfo.Tizen.TV.Services
{
    /// <summary>
    /// TizenPackageSizeInfo class.
    /// Defines properties describing package size provided by the Tizen Applications API.
    /// </summary>
    class TizenPackageSizeInfo : IPackageSizeInfo
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// DataSize property.
        /// </summary>
        public long DataSize => throw new System.NotImplementedException();

        /// <summary>
        /// CacheSize property.
        /// </summary>
        public long CacheSize => throw new System.NotImplementedException();

        /// <summary>
        /// AppSize property.
        /// </summary>
        public long AppSize => throw new System.NotImplementedException();

        /// <summary>
        /// ExternalDataSize property.
        /// </summary>
        public long ExternalDataSize => throw new System.NotImplementedException();

        /// <summary>
        /// ExternalCacheSize property.
        /// </summary>
        public long ExternalCacheSize => throw new System.NotImplementedException();

        /// <summary>
        /// ExternalAppSize property.
        /// </summary>
        public long ExternalAppSize => throw new System.NotImplementedException();

        #endregion

        #region methods

        /// <summary>
        /// TizenPackageSizeInfo class constructor.
        /// </summary>
        /// <param name="source">An instance of the PackageSizeInformation class.</param>
        internal TizenPackageSizeInfo(PackageSizeInformation source)
        {

        }

        #endregion
    }
}