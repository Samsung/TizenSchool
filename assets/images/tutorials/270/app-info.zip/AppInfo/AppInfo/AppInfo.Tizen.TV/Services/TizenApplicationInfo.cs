﻿using AppInfo.Models;
using Tizen.Applications;
using System.Collections.Generic;

namespace AppInfo.Tizen.TV.Services
{
    /// <summary>
    /// TizenApplicationInfo class.
    /// Defines properties describing application provided by the Tizen Applications API.
    /// </summary>
    class TizenApplicationInfo : IApplication
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// ApplicationId property.
        /// </summary>
        public string ApplicationId => throw new System.NotImplementedException();

        /// <summary>
        /// PackageId property.
        /// </summary>
        public string PackageId => throw new System.NotImplementedException();

        /// <summary>
        /// Label property.
        /// </summary>
        public string Label => throw new System.NotImplementedException();

        /// <summary>
        /// ExecutablePath property.
        /// </summary>
        public string ExecutablePath => throw new System.NotImplementedException();

        /// <summary>
        /// IconPath property.
        /// </summary>
        public string IconPath => throw new System.NotImplementedException();

        /// <summary>
        /// ApplicationType property.
        /// </summary>
        public string ApplicationType => throw new System.NotImplementedException();

        /// <summary>
        /// Metadata property.
        /// </summary>
        public IDictionary<string, string> Metadata => throw new System.NotImplementedException();

        /// <summary>
        /// IsNoDisplay property.
        /// </summary>
        public bool IsNoDisplay => throw new System.NotImplementedException();

        /// <summary>
        /// IsOnBoot property.
        /// </summary>
        public bool IsOnBoot => throw new System.NotImplementedException();

        /// <summary>
        /// IsPreload property.
        /// </summary>
        public bool IsPreload => throw new System.NotImplementedException();

        /// <summary>
        /// SharedDataPath property.
        /// </summary>
        public string SharedDataPath => throw new System.NotImplementedException();

        /// <summary>
        /// SharedResourcePath property.
        /// </summary>
        public string SharedResourcePath => throw new System.NotImplementedException();

        /// <summary>
        /// SharedTrustedPath property.
        /// </summary>
        public string SharedTrustedPath => throw new System.NotImplementedException();

        /// <summary>
        /// ExternalSharedDataPath property.
        /// </summary>
        public string ExternalSharedDataPath => throw new System.NotImplementedException();

        #endregion

        #region methods

        /// <summary>
        /// TizenApplicationInfo class constructor.
        /// </summary>
        /// <param name="source">An instance of the ApplicationInfo class.</param>
        internal TizenApplicationInfo(ApplicationInfo source)
        {

        }

        #endregion
    }
}