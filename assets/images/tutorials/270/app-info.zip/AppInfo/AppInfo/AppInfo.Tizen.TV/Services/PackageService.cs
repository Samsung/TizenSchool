﻿using System.Threading.Tasks;
using AppInfo.Models;
using AppInfo.Tizen.TV.Services;
using Tizen.Applications;

[assembly: Xamarin.Forms.Dependency(typeof(PackageService))]
namespace AppInfo.Tizen.TV.Services
{
    /// <summary>
    /// PackageService class.
    /// </summary>
    class PackageService : IPackageService
    {
        #region methods

        /// <summary>
        /// Returns information about installed package based on its id.
        /// </summary>
        /// <param name="packageId">Package id.</param>
        /// <returns>An instance of the IPackage class.</returns>
        public IPackage GetPackage(string packageId)
        {
            return null;
        }

        /// <summary>
        /// Returns an object describing package size
        /// based on the corresponding instance of IApplication class.
        /// </summary>
        /// <param name="application">An instance of IApplication class.</param>
        /// <returns>List of instances of the IPackageSizeInfo class.</returns>
        public async Task<IPackageSizeInfo> GetPackageSizeInfo(IApplication application)
        {
            return null;
        }

        #endregion
    }
}