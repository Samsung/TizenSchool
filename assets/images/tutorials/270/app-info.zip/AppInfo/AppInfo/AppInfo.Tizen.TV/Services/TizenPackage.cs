﻿using AppInfo.Models;
using Tizen.Applications;

namespace AppInfo.Tizen.TV.Services
{
    /// <summary>
    /// TizenPackage class.
    /// Defines properties describing package provided by the Tizen Applications API.
    /// </summary>
    class TizenPackage : IPackage
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// PackageId property.
        /// </summary>
        public string PackageId => throw new System.NotImplementedException();

        /// <summary>
        /// Label property.
        /// </summary>
        public string Label => throw new System.NotImplementedException();

        /// <summary>
        /// IconPath property.
        /// </summary>
        public string IconPath => throw new System.NotImplementedException();

        /// <summary>
        /// Version property.
        /// </summary>
        public string Version => throw new System.NotImplementedException();

        /// <summary>
        /// PackageType property.
        /// </summary>
        public string PackageType => throw new System.NotImplementedException();

        /// <summary>
        /// InstalledStorageType property.
        /// </summary>
        public string InstalledStorageType => throw new System.NotImplementedException();

        /// <summary>
        /// RootPath property.
        /// </summary>
        public string RootPath => throw new System.NotImplementedException();

        /// <summary>
        /// TizenExpansionPackageName property.
        /// </summary>
        public string TizenExpansionPackageName => throw new System.NotImplementedException();

        /// <summary>
        /// IsSystemPackage property.
        /// </summary>
        public bool IsSystemPackage => throw new System.NotImplementedException();

        /// <summary>
        /// IsRemovable property.
        /// </summary>
        public bool IsRemovable => throw new System.NotImplementedException();

        /// <summary>
        /// IsPreloaded property.
        /// </summary>
        public bool IsPreloaded => throw new System.NotImplementedException();

        /// <summary>
        /// IsAccessible property.
        /// </summary>
        public bool IsAccessible => throw new System.NotImplementedException();

        #endregion

        #region methods

        /// <summary>
        /// TizenPackage class constructor.
        /// </summary>
        /// <param name="source">An instance of the Package class.</param>
        internal TizenPackage(Package source)
        {

        }

        #endregion
    }
}