﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AppInfo.Models;
using AppInfo.Tizen.TV.Services;
using Tizen.Applications;

[assembly: Xamarin.Forms.Dependency(typeof(ApplicationService))]
namespace AppInfo.Tizen.TV.Services
{
    /// <summary>
    /// ApplicationService class.
    /// </summary>
    class ApplicationService : IApplicationService
    {
        #region methods

        /// <summary>
        /// Returns list of installed apps provided by the Tizen Applications API.
        /// </summary>
        /// <returns>List of installed apps.</returns>
        public async Task<IEnumerable<IApplication>> GetApps()
        {
            return null;
        }

        #endregion
    }
}