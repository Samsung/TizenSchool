﻿using System.Collections.Generic;

namespace AppInfo.Models
{
    /// <summary>
    /// IApplication interface class.
    /// Defines properties describing application,
    /// provided by the Tizen Applications API.
    /// </summary>
    public interface IApplication
    {
        #region properties

        /// <summary>
        /// ApplicationId property.
        /// </summary>
        string ApplicationId { get; }

        /// <summary>
        /// PackageId property.
        /// </summary>
        string PackageId { get; }

        /// <summary>
        /// Label property.
        /// </summary>
        string Label { get; }

        /// <summary>
        /// ExecutablePath property.
        /// </summary>
        string ExecutablePath { get; }

        /// <summary>
        /// IconPath property.
        /// </summary>
        string IconPath { get; }

        /// <summary>
        /// ApplicationType property.
        /// </summary>
        string ApplicationType { get; }

        /// <summary>
        /// Metadata property.
        /// </summary>
        IDictionary<string, string> Metadata { get; }

        /// <summary>
        /// IsNoDisplay property.
        /// </summary>
        bool IsNoDisplay { get; }

        /// <summary>
        /// IsOnBoot property.
        /// </summary>
        bool IsOnBoot { get; }

        /// <summary>
        /// IsPreload property.
        /// </summary>
        bool IsPreload { get; }

        /// <summary>
        /// SharedDataPath property.
        /// </summary>
        string SharedDataPath { get; }

        /// <summary>
        /// SharedResourcePath property.
        /// </summary>
        string SharedResourcePath { get; }

        /// <summary>
        /// SharedTrustedPath property.
        /// </summary>
        string SharedTrustedPath { get; }

        /// <summary>
        /// ExternalSharedDataPath property.
        /// </summary>
        string ExternalSharedDataPath { get; }

        #endregion
    }
}