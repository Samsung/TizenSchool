﻿using System.Collections.Generic;
using AppInfo.Models;
using System.Linq;

namespace AppInfo.ViewModels
{
    /// <summary>
    /// MainViewModel class.
    /// Provides commands and methods responsible for application view model state.
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region fields

        #endregion

        #region properties

        #endregion

        #region methods

        /// <summary>
        /// MainViewModel class constructor.
        /// Initializes all necessary data models.
        /// Executes GetListOfApps method.
        /// </summary>
        public MainViewModel()
        {

        }

        #endregion
    }
}