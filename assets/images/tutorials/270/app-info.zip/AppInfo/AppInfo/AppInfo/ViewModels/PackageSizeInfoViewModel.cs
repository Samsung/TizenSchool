﻿using AppInfo.Models;

namespace AppInfo.ViewModels
{
    /// <summary>
    /// PackageSizeInfoViewModel class.
    /// Provides properties describing package size provided by the Tizen Applications API.
    /// </summary>
    public class PackageSizeInfoViewModel
    {
        #region properties

        #endregion

        #region methods

        /// <summary>
        /// PackageSizeInfoViewModel class constructor.
        /// </summary>
        /// <param name="packageSizeInfo">An instance of the IPackageSizeInfo class.</param>
        public PackageSizeInfoViewModel(IPackageSizeInfo packageSizeInfo)
        {

        }

        #endregion
    }
}