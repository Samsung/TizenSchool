﻿namespace AppInfo.Models
{
    /// <summary>
    /// IPackageSizeInfo interface class.
    /// Defines properties describing package size,
    /// provided by the Tizen Applications API.
    /// </summary>
    public interface IPackageSizeInfo
    {
        #region properties

        /// <summary>
        /// DataSize property.
        /// </summary>
        long DataSize { get; }

        /// <summary>
        /// CacheSize property.
        /// </summary>
        long CacheSize { get; }

        /// <summary>
        /// AppSize property.
        /// </summary>
        long AppSize { get; }

        /// <summary>
        /// ExternalDataSize property.
        /// </summary>
        long ExternalDataSize { get; }

        /// <summary>
        /// ExternalCacheSize property.
        /// </summary>
        long ExternalCacheSize { get; }

        /// <summary>
        /// ExternalAppSize property.
        /// </summary>
        long ExternalAppSize { get; }

        #endregion
    }
}