﻿namespace AppInfo.Models
{
    /// <summary>
    /// IPackage interface class.
    /// Defines properties describing package,
    /// provided by the Tizen Applications API.
    /// </summary>
    public interface IPackage
    {
        #region properties

        /// <summary>
        /// PackageId property.
        /// </summary>
        string PackageId { get; }

        /// <summary>
        /// Label property.
        /// </summary>
        string Label { get; }

        /// <summary>
        /// IconPath property.
        /// </summary>
        string IconPath { get; }

        /// <summary>
        /// Version property.
        /// </summary>
        string Version { get; }

        /// <summary>
        /// PackageType property.
        /// </summary>
        string PackageType { get; }

        /// <summary>
        /// InstalledStorageType property.
        /// </summary>
        string InstalledStorageType { get; }

        /// <summary>
        /// RootPath property.
        /// </summary>
        string RootPath { get; }

        /// <summary>
        /// TizenExpansionPackageName property.
        /// </summary>
        string TizenExpansionPackageName { get; }

        /// <summary>
        /// IsSystemPackage property.
        /// </summary>
        bool IsSystemPackage { get; }

        /// <summary>
        /// IsRemovable property.
        /// </summary>
        bool IsRemovable { get; }

        /// <summary>
        /// IsPreloaded property.
        /// </summary>
        bool IsPreloaded { get; }

        /// <summary>
        /// IsAccessible property.
        /// </summary>
        bool IsAccessible { get; }

        #endregion
    }
}