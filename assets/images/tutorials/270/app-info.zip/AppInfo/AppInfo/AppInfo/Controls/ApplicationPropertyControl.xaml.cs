﻿using Xamarin.Forms;

namespace AppInfo.Controls
{
    /// <summary>
    /// ApplicationPropertyControl class.
    /// Provides logic for the ApplicationPropertyControl.
    /// </summary>
    public partial class ApplicationPropertyControl : ContentView
    {
        #region fields

        #endregion

        #region properties

        #endregion

        #region methods

        /// <summary>
        /// ApplicationPropertyControl class constructor.
        /// </summary>
        public ApplicationPropertyControl()
        {
            InitializeComponent();
        }

        #endregion
    }
}