﻿using Xamarin.Forms;

namespace AppInfo.Views
{
    /// <summary>
    /// MainPage class.
    /// Provides logic for UI MainPage.
    /// </summary>
    public partial class MainPage : ContentPage
    {
        #region methods

        /// <summary>
        /// MainPage class constructor.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}