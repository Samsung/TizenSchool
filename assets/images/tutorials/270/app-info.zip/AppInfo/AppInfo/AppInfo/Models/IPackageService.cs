﻿using System.Threading.Tasks;

namespace AppInfo.Models
{
    /// <summary>
    /// IPackageService interface class.
    /// Defines methods that should be implemented by class
    /// that has access to detailed information about installed packages,
    /// provided by the Tizen Applications API.
    /// </summary>
    public interface IPackageService
    {
        #region methods

        /// <summary>
        /// Returns information about installed package based on its id.
        /// </summary>
        /// <param name="packageId">Package id.</param>
        /// <returns>An instance of the IPackage class.</returns>
        IPackage GetPackage(string packageId);

        /// <summary>
        /// Returns an object describing package size
        /// based on the corresponding instance of IApplication class.
        /// </summary>
        /// <param name="application">An instance of IApplication class.</param>
        /// <returns>List of instances of the IPackageSizeInfo class.</returns>
        Task<IPackageSizeInfo> GetPackageSizeInfo(IApplication application);

        #endregion
    }
}