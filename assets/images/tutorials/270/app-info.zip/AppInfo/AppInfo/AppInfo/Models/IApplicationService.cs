﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppInfo.Models
{
    /// <summary>
    /// IApplicationService interface class.
    /// Defines methods that should be implemented by class
    /// that has access to detailed information about installed applications,
    /// provided by the Tizen Applications API.
    /// </summary>
    public interface IApplicationService
    {
        #region methods

        /// <summary>
        /// Returns list of installed apps provided by the Tizen Applications API.
        /// </summary>
        /// <returns>List of installed apps.</returns>
        Task<IEnumerable<IApplication>> GetApps();

        #endregion
    }
}