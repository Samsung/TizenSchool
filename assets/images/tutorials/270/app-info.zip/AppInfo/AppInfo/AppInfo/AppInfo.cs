using AppInfo.Views;
using Xamarin.Forms;

namespace AppInfo
{
    /// <summary>
    /// Portable application part main class.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// App class constructor.
        /// Creates the application's main page.
        /// </summary>
        public App()
        {
            MainPage = new NavigationPage(new MainPage());
        }

        #endregion
    }
}