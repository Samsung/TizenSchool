﻿using AppInfo.Models;

namespace AppInfo.ViewModels
{
    /// <summary>
    /// PackageViewModel class.
    /// Provides properties describing package provided by the Tizen Applications API.
    /// </summary>
    public class PackageViewModel
    {
        #region properties

        #endregion

        #region methods

        /// <summary>
        /// PackageViewModel class constructor.
        /// </summary>
        /// <param name="package">An instance of the IPackage class.</param>
        public PackageViewModel(IPackage package)
        {

        }

        #endregion
    }
}