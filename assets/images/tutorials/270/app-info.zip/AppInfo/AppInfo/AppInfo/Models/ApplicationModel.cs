﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AppInfo.Models
{
    /// <summary>
    /// ApplicationModel class.
    /// Defines methods that allow the application to access
    /// detailed information about installed applications,
    /// provided by the Tizen Applications API.
    /// </summary>
    public class ApplicationModel
    {
        #region methods

        /// <summary>
        /// Returns list of installed apps provided by the Tizen Applications API.
        /// </summary>
        /// <returns>List of installed apps.</returns>
        public async Task<IEnumerable<IApplication>> GetApps()
        {
            return await DependencyService.Get<IApplicationService>().GetApps();
        }

        #endregion
    }
}