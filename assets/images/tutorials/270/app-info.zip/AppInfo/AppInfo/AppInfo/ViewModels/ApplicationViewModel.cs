﻿using System.Collections.Generic;
using AppInfo.Models;

namespace AppInfo.ViewModels
{
    /// <summary>
    /// ApplicationViewModel class.
    /// Provides properties describing application provided by the Tizen Applications API.
    /// </summary>
    public class ApplicationViewModel
    {
        #region fields

        #endregion

        #region properties

        #endregion

        #region methods

        /// <summary>
        /// ApplicationViewModel class constructor.
        /// Initializes all necessary data models.
        /// </summary>
        /// <param name="app">An instance of the IApplication class.</param>
        public ApplicationViewModel(IApplication app)
        {

        }

        #endregion
    }
}