﻿namespace Geocoding.ViewModels
{
    /// <summary>
    /// Provides methods to use the information popup service.
    /// </summary>
    public interface IInformationPopupService
    {
        #region properties

        /// <summary>
        /// Gets or sets text displayed on the no results popup.
        /// </summary>
        string NoResultsPopupText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the no results popup button.
        /// </summary>
        string NoResultsPopupButtonText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the connection failed popup.
        /// </summary>
        string ConnectionFailedPopupText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the connection failed popup button.
        /// </summary>
        string ConnectionFailedPopupButtonText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the "Find more markers" popup.
        /// </summary>
        string FindMoreMarkersPopupText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the "Find more markers" popup button.
        /// </summary>
        string FindMoreMarkersPopupButtonText { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Dismisses the popup.
        /// </summary>
        void Dismiss();

        /// <summary>
        /// Shows no results popup.
        /// </summary>
        void ShowNoResultsPopup();

        /// <summary>
        /// Shows connection failed popup.
        /// </summary>
        void ShowConnectionFailedPopup();

        /// <summary>
        /// Shows "Find more markers" popup.
        /// </summary>
        void ShowFindMoreMarkersPopup();

        #endregion
    }
}
