﻿namespace Geocoding.ViewModels
{
    /// <summary>
    /// IGeocodingCoordinatesArgs interface.
    /// It defines methods that must be implemented by class used to notifying about geocoding coordinates.
    /// </summary>
    public interface IGeocodingCoordinatesArgs
    {
        #region properties

        /// <summary>
        /// Latitude value.
        /// </summary>
        double Latitude { get; }

        /// <summary>
        /// Longitude value.
        /// </summary>
        double Longitude { get; }

        #endregion
    }
}
