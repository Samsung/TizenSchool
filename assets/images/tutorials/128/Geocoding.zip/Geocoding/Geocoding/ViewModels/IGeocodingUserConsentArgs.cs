﻿namespace Geocoding.ViewModels
{
    /// <summary>
    /// IGeocodingUserConsentArgs interface.
    /// Defines properties that must be implemented by class used to notifying about the user consent status.
    /// </summary>
    public interface IGeocodingUserConsentArgs
    {
        #region properties

        /// <summary>
        /// Consent status value.
        /// </summary>
        bool IsConsent { get; }

        #endregion
    }
}
