﻿using System;

namespace Geocoding.ViewModels
{
    /// <summary>
    /// IGeocodingService interface class.
    /// It defines methods that should be implemented by class used to providing geocoding functionality.
    /// </summary>
    public interface IGeocodingService
    {
        #region properties

        /// <summary>
        /// Notifies about user consent.
        /// </summary>
        event EventHandler<IGeocodingUserConsentArgs> UserConsent;

        /// <summary>
        /// Notifies about geocode request success.
        /// </summary>
        event EventHandler GeocodeRequestSuccess;

        /// <summary>
        /// Notifies about lack of results of the geocode request.
        /// </summary>
        event EventHandler GeocodeRequestNotFound;

        /// <summary>
        /// Notifies about lack of connection to the map provider during the geocode request.
        /// </summary>
        event EventHandler GeocodeRequestConnectionFailed;

        /// <summary>
        /// Notifies about received coordinates.
        /// </summary>
        event EventHandler<IGeocodingCoordinatesArgs> CoordinatesReceived;

        /// <summary>
        /// Notifies about center point coordinates.
        /// </summary>
        event EventHandler<IGeocodingCoordinatesArgs> CenterPointCalculated;

        #endregion

        #region methods

        /// <summary>
        /// Parses data provided with the last geocoding request.
        /// </summary>
        void ParseLastGeocodeResponse();

        /// <summary>
        /// Requests user's consent to the map provider's license terms.
        /// </summary>
        void RequestUserConsent();

        /// <summary>
        /// Creates request to translate given address to its geographical location.
        /// </summary>
        /// <param name="address">Address value.</param>
        void CreateGeocodeRequestMethod(string address);

        #endregion
    }
}
