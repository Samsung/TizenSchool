﻿namespace Geocoding
{
    /// <summary>
    /// Provides application settings.
    /// </summary>
    public static class Config
    {
        #region fields

        /// <summary>
        /// Map provider's name.
        /// </summary>
        private const string _PROVIDER_NAME = "HERE";

        /// <summary>
        /// ID registered with provider.
        /// Please visit http://developer.here.com to obtain application id.
        /// </summary>
        private const string _APP_ID = "";

        /// <summary>
        /// Key assigned with application ID.
        /// Please visit http://developer.here.com to obtain application key.
        /// </summary>
        private const string _APP_KEY = "";

        #endregion

        #region properties

        /// <summary>
        /// Provider name.
        /// </summary>
        public static string ProviderName => _PROVIDER_NAME;

        /// <summary>
        /// Authentication token used to initialize map library.
        /// </summary>
        public static string AuthenticationToken => _APP_ID + "/" + _APP_KEY;

        #endregion
    }
}
