﻿namespace Geocoding.Views
{
    /// <summary>
    /// Provides methods which allow to navigate between pages.
    /// </summary>
    public interface IPageNavigation
    {
        #region methods

        /// <summary>
        /// Creates welcome page and sets it as active.
        /// </summary>
        void CreateWelcomePage();

        /// <summary>
        /// Creates range selection page and sets it as active.
        /// </summary>
        void CreateSearchPage();

        /// <summary>
        /// Creates map page and sets it as active.
        /// </summary>
        void CreateMapPage();

        /// <summary>
        /// Closes the application.
        /// </summary>
        void Close();

        #endregion
    }
}
