﻿using System;
using Geocoding.Tizen.Wearable.Controls;
using Geocoding.Tizen.Wearable.Renderers;
using Tizen.Maps;
using Xamarin.Forms.Platform.Tizen;

[assembly: ExportRenderer(typeof(TizenMapView), typeof(TizenMapViewRenderer))]
namespace Geocoding.Tizen.Wearable.Renderers
{
    /// <summary>
    /// Tizen map view renderer.
    /// </summary>
    public class TizenMapViewRenderer : ViewRenderer<TizenMapView, MapView>
    {
        #region fields

        /// <summary>
        /// MapView class instance used for interacting with the map view.
        /// </summary>
        MapView _mapView;

        #endregion

        #region methods

        /// <summary>
        /// Overridden OnElementChanged method which initializes new control as a Tizen map view.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnElementChanged(ElementChangedEventArgs<TizenMapView> e)
        {
        }

        /// <summary>
        /// Handles "ViewReady" event of the MapView class.
        /// </summary>
        /// <param name="sender">Object firing the event.</param>
        /// <param name="e">Event arguments.</param>
        private void OnViewReady(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
