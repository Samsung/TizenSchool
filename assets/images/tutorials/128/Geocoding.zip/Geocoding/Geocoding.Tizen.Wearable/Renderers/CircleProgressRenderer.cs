﻿using ElmSharp;
using Geocoding.Tizen.Wearable.Controls;
using Geocoding.Tizen.Wearable.Renderers;
using Xamarin.Forms.Platform.Tizen;
using EProgressBar = ElmSharp.ProgressBar;
using TForms = Xamarin.Forms.Platform.Tizen.Forms;

[assembly: ExportRenderer(typeof(CircleProgress), typeof(CircleProgressRenderer))]
namespace Geocoding.Tizen.Wearable.Renderers
{
    /// <summary>
    /// Circle progress renderer.
    /// </summary>
    public class CircleProgressRenderer : ViewRenderer<CircleProgress, EProgressBar>
    {
        #region methods

        /// <summary>
        /// Overridden OnElementChanged method for initializing new control.
        /// </summary>
        /// <param name="e">Event argument.</param>
        protected override void OnElementChanged(ElementChangedEventArgs<CircleProgress> e)
        {
            if (Control == null)
            {
                var progressBar = new EProgressBar(TForms.NativeParent);
                SetNativeControl(progressBar);
            }

            if (e.NewElement != null)
            {
                Control.Style = "process/popup/small";
                Control.Color = Color.FromHex("#197847");
                Control.Show();
                Control.PlayPulse();
            }

            base.OnElementChanged(e);
        }

        #endregion
    }
}
