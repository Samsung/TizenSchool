﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using ElmSharp.Wearable;
using Geocoding.Tizen.Wearable.Controls;
using Geocoding.Tizen.Wearable.Services;
using Geocoding.ViewModels;
using Tizen.Maps;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Tizen;
using Xamarin.Forms.Xaml;

namespace Geocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Map page.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MapPage : CirclePage
    {
        #region fields

        /// <summary>
        /// Geocoding service interface used to manage geolocation data provided by the Tizen maps.
        /// </summary>
        private IGeocodingService _iGeocodingService;

        /// <summary>
        /// MapService class instance used for getting the map service data.
        /// </summary>
        private MapService _mapService;

        /// <summary>
        /// TizenMapView class instance used for interacting with the map view.
        /// </summary>
        private TizenMapView _mapView;

        /// <summary>
        /// List of pins' screen coordinates.
        /// </summary>
        private List<Point> _pinScreenCoordinates = new List<Point>();

        /// <summary>
        /// Recently received geographical coordinates.
        /// </summary>
        private Geocoordinates _recentlyReceivedCoordinates;

        /// <summary>
        /// Default zoom value.
        /// </summary>
        private const int DEFAULT_ZOOM_VALUE = 2;

        /// <summary>
        /// Zoom value used to display one marked in the middle of the map view.
        /// </summary>
        private const int ZOOM_VALUE_FOR_ONE_MARKER = 12;

        /// <summary>
        /// Maximum distance between markers.
        /// </summary>
        private const int MAX_DISTANCE_BETWEEN_MARKERS = 300;

        /// <summary>
        /// Device screen size.
        /// </summary>
        private const int SCREEN_SIZE = 360;

        /// <summary>
        /// Calculated distance in pixels between most distant markers.
        /// </summary>
        private double _distance = 0;

        #endregion

        #region properties

        /// <summary>
        /// "Find more markers" bindable property definition.
        /// </summary>
        public static BindableProperty FindMoreMarkersCommandProperty =
            BindableProperty.Create("FindMoreMarkersCommand",
            typeof(ICommand), typeof(MapPage), default(ICommand));

        /// <summary>
        /// "Find more markers" command.
        /// </summary>
        public ICommand FindMoreMarkersCommand
        {
            set => SetValue(FindMoreMarkersCommandProperty, value);
            get => (ICommand)GetValue(FindMoreMarkersCommandProperty);
        }

        #endregion

        #region methods

        /// <summary>
        /// MapPage class constructor.
        /// </summary>
        public MapPage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles "Rotated" event of the rotary event manager.
        /// Zooms in/out map on rotary event.
        /// </summary>
        /// <param name="e">Rotary event arguments.</param>
        private void OnRotaryChange(ElmSharp.Wearable.RotaryEventArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Handles "CenterPointCalculated" event of the geocoding service.
        /// </summary>
        /// <param name="sender">Object firing the event.</param>
        /// <param name="e">Event arguments.</param>
        private void ServiceOnCenterPointCalculated(object sender, IGeocodingCoordinatesArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Centers the map view.
        /// </summary>
        /// <param name="latitude">Latitude value.</param>
        /// <param name="longitude">Longitude value.</param>
        private void CenterMap(double latitude, double longitude)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Initializes the zoom value of the map view.
        /// </summary>
        private void InitializeZoom()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Adjusts the zoom value of the map view so that the specified distance between markers
        /// fits on the device screen.
        /// </summary>
        /// <returns>Zoom value.</returns>
        private int AdjustZoom()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Handles "CoordinatesReceived" event of the geocoding service.
        /// </summary>
        /// <param name="sender">Object firing the event.</param>
        /// <param name="e">Event arguments.</param>
        private void ServiceOnCoordinatesReceived(object sender, IGeocodingCoordinatesArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Handles "OnMapViewSet" event of the map view.
        /// </summary>
        /// <param name="sender">Object firing the event.</param>
        /// <param name="e">Event arguments.</param>
        private void OnMapViewSet(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Overrides OnDisappearing method.
        /// Unregisters event handlers.
        /// </summary>
        protected override void OnDisappearing()
        {
            base.OnDisappearing();
        }

        #endregion
    }
}
