﻿using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace Geocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Welcome page.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class WelcomePage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes a new instance of the WelcomePage class.
        /// </summary>
        public WelcomePage()
        {
            InitializeComponent();
        }

        #endregion
    }
}