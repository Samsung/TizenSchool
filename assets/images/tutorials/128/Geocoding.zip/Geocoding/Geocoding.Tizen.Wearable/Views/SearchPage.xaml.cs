﻿using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace Geocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Search page.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SearchPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public SearchPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}