﻿using System;
using Tizen.Maps;
using Xamarin.Forms;

namespace Geocoding.Tizen.Wearable.Controls
{
    /// <summary>
    /// TizenMapView control class.
    /// Provides base functionality of the TizenMapView.
    /// </summary>
    public class TizenMapView : View
    {
        #region fields
        #endregion

        #region properties
        #endregion
    }
}
