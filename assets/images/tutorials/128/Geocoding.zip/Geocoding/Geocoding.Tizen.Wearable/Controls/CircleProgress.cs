﻿using Xamarin.Forms;

namespace Geocoding.Tizen.Wearable.Controls
{
    /// <summary>
    /// CircleProgress control class.
    /// </summary>
    public class CircleProgress : View
    {
    }
}
