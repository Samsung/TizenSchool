﻿using Tizen.Maps;

namespace Geocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// IMapServiceProvider interface.
    /// It defines methods that have to be implemented by class used to providing map service.
    /// </summary>
    public interface IMapServiceProvider
    {
        #region methods

        /// <summary>
        /// Returns an instance of the map service class.
        /// </summary>
        /// <returns>An instance of map service class.</returns>
        MapService GetService();

        #endregion
    }
}
