﻿using Geocoding.Tizen.Wearable.Services;
using Tizen.Maps;

[assembly: Xamarin.Forms.Dependency(typeof(MapServiceProvider))]
namespace Geocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Provides an instance of the map service class to other application modules.
    /// </summary>
    class MapServiceProvider : IMapServiceProvider
    {
        #region fields

        /// <summary>
        /// An instance of the map service class provided by the Tizen API.
        /// </summary>
        private MapService _mapService;

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public MapServiceProvider()
        {
        }

        /// <summary>
        /// Returns an instance of the map service class.
        /// </summary>
        /// <returns>An instance of the map service class.</returns>
        public MapService GetService()
        {
            throw new System.NotImplementedException();
        }

        #endregion
    }
}
