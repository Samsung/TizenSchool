﻿using Geocoding.ViewModels;
using System;

namespace Geocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// GeocodingUserConsentArgs class.
    /// Defines structure of object being parameter of the UserConsent event.
    /// </summary>
    class GeocodingUserConsentArgs : EventArgs, IGeocodingUserConsentArgs
    {
        #region properties

        /// <summary>
        /// Consent status.
        /// </summary>
        public bool IsConsent { get; }

        #endregion

        #region methods

        /// <summary>
        /// GeocodingUserConsentArgs class constructor.
        /// </summary>
        /// <param name="isConsent">Consent status value.</param>
        public GeocodingUserConsentArgs(bool isConsent)
        {
            IsConsent = isConsent;
        }

        #endregion
    }
}
