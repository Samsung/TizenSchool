﻿using Geocoding.ViewModels;
using System;

namespace Geocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// GeocodingCoordinatesArgs class.
    /// Defines structure of object being parameter of the CoordinatesReceived and CenterPointCalculated events.
    /// </summary>
    class GeocodingCoordinatesArgs : EventArgs, IGeocodingCoordinatesArgs
    {
        #region properties

        /// <summary>
        /// Latitude value.
        /// </summary>
        public double Latitude { get; }

        /// <summary>
        /// Longitude value.
        /// </summary>
        public double Longitude { get; }

        #endregion

        #region methods

        /// <summary>
        /// GeocodingCoordinatesArgs class constructor.
        /// </summary>
        /// <param name="latitude">Latitude value.</param>
        /// <param name="longitude">Longitude value.</param>
        public GeocodingCoordinatesArgs(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }

        #endregion
    }
}
