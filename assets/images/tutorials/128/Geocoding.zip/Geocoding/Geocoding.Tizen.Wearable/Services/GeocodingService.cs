﻿using Geocoding.Tizen.Wearable.Services;
using Geocoding.ViewModels;
using System;
using System.Collections.Generic;
using Tizen.Maps;
using Xamarin.Forms;
using System.Linq;

[assembly: Xamarin.Forms.Dependency(typeof(GeocodingService))]
namespace Geocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Service which allows to manage geolocation data provided by the Tizen maps.
    /// </summary>
    class GeocodingService : IGeocodingService
    {
        #region fields

        /// <summary>
        /// Not found error message.
        /// </summary>
        private const string NOT_FOUND_ERROR = "NotFound";

        /// <summary>
        /// Network unreachable error message.
        /// </summary>
        private const string NETWORK_UNREACHABLE_ERROR = "NetworkUnreachable";

        /// <summary>
        /// Invalid operation error message.
        /// </summary>
        private const string INVALID_OPERATION_ERROR = "InvalidOperation";

        /// <summary>
        /// MapService class instance used for getting the map service data.
        /// </summary>
        public MapService _mapService;

        /// <summary>
        /// The last response containing geocoding data.
        /// </summary>
        private IEnumerable<Geocoordinates> _latestGeocodeResponse;

        #endregion

        #region properties

        /// <summary>
        /// Notifies about user consent.
        /// </summary>
        public event EventHandler<IGeocodingUserConsentArgs> UserConsent;

        /// <summary>
        /// Notifies about geocode request success.
        /// </summary>
        public event EventHandler GeocodeRequestSuccess;

        /// <summary>
        /// Notifies about lack of results of the geocode request.
        /// </summary>
        public event EventHandler GeocodeRequestNotFound;

        /// <summary>
        /// Notifies about lack of connection to the map provider during the geocode request.
        /// </summary>
        public event EventHandler GeocodeRequestConnectionFailed;

        /// <summary>
        /// Notifies about received coordinates.
        /// </summary>
        public event EventHandler<IGeocodingCoordinatesArgs> CoordinatesReceived;

        /// <summary>
        /// Notifies about center point coordinates.
        /// </summary>
        public event EventHandler<IGeocodingCoordinatesArgs> CenterPointCalculated;

        #endregion

        #region methods

        /// <summary>
        /// MagnetometerService class constructor.
        /// Creates instance of internal Magnetometer class.
        /// </summary>
        public GeocodingService()
        {
        }

        /// <summary>
        /// Parses data provided with the last geocoding request.
        /// </summary>
        public void ParseLastGeocodeResponse()
        {
        }

        /// <summary>
        /// Requests user's consent to the map provider's license terms.
        /// </summary>
        public async void RequestUserConsent()
        {
        }

        /// <summary>
        /// Creates request to translate given address to its geographical location.
        /// </summary>
        /// <param name="address">Address value.</param>
        public async void CreateGeocodeRequestMethod(string address)
        {
        }

        #endregion
    }
}
