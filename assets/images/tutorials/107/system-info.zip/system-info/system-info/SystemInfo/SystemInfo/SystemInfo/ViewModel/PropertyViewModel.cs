using System.Collections.ObjectModel;
using SystemInfo.Utils;
using SystemInfo.ViewModel.List;

namespace SystemInfo.ViewModel
{
    /// <summary>
    /// ViewModel class for property page.
    /// </summary>
    public class PropertyViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// List of content of property page.
        /// </summary>
        public static readonly string[] Properties = { "Display", "LED", "Vibrator", "USB" };

        /// <summary>
        /// Local storage of property page content.
        /// </summary>
        private ObservableCollection<ItemViewModel> _propertiesCollection;

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets property page content.
        /// </summary>
        public ObservableCollection<ItemViewModel> PropertiesCollection
        {
            get => _propertiesCollection;
            set => SetProperty(ref _propertiesCollection, value);
        }

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public PropertyViewModel()
        {
            PropertiesCollection = ListUtils.CreateItemsListWithNavigation(Properties);
        }

        #endregion
    }
}