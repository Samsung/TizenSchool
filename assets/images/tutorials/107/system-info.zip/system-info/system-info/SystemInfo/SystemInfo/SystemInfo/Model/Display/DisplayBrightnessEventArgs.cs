using System;

namespace SystemInfo.Model.Display
{
    /// <summary>
    /// Class that is passed with DisplayBrightnessChanged event.
    /// </summary>
    public class DisplayBrightnessEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Gets display brightness.
        /// </summary>
        public int Brightness { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set display brightness.
        /// </summary>
        /// <param name="brightness">Display brightness.</param>
        public DisplayBrightnessEventArgs(int brightness)
        {
            Brightness = brightness;
        }

        #endregion
    }
}