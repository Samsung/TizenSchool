using System;
using Xamarin.Forms;

namespace SystemInfo.Model.Led
{
    /// <summary>
    /// Class that holds information about LED.
    /// </summary>
    public class Led
    {
        #region fields

        /// <summary>
        /// Service that provides information about LED.
        /// </summary>
        private readonly ILed _service;

        #endregion

        #region properties

        /// <summary>
        /// Gets LED's max brightness.
        /// </summary>
        public int MaxBrightness => _service.MaxBrightness;

        /// <summary>
        /// Gets LED's brightness.
        /// </summary>
        public int Brightness => _service.Brightness;

        /// <summary>
        /// Event invoked when LED's brightness has changed.
        /// </summary>
        public event EventHandler<LedEventArgs> LedChanged;

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public Led()
        {
            _service = DependencyService.Get<ILed>();

            _service.StartListening();

            _service.LedChanged += (s, e) => { OnLedChanged(e); };
        }

        /// <summary>
        /// Invokes LedChanged event.
        /// </summary>
        /// <param name="e">Arguments passed with event.</param>
        protected virtual void OnLedChanged(LedEventArgs e)
        {
            LedChanged?.Invoke(this, e);
        }

        #endregion
    }
}