using Xamarin.Forms;

namespace SystemInfo.View
{
    /// <summary>
    /// Interface that contains all pages, which have different layout on different platforms.
    /// </summary>
    public interface IPageResolver
    {
        #region properties

        /// <summary>
        /// Main page of application.
        /// </summary>
        Page MainPage { get; }

        /// <summary>
        /// Page that contains information about device's capabilities.
        /// </summary>
        Page CapabilitiesPage { get; }

        /// <summary>
        /// Page that contains information about device's display.
        /// </summary>
        Page DisplayPage { get; }

        /// <summary>
        /// Page that contains information about device's LEDs.
        /// </summary>
        Page LedPage { get; }

        /// <summary>
        /// Page that contains information about device's settings.
        /// </summary>
        Page SettingsPage { get; }

        /// <summary>
        /// Page that contains information about device's USB.
        /// </summary>
        Page UsbPage { get; }

        /// <summary>
        /// Page that contains information about device's vibrators.
        /// </summary>
        Page VibratorPage { get; }

        #endregion
    }
}