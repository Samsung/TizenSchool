namespace SystemInfo.Model.Vibrator
{
    /// <summary>
    /// Interface that contains all necessary methods to get information about device's vibrators.
    /// </summary>
    public interface IVibrator
    {
        #region properties

        /// <summary>
        /// Gets the number of available vibrators.
        /// </summary>
        int NumberOfVibrators { get; }

        #endregion
    }
}