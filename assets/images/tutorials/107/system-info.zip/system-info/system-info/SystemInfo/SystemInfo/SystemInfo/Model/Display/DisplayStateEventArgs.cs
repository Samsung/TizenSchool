namespace SystemInfo.Model.Display
{
    /// <summary>
    /// Class that is passed with DisplayStateChanged event.
    /// </summary>
    public class DisplayStateEventArgs : System.EventArgs
    {
        #region properties

        /// <summary>
        /// Gets display state.
        /// </summary>
        public DisplayState DisplayState { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set display state.
        /// </summary>
        /// <param name="displayState">Display state.</param>
        public DisplayStateEventArgs(DisplayState displayState)
        {
            DisplayState = displayState;
        }

        #endregion
    }
}