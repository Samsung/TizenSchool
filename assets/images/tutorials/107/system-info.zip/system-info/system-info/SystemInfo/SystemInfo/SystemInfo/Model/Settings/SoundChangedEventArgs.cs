using System;

namespace SystemInfo.Model.Settings
{
    /// <summary>
    /// Class that is passed with SoundChanged event.
    /// </summary>
    public class SoundChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Indicates if the screen lock sound is enabled.
        /// </summary>
        public bool SoundLockEnabled { get; set; }

        /// <summary>
        /// Indicates if the device is in the silent mode.
        /// </summary>
        public bool SilentModeEnabled { get; set; }

        /// <summary>
        /// Indicates if the screen touch sound is enabled.
        /// </summary>
        public bool SoundTouchEnabled { get; set; }

        /// <summary>
        /// Indicates the file path of the current notification tone set by the user.
        /// </summary>
        public string SoundNotification { get; set; }

        /// <summary>
        /// Indicates the time period for notification repetitions.
        /// </summary>
        public int SoundNotificationRepetitionPeriod { get; set; }

        #endregion
    }
}