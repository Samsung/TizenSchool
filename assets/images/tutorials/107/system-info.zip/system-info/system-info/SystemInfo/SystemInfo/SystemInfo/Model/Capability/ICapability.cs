using System;

namespace SystemInfo.Model.Capability
{
    /// <summary>
    /// Interface that contains all necessary methods to get information about capabilities.
    /// </summary>
    public interface ICapability
    {
        #region properties

        /// <summary>
        /// Indicates if the 3G data network is enabled.
        /// </summary>
        bool Network3G { get; }

        /// <summary>
        /// Indicates if Wi-Fi-related notifications are enabled on the device.
        /// </summary>
        bool WifiNotification { get; }

        /// <summary>
        /// Indicates if the device is in the flight mode.
        /// </summary>
        bool FlightMode { get; }

        /// <summary>
        /// Event invoked when 3G network was turned on or off.
        /// </summary>
        event EventHandler<CapabilityChangedEventArgs> Network3GChanged;

        /// <summary>
        /// Event invoked when Wi-Fi-related notifications have changed.
        /// </summary>
        event EventHandler<CapabilityChangedEventArgs> WifiNotificationChanged;

        /// <summary>
        /// Event invoked when flight mode was turned on or off.
        /// </summary>
        event EventHandler<CapabilityChangedEventArgs> FlightModeChanged;

        #endregion

        #region methods

        /// <summary>
        /// Starts observing capabilities information for changes.
        /// </summary>
        /// <remarks>
        /// Capabilities' events will be never invoked before calling this method.
        /// </remarks>
        void StartListening();

        #endregion
    }
}