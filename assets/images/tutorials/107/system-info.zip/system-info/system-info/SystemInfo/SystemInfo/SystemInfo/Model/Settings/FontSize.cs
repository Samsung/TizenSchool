namespace SystemInfo.Model.Settings
{
    /// <summary>
    /// Enumerator that contains all font sizes.
    /// </summary>
    public enum FontSize
    {
        /// <summary>
        /// Small size.
        /// </summary>
        Small = 0,

        /// <summary>
        /// Normal size.
        /// </summary>
        Normal,

        /// <summary>
        /// Large size.
        /// </summary>
        Large,

        /// <summary>
        /// Huge size.
        /// </summary>
        Huge,

        /// <summary>
        /// Giant size.
        /// </summary>
        Giant
    }
}