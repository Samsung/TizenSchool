namespace SystemInfo.ViewModel
{
    /// <summary>
    /// ViewModel class for battery page.
    /// </summary>
    public class BatteryViewModel : ViewModelBase
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public BatteryViewModel()
        {
        }

        #endregion
    }
}