using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace SystemInfo.Tizen.Wearable.View
{
    /// <summary>
    /// Interaction logic for UsbPage.xaml
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UsbPage : CirclePage
    {
        /// <summary>
        /// Default class constructor.
        /// </summary>
        public UsbPage()
        {
            InitializeComponent();
        }
    }
}