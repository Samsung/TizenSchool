using System;
using SystemInfo.Model.Usb;
using SystemInfo.Tizen.Wearable.Service;
using SystemSettings = Tizen.System.SystemSettings;

[assembly: Xamarin.Forms.Dependency(typeof(UsbService))]
namespace SystemInfo.Tizen.Wearable.Service
{
    /// <summary>
    /// Provides methods that allow to obtain information about USB services.
    /// </summary>
    public class UsbService : IUsb
    {
        #region properties

        /// <summary>
        /// Indicates if the USB debugging is enabled.
        /// </summary>
        public bool UsbDebuggingEnabled => SystemSettings.UsbDebuggingEnabled;

        /// <summary>
        /// Event invoked when USB debugging state has changed.
        /// </summary>
        public event EventHandler<UsbDebuggingEventArgs> UsbDebuggingChanged;

        #endregion

        #region methods

        /// <summary>
        /// Starts observing USB information for changes.
        /// </summary>
        /// <remarks>
        /// UsbDebuggingChanged event will be never invoked before calling this method.
        /// </remarks>
        public void StartListening()
        {
            SystemSettings.UsbDebuggingSettingChanged +=
                (s, e) => { UsbDebuggingChanged?.Invoke(s, new UsbDebuggingEventArgs(e.Value)); };
        }

        #endregion
    }
}
