using System;

namespace SystemInfo.Model.Settings
{
    /// <summary>
    /// Class that is passed with UserSettingsChanged event.
    /// </summary>
    public class UserSettingsChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// The file path of the current ringtone.
        /// </summary>
        public string IncomingCallRingtone { get; set; }

        /// <summary>
        /// The file path of the current email alert ringtone.
        /// </summary>
        public string EmailAlertRingtone { get; set; }

        /// <summary>
        /// The file path of the current home screen wallpaper.
        /// </summary>
        public string WallpaperHomeScreen { get; set; }

        /// <summary>
        /// The file path of the current lock screen wallpaper.
        /// </summary>
        public string WallpaperLockScreen { get; set; }

        #endregion
    }
}