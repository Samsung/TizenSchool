using System.Collections.Generic;
using System.Collections.ObjectModel;
using SystemInfo.ViewModel.List;

namespace SystemInfo.Tizen.Wearable.View
{
    /// <summary>
    /// Labeled view model observable collection.
    /// </summary>
    public class MenuItemsCollection : ObservableCollection<ItemViewModel>
    {
        #region properties

        /// <summary>
        /// Name for the menu items collection.
        /// </summary>
        public string Name { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor.
        /// </summary>
        /// <param name="items">Items collection.</param>
        public MenuItemsCollection(IEnumerable<ItemViewModel> items) : base(items)
        {
        }

        #endregion
    }
}
