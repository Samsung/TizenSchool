using System.Collections.ObjectModel;
using SystemInfo.Utils;
using SystemInfo.ViewModel.List;

namespace SystemInfo.ViewModel
{
    /// <summary>
    /// ViewModel class for "Other" page.
    /// </summary>
    public class OtherViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// List of content of "Other" page.
        /// </summary>
        public static readonly string[] Properties = { "Capabilities", "Settings" };

        /// <summary>
        /// Local storage of "Other" page content.
        /// </summary>
        private ObservableCollection<ItemViewModel> _propertiesCollection;

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets "Other" page content.
        /// </summary>
        public ObservableCollection<ItemViewModel> PropertiesCollection
        {
            get => _propertiesCollection;
            set => SetProperty(ref _propertiesCollection, value);
        }

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public OtherViewModel()
        {
            PropertiesCollection = ListUtils.CreateItemsListWithNavigation(Properties);
        }

        #endregion
    }
}