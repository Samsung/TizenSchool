using System;

namespace SystemInfo.Model.Display
{
    /// <summary>
    /// Class that is passed with ScreenBacklightTimeChanged event.
    /// </summary>
    public class ScreenBacklightTimeChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Gets screen backlight time.
        /// </summary>
        public int ScreenBacklightTime { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set screen backlight time.
        /// </summary>
        /// <param name="screenBacklightTime">Screen backlight time.</param>
        public ScreenBacklightTimeChangedEventArgs(int screenBacklightTime)
        {
            ScreenBacklightTime = screenBacklightTime;
        }

        #endregion
    }
}