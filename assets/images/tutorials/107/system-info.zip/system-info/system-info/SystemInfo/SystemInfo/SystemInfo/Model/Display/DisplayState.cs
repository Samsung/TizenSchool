namespace SystemInfo.Model.Display
{
    /// <summary>
    /// Enumerator that contains all states of the display.
    /// </summary>
    public enum DisplayState
    {
        /// <summary>
        /// Display is in normal state.
        /// </summary>
        Normal,

        /// <summary>
        /// Display is dimmed.
        /// </summary>
        Dim,

        /// <summary>
        /// Display is turned off.
        /// </summary>
        Off
    }
}