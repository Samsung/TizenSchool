using SystemInfo.View;
using Xamarin.Forms;

namespace SystemInfo
{
    /// <summary>
    /// Portable application main class.
    /// </summary>
    public class App : Application
    {
        /// <summary>
        /// Portable application constructor method.
        /// </summary>
        public App()
        {
            MainPage = new NavigationPage();
            MainPage.Navigation.PushAsync(DependencyService.Get<IPageResolver>().MainPage, false);
        }
    }
}