using System.Collections.ObjectModel;
using System.Linq;
using SystemInfo.Utils;

namespace SystemInfo.ViewModel.List
{
    /// <summary>
    /// ViewModel class for list of grouped items.
    /// </summary>
    public class GroupViewModel : ObservableCollection<ListItem>
    {
        #region properties

        /// <summary>
        /// Gets single group by its title.
        /// </summary>
        /// <param name="s">Title of the group.</param>
        /// <returns>If group with given title is found, function returns that group, otherwise returns null.</returns>
        public ListItem this[string s] => GetGroupByTitle(s);

        #endregion

        #region methods

        /// <summary>
        /// Gets group from its title.
        /// </summary>
        /// <param name="groupName">Group title.</param>
        /// <returns>If group with given title is found, function returns that group, otherwise returns null.</returns>
        private ListItem GetGroupByTitle(string groupName)
        {
            return this.FirstOrDefault(item => item.GroupName.Equals(groupName));
        }

        #endregion
    }
}