using SystemInfo.Model.Led;
using SystemInfo.Utils;

namespace SystemInfo.ViewModel
{
    /// <summary>
    /// ViewModel class for LED page.
    /// </summary>
    public class LedViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Properties of device's LED.
        /// </summary>
        public static readonly string[] Properties = { "Max Brightness", "Brightness" };

        /// <summary>
        /// Local storage of device's LED properties.
        /// </summary>
        private ListItem _itemList;

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets device's LED properties.
        /// </summary>
        public ListItem ItemList
        {
            get => _itemList;
            set => SetProperty(ref _itemList, value);
        }

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public LedViewModel()
        {
            var led = new Led();

            string[] initialValues =
            {
                led.MaxBrightness.ToString(),
                led.Brightness.ToString()
            };

            ItemList = ListUtils.CreateItemsList(Properties, initialValues, ListItemType.Standard);

            led.LedChanged += OnLedChanged;
        }

        /// <summary>
        /// Updates LED's brightness.
        /// </summary>
        /// <param name="s">Object that sent event.</param>
        /// <param name="e">Event's argument.</param>
        private void OnLedChanged(object s, LedEventArgs e)
        {
            ItemList["Brightness"] = e.Brightness.ToString();
        }

        #endregion
    }
}