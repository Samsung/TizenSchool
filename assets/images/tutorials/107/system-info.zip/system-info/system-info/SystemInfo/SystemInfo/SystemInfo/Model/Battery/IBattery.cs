namespace SystemInfo.Model.Battery
{
    /// <summary>
    /// Interface that contains all necessary methods to get information about battery.
    /// </summary>
    public interface IBattery
    {
    }
}