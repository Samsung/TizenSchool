using System;
using SystemInfo.Model.Led;
using SystemInfo.Tizen.Wearable.Service;
using Led = Tizen.System.Led;

[assembly: Xamarin.Forms.Dependency(typeof(LedService))]
namespace SystemInfo.Tizen.Wearable.Service
{
    /// <summary>
    /// Provides methods that allow to obtain information about device's LED.
    /// </summary>
    public class LedService : ILed
    {
        #region properties

        /// <summary>
        /// LED's max brightness.
        /// </summary>
        public int MaxBrightness => Led.MaxBrightness;

        /// <summary>
        /// LED's brightness.
        /// </summary>
        public int Brightness => Led.Brightness;

        /// <summary>
        /// Event invoked when LED's brightness has changed.
        /// </summary>
        public event EventHandler<LedEventArgs> LedChanged;

        #endregion

        #region methods

        /// <summary>
        /// Starts observing LED's brightness for changes.
        /// </summary>
        /// <remarks>
        /// Event LedChanged will be never invoked before calling this method.
        /// </remarks>
        public void StartListening()
        {
            Led.BrightnessChanged += (s, e) => { LedChanged?.Invoke(s, new LedEventArgs(e.Brightness)); };
        }

        #endregion
    }
}
