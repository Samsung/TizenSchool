using System.Collections.ObjectModel;
using SystemInfo.ViewModel;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace SystemInfo.Tizen.Wearable.View
{
    /// <summary>
    /// Main page of the application. Shows application's main menu.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// Initializes page component.
        /// </summary>
        public MainPage()
        {
            BindingContext = PrepareMainMenuItems();

            InitializeComponent();
        }

        /// <summary>
        /// Returns main menu items grouped by their type.
        /// </summary>
        /// <returns>Main menu items.</returns>
        private ObservableCollection<MenuItemsCollection> PrepareMainMenuItems()
        {
            return new ObservableCollection<MenuItemsCollection>
            {
                new MenuItemsCollection(new PropertyViewModel().PropertiesCollection)
                {
                    Name = "Properties"
                },
                new MenuItemsCollection(new OtherViewModel().PropertiesCollection)
                {
                    Name = "Other"
                }
            };
        }

        #endregion
    }
}
