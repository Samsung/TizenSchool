using System;

namespace SystemInfo.Model.Settings
{
    /// <summary>
    /// Class that is passed with FontChanged event.
    /// </summary>
    public class FontChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// The current system font size.
        /// </summary>
        public FontSize FontSize { get; set; }

        /// <summary>
        /// The current system font type.
        /// </summary>
        public string FontType { get; set; }

        /// <summary>
        /// The current system default font type.
        /// </summary>
        public string DefaultFontType { get; set; }

        #endregion
    }
}