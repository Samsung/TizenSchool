using System;

namespace SystemInfo.Model.Usb
{
    /// <summary>
    /// Class that is passed with UsbDebuggingChanged event.
    /// </summary>
    public class UsbDebuggingEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Indicates if the USB debugging is enabled.
        /// </summary>
        public bool UsbDebuggingEnabled { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set USB debugging enabled flag.
        /// </summary>
        /// <param name="usbDebuggingEnabled">USB debugging enabled flag.</param>
        public UsbDebuggingEventArgs(bool usbDebuggingEnabled)
        {
            UsbDebuggingEnabled = usbDebuggingEnabled;
        }

        #endregion
    }
}