using System;
using System.Diagnostics;
using Xamarin.Forms;

namespace SystemInfo.Utils
{
    /// <summary>
    /// Class that allows getting value of device's features.
    /// </summary>
    public static class KeyUtil
    {
        #region methods

        /// <summary>
        /// Gets string value of feature by its name.
        /// </summary>
        /// <param name="key">Name of the feature.</param>
        /// <returns>Value of the feature.</returns>
        public static string GetKeyValue<T>(string key)
        {
            var result = string.Empty;


            if (typeof(T) == typeof(bool))
            {
                try
                {
                    var boolValue = DependencyService.Get<IKeyUtil>().TryGetValueToBool(key);
                    result = boolValue ? "Supported" : "Not Supported";
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }
            }
            else if (typeof(T) == typeof(int))
            {
                try
                {
                    var intValue = DependencyService.Get<IKeyUtil>().TryGetValueToInt(key);
                    result = intValue.ToString();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }
            }
            else if (typeof(T) == typeof(string))
            {
                try
                {
                    var stringValue = DependencyService.Get<IKeyUtil>().TryGetValueToString(key);
                    result = stringValue;
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }
            }
            else if (typeof(T) == typeof(double))
            {
                try
                {
                    var doubleValue = DependencyService.Get<IKeyUtil>().TryGetValueToDouble(key);
                    result = doubleValue.ToString();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }
            }
            else if (typeof(T) == typeof(DateTime))
            {
                try
                {
                    var datetimeValue = DependencyService.Get<IKeyUtil>().TryGetValueToDateTime(key);
                    result = datetimeValue.ToString();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }
            }

            return result;
        }

        #endregion
    }
}