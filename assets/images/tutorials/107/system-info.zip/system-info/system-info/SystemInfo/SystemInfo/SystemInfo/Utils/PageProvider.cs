using SystemInfo.View;
using Xamarin.Forms;

namespace SystemInfo.Utils
{
    /// <summary>
    /// Helper class that provides application's pages.
    /// </summary>
    public static class PageProvider
    {
        #region methods

        /// <summary>
        /// Method that provides platform-specific pages.
        /// </summary>
        /// <param name="s">Title of page.</param>
        /// <returns>Returns page by its title. In case of unsupported title empty ContentPage will be returned.</returns>
        public static Page CreatePage(string s)
        {
            switch (s)
            {
                case "Display":
                    return DependencyService.Get<IPageResolver>().DisplayPage;
                case "USB":
                    return DependencyService.Get<IPageResolver>().UsbPage;
                case "Capabilities":
                    return DependencyService.Get<IPageResolver>().CapabilitiesPage;
                case "Settings":
                    return DependencyService.Get<IPageResolver>().SettingsPage;
                case "LED":
                    return DependencyService.Get<IPageResolver>().LedPage;
                case "Vibrator":
                    return DependencyService.Get<IPageResolver>().VibratorPage;
                default:
                    return new ContentPage { Title = "Default " + s };
            }
        }

        #endregion
    }
}