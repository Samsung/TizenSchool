using System;

namespace SystemInfo.Model.Usb
{
    /// <summary>
    /// Interface that contains all necessary methods to get information about USB.
    /// </summary>
    public interface IUsb
    {
        #region properties

        /// <summary>
        /// Indicates if the USB debugging is enabled.
        /// </summary>
        bool UsbDebuggingEnabled { get; }

        /// <summary>
        /// Event invoked when USB debugging state has changed.
        /// </summary>
        event EventHandler<UsbDebuggingEventArgs> UsbDebuggingChanged;

        #endregion

        #region methods

        /// <summary>
        /// Starts observing USB information for changes.
        /// </summary>
        /// <remarks>
        /// UsbDebuggingChanged event will be never invoked before calling this method.
        /// </remarks>
        void StartListening();

        #endregion
    }
}