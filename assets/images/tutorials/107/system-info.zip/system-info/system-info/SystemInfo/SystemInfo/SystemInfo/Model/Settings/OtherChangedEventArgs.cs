using System;

namespace SystemInfo.Model.Settings
{
    /// <summary>
    /// Class that is passed with OtherChanged event.
    /// </summary>
    public class OtherChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Indicates device name.
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// Indicates if the device user has enabled motion feature.
        /// </summary>
        public bool MotionEnabled { get; set; }

        /// <summary>
        /// Indicates if the motion service is activated.
        /// </summary>
        public bool MotionActivationEnabled { get; set; }

        #endregion
    }
}