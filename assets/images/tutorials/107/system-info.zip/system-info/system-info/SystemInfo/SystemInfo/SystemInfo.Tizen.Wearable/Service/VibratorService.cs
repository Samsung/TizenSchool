using SystemInfo.Model.Vibrator;
using SystemInfo.Tizen.Wearable.Service;
using Vibrator = Tizen.System.Vibrator;

[assembly: Xamarin.Forms.Dependency(typeof(VibratorService))]
namespace SystemInfo.Tizen.Wearable.Service
{
    /// <summary>
    /// Provides methods that allow to obtain information about device's vibrators.
    /// </summary>
    public class VibratorService : IVibrator
    {
        #region properties

        /// <summary>
        /// Number of available vibrators.
        /// </summary>
        public int NumberOfVibrators => Vibrator.NumberOfVibrators;

        #endregion
    }
}
