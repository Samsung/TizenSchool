using SystemInfo.Model.Vibrator;
using SystemInfo.Utils;

namespace SystemInfo.ViewModel
{
    /// <summary>
    /// ViewModel class for vibrator page.
    /// </summary>
    public class VibratorViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Properties of device's vibrators.
        /// </summary>
        public static readonly string[] Properties = { "Number of Vibrators" };

        /// <summary>
        /// Local storage of collection of device's vibrators properties.
        /// </summary>
        private ListItem _itemList;

        #endregion

        #region properties

        /// <summary>
        /// Gets or sets device's vibrators properties.
        /// </summary>
        public ListItem ItemList
        {
            get => _itemList;
            set => SetProperty(ref _itemList, value);
        }

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public VibratorViewModel()
        {
            var vibrator = new Vibrator();

            string[] initialValues =
            {
                vibrator.NumberOfVibrators.ToString()
            };

            ItemList = ListUtils.CreateItemsList(Properties, initialValues, ListItemType.Standard);
        }

        #endregion
    }
}