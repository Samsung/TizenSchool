using System.Collections.Generic;
using SystemInfo.Model.Settings;
using Tizen.System;

namespace SystemInfo.Tizen.Wearable.Service
{
    /// <summary>
    /// Class that creates mapping between platform and portable enumerators.
    /// </summary>
    public static class EnumMapper
    {
        #region fields

        /// <summary>
        /// Dictionary of display states.
        /// </summary>
        private static readonly Dictionary<DisplayState, Model.Display.DisplayState> DisplayStateDictionary;

        /// <summary>
        /// Dictionary of font sizes.
        /// </summary>
        private static readonly Dictionary<SystemSettingsFontSize, Model.Settings.FontSize> FontSizeDictionary;

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// Initializes dictionaries used for mapping.
        /// </summary>
        static EnumMapper()
        {
            DisplayStateDictionary = new Dictionary<DisplayState, Model.Display.DisplayState>
            {
                {DisplayState.Normal, Model.Display.DisplayState.Normal},
                {DisplayState.Dim, Model.Display.DisplayState.Dim},
                {DisplayState.Off, Model.Display.DisplayState.Off}
            };

            FontSizeDictionary = new Dictionary<SystemSettingsFontSize, FontSize>
            {
                {SystemSettingsFontSize.Small, FontSize.Small},
                {SystemSettingsFontSize.Normal, FontSize.Normal},
                {SystemSettingsFontSize.Large, FontSize.Large},
                {SystemSettingsFontSize.Huge, FontSize.Huge},
                {SystemSettingsFontSize.Giant, FontSize.Giant}
            };
        }

        /// <summary>
        /// Returns unified display state, common for all supported platform.
        /// </summary>
        /// <param name="displayState">Platform depended display state.</param>
        /// <returns>Common for all supported platform display state.</returns>
        public static Model.Display.DisplayState DisplayStateMapper(DisplayState displayState)
        {
            return DisplayStateDictionary[displayState];
        }

        /// <summary>
        /// Returns unified font size, common for all supported platform.
        /// </summary>
        /// <param name="systemSettingsFontSize">Platform depended font size.</param>
        /// <returns>Common for all supported platform font size.</returns>
        public static FontSize FontSizeMapper(SystemSettingsFontSize systemSettingsFontSize)
        {
            return FontSizeDictionary[systemSettingsFontSize];
        }

        #endregion
    }
}
