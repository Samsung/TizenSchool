using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace SystemInfo.Tizen.Wearable.View
{
    /// <summary>
    /// Interaction logic for BatteryPage.xaml
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BatteryPage : CirclePage
    {
        /// <summary>
        /// Default class constructor.
        /// </summary>
        public BatteryPage()
        {
            InitializeComponent();
        }
    }
}