using System;

namespace SystemInfo.Model.Led
{
    /// <summary>
    /// Interface that contains all necessary methods to get information about LED.
    /// </summary>
    public interface ILed
    {
        #region properties

        /// <summary>
        /// Gets LED's max brightness.
        /// </summary>
        int MaxBrightness { get; }

        /// <summary>
        /// Gets LED's brightness.
        /// </summary>
        int Brightness { get; }

        /// <summary>
        /// Event invoked when LED's brightness has changed.
        /// </summary>
        event EventHandler<LedEventArgs> LedChanged;

        #endregion

        #region methods

        /// <summary>
        /// Starts observing LED's brightness for changes.
        /// </summary>
        /// <remarks>
        /// Event LedChanged will be never invoked before calling this method.
        /// </remarks>
        void StartListening();

        #endregion
    }
}