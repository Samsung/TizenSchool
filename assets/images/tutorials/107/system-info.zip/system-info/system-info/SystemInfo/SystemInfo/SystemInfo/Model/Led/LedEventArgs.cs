namespace SystemInfo.Model.Led
{
    /// <summary>
    /// Class that is passed with LedChanged event.
    /// </summary>
    public class LedEventArgs
    {
        #region properties

        /// <summary>
        /// Gets LED's brightness.
        /// </summary>
        public int Brightness { get; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set LED's brightness.
        /// </summary>
        /// <param name="brightness">LED's brightness.</param>
        public LedEventArgs(int brightness)
        {
            Brightness = brightness;
        }

        #endregion
    }
}