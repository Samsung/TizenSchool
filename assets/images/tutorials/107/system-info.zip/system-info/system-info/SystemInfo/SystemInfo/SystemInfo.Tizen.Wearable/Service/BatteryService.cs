using SystemInfo.Tizen.Wearable.Service;

[assembly: Xamarin.Forms.Dependency(typeof(BatteryService))]
namespace SystemInfo.Tizen.Wearable.Service
{
    /// <summary>
    /// Provides methods that allow to obtain information about device's battery.
    /// </summary>
    public class BatteryService
    {
    }
}
