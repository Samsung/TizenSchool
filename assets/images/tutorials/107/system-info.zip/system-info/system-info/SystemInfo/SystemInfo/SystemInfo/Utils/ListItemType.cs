namespace SystemInfo.Utils
{
    /// <summary>
    /// Enumerator that contains all possible types of items.
    /// </summary>
    public enum ListItemType
    {
        /// <summary>
        /// Standard item with title and value.
        /// </summary>
        Standard = 0,

        /// <summary>
        /// Item with title, value and value's representation on progress bar.
        /// </summary>
        WithProgress
    }
}