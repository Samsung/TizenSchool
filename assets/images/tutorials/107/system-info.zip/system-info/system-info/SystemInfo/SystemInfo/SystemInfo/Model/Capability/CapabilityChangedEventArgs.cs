using System;

namespace SystemInfo.Model.Capability
{
    /// <summary>
    /// Class that is passed with capabilities events.
    /// </summary>
    public class CapabilityChangedEventArgs : EventArgs
    {
        #region properties

        /// <summary>
        /// Gets new value.
        /// </summary>
        public bool Value { get; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor that allows to set new value of capability.
        /// </summary>
        /// <param name="value">Value of capability.</param>
        public CapabilityChangedEventArgs(bool value)
        {
            Value = value;
        }

        #endregion
    }
}