namespace SystemInfo.Model.Battery
{
    /// <summary>
    /// Class that holds information about battery.
    /// </summary>
    public class Battery
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public Battery()
        {
        }

        #endregion
    }
}