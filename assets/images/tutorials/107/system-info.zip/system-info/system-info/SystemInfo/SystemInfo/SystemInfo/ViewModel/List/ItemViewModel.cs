using System.Windows.Input;
using SystemInfo.Utils;

namespace SystemInfo.ViewModel.List
{
    /// <summary>
    /// ViewModel class for single list's item.
    /// </summary>
    public class ItemViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Local storage of item's description.
        /// </summary>
        private string _description;

        #endregion

        #region properties

        /// <summary>
        /// Gets item's title.
        /// </summary>
        public string Title { get; }

        /// <summary>
        /// Gets item's type.
        /// </summary>
        public ListItemType ListItemType { get; }

        /// <summary>
        /// Gets or sets item's description.
        /// </summary>
        public string Description
        {
            get => _description;
            set => SetProperty(ref _description, value);
        }

        /// <summary>
        /// Gets command executed when item is tapped.
        /// </summary>
        public ICommand OnTap { get; }

        #endregion

        #region methods

        /// <summary>
        /// Class constructor.
        /// </summary>
        /// <param name="title">Title of the item.</param>
        /// <param name="onTap">On tap command.</param>
        /// <param name="description">Description of the item.</param>
        /// <param name="listItemType">Type of the item.</param>
        public ItemViewModel(string title, ICommand onTap, string description = "",
            ListItemType listItemType = ListItemType.Standard)
        {
            Title = title;
            Description = description;
            OnTap = onTap;
            ListItemType = listItemType;
        }

        #endregion
    }
}