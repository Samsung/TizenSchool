namespace SystemInfo.Model.Battery
{
    /// <summary>
    /// Enumerator that contains all statuses of battery.
    /// </summary>
    public enum BatteryLevelStatus
    {
    }
}