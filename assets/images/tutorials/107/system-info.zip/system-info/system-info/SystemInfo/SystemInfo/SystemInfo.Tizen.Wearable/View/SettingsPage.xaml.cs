using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace SystemInfo.Tizen.Wearable.View
{
    /// <summary>
    /// Interaction logic for SettingsPage.xaml
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SettingsPage : CirclePage
    {
        /// <summary>
        /// Default class constructor.
        /// </summary>
        public SettingsPage()
        {
            InitializeComponent();
        }
    }
}