﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace SystemInfo.Converter
{
    /// <summary>
    /// Class that converts numeric value to percent.
    /// </summary>
    public class NumberToDisplayPercentConverter : IValueConverter
    {
        #region methods

        /// <summary>
        /// Converts numeric value to percent.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Percent value.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double d;
            double.TryParse(value.ToString(), out d);

            d = d / 100;

            return $"{d:P0}";
        }

        /// <summary>
        /// Converts back percent to numeric value.
        /// </summary>
        /// <param name="value">The value produced by the binding source.</param>
        /// <param name="targetType">The type of the binding target property.</param>
        /// <param name="parameter">The converter parameter to use.</param>
        /// <param name="culture">The culture to use in the converter.</param>
        /// <returns>Numeric value.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}