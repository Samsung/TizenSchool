namespace SystemInfo.Model.Battery
{
    /// <summary>
    /// Class that is passed with BatteryInfoChanged event.
    /// </summary>
    public class BatteryEventArgs : System.EventArgs
    {
    }
}