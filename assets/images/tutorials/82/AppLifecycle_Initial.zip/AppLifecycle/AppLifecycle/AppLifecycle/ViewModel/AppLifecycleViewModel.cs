﻿namespace AppLifecycle.ViewModel
{
    public class AppLifecycleViewModel : ViewModelBase
    {
    }
}
