﻿using Xamarin.Forms;

namespace AppLifecycle.View
{
    /// <summary>
    /// Interaction logic for AppLifecyclePage.xaml.
    /// </summary>
    public partial class AppLifecyclePage : ContentPage
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public AppLifecyclePage()
        {
            InitializeComponent();
        }

        #endregion
    }
}