using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;


namespace Wearable_Lesson017
{
    public class App : Application
    {
        const int treasureX = 3908;
        const int treasureY = 943;
        const int width = 360;
        const int height = 360;
        const int AreaRadius = 150;

        public App()
        {
            Image image = new Image
            {
                Source = "images/map.jpg"
            };

            ScrollView scrollView = new ScrollView
            {
                Orientation = ScrollOrientation.Both,
            };
            scrollView.Content = image;
            scrollView.Scrolled += ScrollviewOnScrolled;

            MainPage = new ContentPage
            {
                Content = scrollView
            };
        }

        private bool IsPointInCircle(double xCenter, double yCenter)
        {
            double deltaX = Math.Abs(xCenter - treasureX);
            double deltaY = Math.Abs(yCenter - treasureY);
            double distance = Math.Sqrt((deltaX * deltaX) + (deltaY * deltaY));
            if (distance < AreaRadius)
            {
                return true;
            }
            return false;
        }

        private void ScrollviewOnScrolled(object sender, ScrolledEventArgs e)
        {
            ScrollView scrollView = (ScrollView)sender;
            double xCenter = scrollView.ScrollX + width / 2;
            double yCenter = scrollView.ScrollY + height / 2;
            bool isInCircle = IsPointInCircle(xCenter, yCenter);
            if (isInCircle)
            {
                scrollView.InputTransparent = true;
                Toast.DisplayText("Congratulations! You found the treasure.");
            }
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            Toast.DisplayText("To move, slide your finger across the screen...", 2000);
            // Handle when your app resumes
        }
    }
}
