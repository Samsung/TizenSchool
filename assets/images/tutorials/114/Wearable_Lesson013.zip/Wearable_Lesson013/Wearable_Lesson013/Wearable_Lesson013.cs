using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.TizenSpecific;

namespace Wearable_Lesson013
{
    public class App : Application
    {
        Button button;
        public App()
        {

            button = new Button
            {
                Text = "Click Me!"
            };
            StackLayout stacklayout = new StackLayout
            {
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center,
                Children =
                {
                    button
                }
            };
            button.On<Xamarin.Forms.PlatformConfiguration.Tizen>().SetStyle(ButtonStyle.Default);

            button.Clicked += OnClickHandler;
            // The root page of your application
            MainPage = new ContentPage
            {
                Content = stacklayout
            };


        }

        void OnClickHandler(object sender, EventArgs args)
        {
            button.Text = "Clicked";
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}


