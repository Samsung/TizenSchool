using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tizen.Wearable.CircularUI.Forms;

using Xamarin.Forms;

namespace XamrinApplication
{
    public class App : Application
    {
        public App()
        {
            MainPage = CreateScrollableImage();
        }
        private ContentPage CreateScrollableImage()
        {
            var image = new Image() { Source = "lesson_16_3.png" };

            ContentPage page = new ContentPage
            {
                Content = new ScrollView
                {
                    Orientation = ScrollOrientation.Both,
                    Content = image,
                }
            };
            return page;
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resume
        }
    }
}
