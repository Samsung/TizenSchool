﻿using Tizen.Applications;
using WearableLesson_25.Tizen.Wearable;

[assembly: Xamarin.Forms.Dependency(typeof(PlatformAPI))]
namespace WearableLesson_25.Tizen.Wearable
{
    class PlatformAPI : IInterface
    {
        public void LaunchApp()
        {
            AppControl control = new AppControl();
            control.Operation = AppControlOperations.View;
            control.Uri = Application.Current.DirectoryInfo.SharedResource + "img1.jpg";
            control.LaunchMode = AppControlLaunchMode.Group;
            AppControl.SendLaunchRequest(control);
        }
    }
}
