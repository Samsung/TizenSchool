using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Tizen.Wearable.CircularUI.Forms;

namespace WearableLesson_25
{
    public class App : Application
    {
        CirclePage circlePage = new CirclePage();
        public App()
        {
            CirclePage circlePage = new CirclePage();
            CircleToolbarItem item = new CircleToolbarItem
            {
                Text = "Tool1",
                SubText = "Select Images",
                Icon = "Default.jpg",
            };
            item.Clicked += Item_Clicked;
            circlePage.ToolbarItems.Add(item);

            MainPage = circlePage;
        }
        private void Item_Clicked(object sender, EventArgs e)
        {
             DependencyService.Get<IInterface>().LaunchApp();
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {

        }
    }
}
