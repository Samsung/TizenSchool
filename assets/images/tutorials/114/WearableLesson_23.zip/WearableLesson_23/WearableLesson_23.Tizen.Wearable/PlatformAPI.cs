﻿using System.Collections.Generic;
using Tizen.Applications;
using WearableLesson_23.Tizen.Wearable;

[assembly: Xamarin.Forms.Dependency(typeof(PlatformAPI))]
namespace WearableLesson_23.Tizen.Wearable
{
    class PlatformAPI : IInterface
    {
        public List<MyPackageInfo> GetPackageList()
        {

            List<MyPackageInfo> myPackages = new List<MyPackageInfo>();
            IEnumerable<Package> packageList = PackageManager.GetPackages();
            foreach (Package package in packageList)
            {
                MyPackageInfo packageInfo = new MyPackageInfo();
                packageInfo.Name = package.Label;
                packageInfo.Version = package.Version;
                packageInfo.Icon = package.IconPath;

                myPackages.Add(packageInfo);
            }
            return myPackages;
        }
    }
}
