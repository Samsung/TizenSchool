using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Tizen.Wearable.CircularUI.Forms;

namespace WearableLesson_23
{
    public class App : Application
    {
        public App()
        {
            CirclePage circlePage = new CirclePage();
            List<MyPackageInfo> packages = DependencyService.Get<IInterface>().GetPackageList();
            for (int i = 0; i < packages.Count; i++)
            {
                CircleToolbarItem item = new CircleToolbarItem
                {
                    SubText = packages[i].Name,
                    Icon = packages[i].Icon,
                    Text = packages[i].Version,
                };

                circlePage.ToolbarItems.Add(item);
            }
            MainPage = circlePage;
        }


        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
