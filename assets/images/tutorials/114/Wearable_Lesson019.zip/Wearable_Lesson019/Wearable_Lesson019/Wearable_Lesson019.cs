using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin;

using Xamarin.Forms;


namespace Wearable_Lesson019
{

    public class MyScrollView : ScrollView
    {
        private int width_size;
        private int height_size;
        public int width
        {
            get
            {
                return width_size;
            }
            set
            {
                width_size = value;
            }
        }
        public int height
        {
            get
            {
                return height_size;
            }
            set
            {
                height_size = value;
            }
        }
        public MyScrollView()
        {
            width = 360;
            height = 360;
        }
    }

    public class App : Application
    { 
        public App()
        {
            // The root page of your application


            MyScrollView scrollobj = new MyScrollView
            {
                Orientation = ScrollOrientation.Both,

            };

            StackLayout stacklayout = new StackLayout
            {
                
                Orientation = StackOrientation.Horizontal,
                Spacing = 0
            };

            LoadImages(stacklayout);

            scrollobj.Content = stacklayout;
            MainPage = new ContentPage
            {
                Content = scrollobj
            };
        }

        private void LoadImages(StackLayout stacklayout)
        {
            Image[] images = new Image[6];
            for (int i = 1; i <= 5; i++)
            {
                images[i] = new Image();

                String imagePath = "images/" + i.ToString() + ".png";
                images[i].Source = ImageSource.FromFile(imagePath);

                stacklayout.Children.Add(images[i]);
            }
        }


        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }


}
