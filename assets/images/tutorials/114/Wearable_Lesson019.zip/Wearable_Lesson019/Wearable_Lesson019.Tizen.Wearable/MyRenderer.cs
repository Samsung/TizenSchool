﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Tizen;
using Wearable_Lesson019;
using Wearable_Lesson019.Tizen.Wearable;


[assembly: ExportRenderer(typeof(MyScrollView), typeof(MyRenderer))]

namespace Wearable_Lesson019.Tizen.Wearable
{
    class MyRenderer : ScrollViewRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<ScrollView> e)
        {
            base.OnElementChanged(e);
            Log.Tag = "Wearable_Lesson019";
            if (Control != null)
            {
                global::Xamarin.Forms.Platform.Tizen.Native.Scroller scroller = Control;

                var ScrollerObj = Element as MyScrollView ;
                scroller.SetPageSize(ScrollerObj.width, ScrollerObj.height);
                scroller.Scrolled += S_Scrolled;
            }
            
            
        }

        private void S_Scrolled(object sender, EventArgs e)
        {
            Log.Info("page is scrolled");
        }
    }
}
