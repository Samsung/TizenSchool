﻿using Xamarin.Forms.Xaml;

namespace BindingTutorial
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}