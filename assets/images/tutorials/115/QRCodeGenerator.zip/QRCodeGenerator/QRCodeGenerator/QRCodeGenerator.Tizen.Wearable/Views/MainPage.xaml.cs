﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Main page of the application.
    /// </summary>
    public partial class MainPage : TwoButtonPage
    {
        #region methods

        /// <summary>
        /// Initializes MainPage class instance.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}