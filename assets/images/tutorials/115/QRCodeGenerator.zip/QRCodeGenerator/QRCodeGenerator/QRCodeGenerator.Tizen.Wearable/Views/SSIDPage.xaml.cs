﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Page providing input for service set identifier.
    /// </summary>
    public partial class SSIDPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes SSIDPage class instance.
        /// </summary>
        public SSIDPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}