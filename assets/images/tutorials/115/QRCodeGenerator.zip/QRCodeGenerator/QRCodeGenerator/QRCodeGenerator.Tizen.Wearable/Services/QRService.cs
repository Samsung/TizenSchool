﻿using QRCodeGenerator.Tizen.Wearable.Services;
using QRCodeGenerator.Services;
using Xamarin.Forms;

[assembly: Dependency(typeof(QRService))]

namespace QRCodeGenerator.Tizen.Wearable.Services
{
    /// <summary>
    /// Application QR service class.
    /// </summary>
    class QRService : IQRService
    {
        #region methods

        /// <summary>
        /// Generates QR code image with Tizen API.
        /// </summary>
        /// <param name="textToEncode">String value that will be encoded intro QR code.</param>
        /// <returns>Path to QR code image.</returns>
        public string Generate(string textToEncode)
        {
            return string.Empty;
        }

        #endregion
    }
}