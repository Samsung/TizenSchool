﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Page providing encryption type selection.
    /// </summary>
    public partial class EncryptionPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes EncryptionPage class instance.
        /// </summary>
        public EncryptionPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}