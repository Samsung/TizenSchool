﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Page providing input for service set identifier.
    /// </summary>
    public partial class SettingsPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes SSIDSettings class instance.
        /// </summary>
        public SettingsPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}