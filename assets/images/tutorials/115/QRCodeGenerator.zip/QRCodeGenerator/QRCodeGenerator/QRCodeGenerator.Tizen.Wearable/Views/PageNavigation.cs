﻿using QRCodeGenerator.Tizen.Wearable.Views;
using QRCodeGenerator.Views;
using Xamarin.Forms;

[assembly: Dependency(typeof(PageNavigation))]

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Application navigation class.
    /// </summary>
    class PageNavigation : IPageNavigation
    {
        #region methods

        /// <summary>
        /// Creates application main page and set it as active.
        /// </summary>
        public void CreateMainPage()
        {
            Application.Current.MainPage = new NavigationPage(new MainPage());
        }

        /// <summary>
        /// Navigates to settings.
        /// </summary>
        public void GoToSettings()
        {
            Application.Current.MainPage.Navigation.PushAsync(new SettingsPage());
        }

        /// <summary>
        /// Navigates to page with generated QR code.
        /// </summary>
        public void GoToQR()
        {
            Application.Current.MainPage.Navigation.PushAsync(new QRPage());
        }

        /// <summary>
        /// Navigates to previous page.
        /// </summary>
        public void GoToPreviousPage()
        {
            Application.Current.MainPage.Navigation.PopAsync();
        }

        /// <summary>
        /// Navigates to page with SSID settings.
        /// </summary>
        public void GoToSSIDPage()
        {
            Application.Current.MainPage.Navigation.PushAsync(new SSIDPage());
        }

        /// <summary>
        /// Navigates to page with password settings.
        /// </summary>
        public void GoToPasswordPage()
        {
            Application.Current.MainPage.Navigation.PushAsync(new PasswordPage());
        }

        /// <summary>
        /// Navigates to page with encryption settings.
        /// </summary>
        public void GoToEncryptionPage()
        {
            Application.Current.MainPage.Navigation.PushAsync(new EncryptionPage());
        }

        #endregion
    }
}