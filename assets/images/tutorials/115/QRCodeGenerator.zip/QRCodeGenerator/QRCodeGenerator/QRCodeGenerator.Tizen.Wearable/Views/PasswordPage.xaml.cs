﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Page providing network password input.
    /// </summary>
    public partial class PasswordPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes PasswordPage class instance.
        /// </summary>
        public PasswordPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}