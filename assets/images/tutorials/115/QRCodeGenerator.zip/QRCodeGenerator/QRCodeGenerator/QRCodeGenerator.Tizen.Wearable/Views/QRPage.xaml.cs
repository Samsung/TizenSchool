﻿using Tizen.Wearable.CircularUI.Forms;

namespace QRCodeGenerator.Tizen.Wearable.Views
{
    /// <summary>
    /// Page providing generated QR Code.
    /// </summary>
    public partial class QRPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes QRPage class instance.
        /// </summary>
        public QRPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}