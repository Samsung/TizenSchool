﻿namespace QRCodeGenerator.Views
{

}