﻿namespace QRCodeGenerator.Utils
{
    /// <summary>
    /// Enumeration containing available encryption types.
    /// </summary>
    public enum EncryptionType
    {
        None,
        WEP,
        WPA
    };
}