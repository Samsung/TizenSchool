﻿namespace QRCodeGenerator.ViewModels
{
    /// <summary>
    /// Provides encryption selection abstraction.
    /// </summary>
    public class EncryptionTypeViewModel : ViewModelBase
    {

    }
}