﻿namespace QRCodeGenerator.Services
{
    /// <summary>
    /// Provides methods which allow to generate QR code image.
    /// </summary>
    public interface IQRService
    {
        #region methods

        /// <summary>
        /// Generates QR code image.
        /// </summary>
        /// <param name="textToEncode">String value that will be encoded intro QR code.</param>
        /// <returns>Path to QR code image.</returns>
        string Generate(string textToEncode);

        #endregion
    }
}