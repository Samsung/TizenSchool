using QRCodeGenerator.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]

namespace QRCodeGenerator
{
    /// <summary>
    /// Main class of QRCodeGenerator.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// Starts application.
        /// </summary>
        public App()
        {
            DependencyService.Get<IPageNavigation>().CreateMainPage();
        }

        #endregion
    }
}