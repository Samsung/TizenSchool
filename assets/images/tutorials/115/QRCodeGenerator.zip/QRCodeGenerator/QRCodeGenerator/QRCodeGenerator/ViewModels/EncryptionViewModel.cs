﻿using QRCodeGenerator.Views;
using Xamarin.Forms;

namespace QRCodeGenerator.ViewModels
{
    /// <summary>
    /// Provides encryption page view abstraction.
    /// </summary>
    public class EncryptionViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Reference to object handling navigation between pages obtained in constructor using DependencyService.
        /// </summary>
        private readonly IPageNavigation _navigation;

        #endregion

        #region methods

        /// <summary>
        /// Initializes EncryptionViewModel class instance.
        /// </summary>
        public EncryptionViewModel()
        {
            _navigation = DependencyService.Get<IPageNavigation>();

            InitializeCollection();
        }

        /// <summary>
        /// Initializes EncryptionTypeList from model.
        /// </summary>
        private void InitializeCollection()
        {

        }

        /// <summary>
        /// Clears all selected options.
        /// </summary>
        private void ClearAllSelection()
        {
            throw new System.NotImplementedException();
        }

        #endregion
    }
}