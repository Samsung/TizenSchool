﻿namespace QRCodeGenerator.Views
{
    /// <summary>
    /// Provides methods which allow to navigate between pages.
    /// </summary>
    public interface IPageNavigation
    {
        #region methods

        /// <summary>
        /// Creates application main page and set it as active.
        /// </summary>
        void CreateMainPage();

        /// <summary>
        /// Navigates to settings page.
        /// </summary>
        void GoToSettings();

        /// <summary>
        /// Navigates to page with generated QR code.
        /// </summary>
        void GoToQR();

        /// <summary>
        /// Navigates to previous page.
        /// </summary>
        void GoToPreviousPage();

        /// <summary>
        /// Navigates to page with SSID settings.
        /// </summary>
        void GoToSSIDPage();

        /// <summary>
        /// Navigates to page with password settings.
        /// </summary>
        void GoToPasswordPage();

        /// <summary>
        /// Navigates to page with encryption settings.
        /// </summary>
        void GoToEncryptionPage();

        #endregion
    }
}