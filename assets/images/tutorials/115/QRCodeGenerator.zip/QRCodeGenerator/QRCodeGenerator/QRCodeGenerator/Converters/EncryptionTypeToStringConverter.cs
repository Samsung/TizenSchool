﻿using System;
using QRCodeGenerator.Utils;
using System.Globalization;
using Xamarin.Forms;

namespace QRCodeGenerator.Converters
{
    /// <summary>
    /// Converter class to convert encryption type enum to string.
    /// </summary>
    class EncryptionTypeToStringConverter : IValueConverter
    {
        #region methods

        /// <summary>
        /// Converts EncryptionType value to string value.
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <param name="targetType">Target type.</param>
        /// <param name="parameter">Converter parameter.</param>
        /// <param name="culture">Culture information.</param>
        /// <returns>Converted value.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string encryptionType = string.Empty;

            if (value is EncryptionType encryption)
            {
                switch (encryption)
                {
                    case EncryptionType.WPA:
                        encryptionType = "WPA";
                        break;
                    case EncryptionType.WEP:
                        encryptionType = "WEP";
                        break;
                    case EncryptionType.None:
                        encryptionType = "None";
                        break;
                }
            }

            return encryptionType;
        }

        /// <summary>
        /// Converts string value to EncryptionType.
        /// Not required by the application (not implemented).
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Target type.</param>
        /// <param name="parameter">Converter parameter.</param>
        /// <param name="culture">Culture information.</param>
        /// <returns>Converted value.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}