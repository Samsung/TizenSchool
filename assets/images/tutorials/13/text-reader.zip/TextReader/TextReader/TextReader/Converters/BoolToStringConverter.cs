﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TextReader.Converters
{
    /// <summary>
    /// Converter class to convert boolean value to string.
    /// </summary>
    public class BoolToStringConverter : IValueConverter
    {
        #region fields

        /// <summary>
        /// String value for the "true" value of the input.
        /// </summary>
        private readonly string _trueValue;

        /// <summary>
        /// String value for the "false" value of the input.
        /// </summary>
        private readonly string _falseValue;

        #endregion

        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public BoolToStringConverter()
        {
            _trueValue = "True";
            _falseValue = "False";
        }

        /// <summary>
        /// Class constructor which allows to specify string values for the "true" and "false"
        /// boolean states.
        /// </summary>
        /// <param name="trueValue">String value for the "true" value of the input.</param>
        /// <param name="falseValue">String value for the "false" value of the input.</param>
        public BoolToStringConverter(string trueValue, string falseValue)
        {
            _trueValue = trueValue;
            _falseValue = falseValue;
        }

        /// <summary>
        /// Converts boolean value to string value.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (bool) value ? _trueValue : _falseValue;
        }

        /// <summary>
        /// Converts back string value to boolean value.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter,
            CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
