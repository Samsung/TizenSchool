﻿using TextReader.Views;
using Xamarin.Forms;

namespace TextReader
{
    /// <summary>
    /// Portable application part main class.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// App class constructor.
        /// Creates the main page of application.
        /// </summary>
        public App()
        {
            MainPage main = new MainPage();

            MainPage = new NavigationPage(main)
            {
                BarBackgroundColor = (Color)main.Resources["MainColor"]
            };
        }

        #endregion
    }
}
