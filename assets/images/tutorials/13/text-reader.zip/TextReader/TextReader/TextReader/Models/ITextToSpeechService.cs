﻿using System;

namespace TextReader.Models
{
    /// <summary>
    /// Interface of text-to-speech service which allows to synthesize a text into speech.
    /// </summary>
    public interface ITextToSpeechService
    {
        #region properties

        /// <summary>
        /// Event fired when the utterance is completed.
        /// </summary>
        event EventHandler UtteranceCompleted;

        /// <summary>
        /// Flag indicating if service is ready to use.
        /// The service requires "Init" method to be called before use.
        /// </summary>
        bool Ready { get; }

        /// <summary>
        /// Currently used text.
        /// If text is changed, the current utterance is stopped immediately
        /// and new one stars then.
        /// </summary>
        string Text { get; set; }

        /// <summary>
        /// Flag indicating if text is read by the TTS engine.
        /// </summary>
        bool Playing { get; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes the service.
        /// Service can be used when the "Ready" property returns "true" value.
        /// </summary>
        void Init();

        /// <summary>
        /// Starts or resumes the current utterance.
        /// </summary>
        void Play();

        /// <summary>
        /// Pauses the current utterance.
        /// </summary>
        void Pause();

        /// <summary>
        /// Stops and clears the current utterance.
        /// </summary>
        void Stop();

        #endregion
    }
}
