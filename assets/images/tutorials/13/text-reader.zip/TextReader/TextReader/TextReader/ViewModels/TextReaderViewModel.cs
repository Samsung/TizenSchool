﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using TextReader.Models;
using Xamarin.Forms;

namespace TextReader.ViewModels
{
    /// <summary>
    /// Text Reader view model class.
    /// Provides abstraction of the main view.
    /// </summary>
    public class TextReaderViewModel : ViewModelBase
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// A command which resets the reader to default state.
        /// </summary>
        public ICommand ResetCommand { get; private set; }

        /// <summary>
        /// A command which toggles the repeat unit option state (on/off).
        /// </summary>
        public ICommand ToggleRepeatUnitCommand { get; private set; }

        /// <summary>
        /// A command which toggles the repeat all option state (on/off).
        /// </summary>
        public ICommand ToggleRepeatAllCommand { get; private set; }

        /// <summary>
        /// A command which changes the active paragraph to the previous one.
        /// </summary>
        public ICommand GoToPreviousUnitCommand { get; private set; }

        /// <summary>
        /// A command which changes the active paragraph to the next one.
        /// </summary>
        public ICommand GoToNextUnitCommand { get; private set; }

        /// <summary>
        /// A command which toogles the play state (playing, paused).
        /// </summary>
        public ICommand TogglePlayStateCommand { get; private set; }

        /// <summary>
        /// A command which saves the state of playing flag and pause the utterance.
        /// </summary>
        public ICommand SaveStateAndPauseCommand { get; private set; }

        /// <summary>
        /// A command which restores state of the playback.
        /// </summary>
        public ICommand RestoreStateCommand { get; private set; }

        #endregion

        #region methods

        /// <summary>
        /// TextReaderViewModel class constructor.
        /// </summary>
        public TextReaderViewModel()
        {
            InitCommands();
        }

        /// <summary>
        /// Initializes view model's commands.
        /// </summary>
        private void InitCommands()
        {
            ResetCommand = new Command(ExecuteReset, CanExecuteReset);
            ToggleRepeatUnitCommand = new Command(ExecuteToggleRepeatUnit);
            ToggleRepeatAllCommand = new Command(ExecuteToggleRepeatAll);
            GoToPreviousUnitCommand = new Command(ExecuteGoToPreviousUnit);
            GoToNextUnitCommand = new Command(ExecuteGoToNextUnit);
            TogglePlayStateCommand = new Command(ExecuteTogglePlayState);
            SaveStateAndPauseCommand = new Command(ExecuteSaveStateAndPause);
            RestoreStateCommand = new Command(ExecuteRestoreState);
        }

        /// <summary>
        /// Returns true if reset commmand can be executed, false otherwise.
        /// </summary>
        /// <returns>True if reset commmand can be executed, false otherwise</returns>
        private bool CanExecuteReset()
        {
            return false;
        }

        /// <summary>
        /// Reset command handler.
        /// Restores default states of the reader.
        /// </summary>
        private void ExecuteReset()
        {

        }

        /// <summary>
        /// Toggle repeat unit command handler.
        /// Toggles the state of repeat unit option.
        /// </summary>
        private void ExecuteToggleRepeatUnit()
        {

        }

        /// <summary>
        /// Toggle repeat all command handler.
        /// Toggles the state of the repeat all option.
        /// </summary>
        private void ExecuteToggleRepeatAll()
        {

        }

        /// <summary>
        /// Go to previous unit command handler.
        /// </summary>
        private void ExecuteGoToPreviousUnit()
        {

        }

        /// <summary>
        /// Go to next unit command handler.
        /// </summary>
        private void ExecuteGoToNextUnit()
        {


        }

        /// <summary>
        /// Toggle play state command handler.
        /// Uses TTS model to play or pause the utterance.
        /// </summary>
        private void ExecuteTogglePlayState()
        {

        }

        /// <summary>
        /// Save state and pause command handler.
        /// Saves state of the playing state and pauses the utterance.
        /// </summary>
        private void ExecuteSaveStateAndPause()
        {

        }

        /// <summary>
        /// Restore state command handler.
        /// Uses saved state of the playing flag to resume the utterance.
        /// </summary>
        private void ExecuteRestoreState()
        {

        }

        #endregion
    }
}
