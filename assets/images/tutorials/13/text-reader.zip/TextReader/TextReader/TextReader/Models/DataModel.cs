﻿using System.Collections.Generic;
using System.Linq;

namespace TextReader.Models
{
    /// <summary>
    /// Model class which provides input data (text) for the reader.
    /// </summary>
    class DataModel
    {
        #region fields

        /// <summary>
        /// Reader's input text as an array of paragraphs.
        /// </summary>
        private readonly string[] _paragraphs =
        {
            "Welcome to Tizen .NET!",

            "Tizen .NET is an exciting new way to develop applications for the Tizen operating" +
                " system, running on 50 million Samsung devices, including TVs, wearables," +
                " mobile, and many other IoT devices around the world.",

            "The existing Tizen frameworks are either C-based with no advantages of a managed" +
                " runtime, or HTML5-based with fewer features and lower performance than" +
                " the C-based solution.",

            "With Tizen .NET, you can use the C# programming language and the Common Language" +
                " Infrastructure standards and benefit from a managed runtime for faster" +
                " application development, and efficient, secure code execution."
        };

        #endregion

        #region properties

        /// <summary>
        /// Reader's input text as a list of paragraphs.
        /// </summary>
        public List<string> Paragraphs => _paragraphs.ToList();

        #endregion
    }
}
