﻿using System;
using Xamarin.Forms;

namespace TextReader.Models
{
    /// <summary>
    /// Model class which handles synthesizing text into speech.
    /// </summary>
    class TextToSpeechModel
    {
        #region properties

        /// <summary>
        /// Event fired when the utterance is completed.
        /// </summary>
        public event EventHandler UtteranceCompleted ;

        /// <summary>
        /// Flag indicating if service is ready to use.
        /// The model requires "Init" method to be called before use.
        /// </summary>
        public bool Ready => DependencyService.Get<ITextToSpeechService>().Ready;

        /// <summary>
        /// Currently used text.
        /// If text is changed, the current utterance is stopped immediately
        /// and new one starts then.
        /// </summary>
        public string Text
        {
            get { return DependencyService.Get<ITextToSpeechService>().Text; }
            set { DependencyService.Get<ITextToSpeechService>().Text = value; }
        }

        /// <summary>
        /// Flag indicating if text is read by the TTS engine.
        /// </summary>
        public bool Playing => DependencyService.Get<ITextToSpeechService>().Playing;

        #endregion

        #region methods

        /// <summary>
        /// The model class constructor.
        /// </summary>
        public TextToSpeechModel()
        {
            var service = DependencyService.Get<ITextToSpeechService>();

            service.UtteranceCompleted += ServiceOnUtteranceCompleted;
        }

        /// <summary>
        /// Handles utterance completed event from the service.
        /// Invokes UtteranceCompleted event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="eventArgs"></param>
        private void ServiceOnUtteranceCompleted(object sender, EventArgs eventArgs)
        {
            UtteranceCompleted?.Invoke(this, new EventArgs());
        }

        /// <summary>
        /// Initializes the model.
        /// The model instance can be used when the "Ready" property returns "true" value.
        /// </summary>
        public void Init()
        {
            DependencyService.Get<ITextToSpeechService>().Init();
        }

        /// <summary>
        /// Starts or resumes the current utterance.
        /// </summary>
        public void Play()
        {
            DependencyService.Get<ITextToSpeechService>().Play();
        }

        /// <summary>
        /// Pauses the current utterance.
        /// </summary>
        public void Pause()
        {
            DependencyService.Get<ITextToSpeechService>().Pause();
        }

        /// <summary>
        /// Stops and clears the current utterance.
        /// </summary>
        public void Stop()
        {
            DependencyService.Get<ITextToSpeechService>().Stop();
        }

        #endregion
    }
}
