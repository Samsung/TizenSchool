﻿using System;
using TextReader.ViewModels;
using Xamarin.Forms;
using Tizen.Xamarin.Forms.Extension;
using System.Linq;

namespace TextReader.Views
{
    /// <summary>
    /// Main page class.
    /// </summary>
    public partial class MainPage : ContentPage
    {
        #region methods

        /// <summary>
        /// Main page constructor.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}
