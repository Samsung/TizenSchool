﻿using System;
using System.Linq;
using TextReader.Models;
using TextReader.Tizen.Mobile.Services;
using Tizen.Uix.Tts;

[assembly: Xamarin.Forms.Dependency(typeof(TextToSpeechService))]
namespace TextReader.Tizen.Mobile.Services
{
    /// <summary>
    /// Tizen text-to-speech service which allows to synthesize a text into speech.
    /// </summary>
    class TextToSpeechService : ITextToSpeechService
    {
        #region properties

        /// <summary>
        /// Event fired when the utterance is completed.
        /// </summary>
        public event EventHandler UtteranceCompleted;

        /// <summary>
        /// Flag indicating if service is ready to use.
        /// The service requires "Init" method to be called before use.
        /// </summary>
        public bool Ready { get; }


        /// <summary>
        /// Currently used text.
        /// If text is changed, the current utterance is stopped immediately
        /// and new one starts then.
        /// </summary>
        public string Text { get; set; }


        /// <summary>
        /// Flag indicating if text is read by the TTS engine.
        /// </summary>
        public bool Playing { get; }

        #endregion

        #region methods

        /// <summary>
        /// The service constructor.
        /// </summary>
        public TextToSpeechService()
        {

        }

        /// <summary>
        /// Initializes the service.
        /// Service can be used when the "Ready" property returns "true" value.
        /// </summary>
        public void Init()
        {

        }

        /// <summary>
        /// Starts or resumes the current utterance.
        /// </summary>
        public void Play()
        {

        }

        /// <summary>
        /// Pauses the current utterance.
        /// </summary>
        public void Pause()
        {

        }

        /// <summary>
        /// Stops and clears the current utterance.
        /// </summary>
        public void Stop()
        {

        }

        #endregion
    }
}
