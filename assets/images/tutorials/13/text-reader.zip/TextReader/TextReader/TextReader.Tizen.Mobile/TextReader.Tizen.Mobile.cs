using System;
using ElmSharp;
using Xamarin.Forms.Platform.Tizen.Native;
using Extensions = Tizen.Xamarin.Forms.Extension;

namespace TextReader.Tizen.Mobile
{
    class Program : global::Xamarin.Forms.Platform.Tizen.FormsApplication
    {
        #region methods

        protected override void OnCreate()
        {
            base.OnCreate();
            Extensions.Renderer.TizenFormsExtension.Init();
            MainWindow.AvailableRotations = DisplayRotation.Degree_0;
            LoadApplication(new App());
        }

        static void Main(string[] args)
        {
            var app = new Program();
            global::Xamarin.Forms.Platform.Tizen.Forms.Init(app);
            app.Run(args);
        }

        #endregion
    }
}
