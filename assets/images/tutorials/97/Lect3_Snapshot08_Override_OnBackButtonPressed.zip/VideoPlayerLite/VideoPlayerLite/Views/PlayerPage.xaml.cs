﻿using Xamarin.Forms;

namespace VideoPlayerLite.Views
{
    public partial class PlayerPage : ContentPage
    {
        public static readonly BindableProperty FetchVideoCommandProperty = BindableProperty.Create("FetchVideoCommand", typeof(Command), typeof(PlayerPage), null);
        public Command FetchVideoCommand
        {
            get => (Command)GetValue(FetchVideoCommandProperty);
        }

        public static readonly BindableProperty PlayerStatusProperty = BindableProperty.Create("PlayerStatus", typeof(PlayerStatus), typeof(PlayerPage), PlayerStatus.Stopped, BindingMode.TwoWay);
        public PlayerStatus PlayerStatus
        {
            get => (PlayerStatus)GetValue(PlayerStatusProperty);
            set => SetValue(PlayerStatusProperty, value);
        }

        public PlayerPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            FetchVideoCommand.Execute(null);
        }

        protected override bool OnBackButtonPressed()
        {
            PlayerStatus = PlayerStatus.Paused;

            return base.OnBackButtonPressed();
        }
    }
}