﻿using System.ComponentModel;
using Tizen.Multimedia;
using VideoPlayerLite.Tizen.Tizen.TV.Renderer;
using VideoPlayerLite.Views;
using Xamarin.Forms.Platform.Tizen;

[assembly: ExportRenderer(typeof(MediaRenderingView), typeof(MediaRenderingViewRenderer))]
namespace VideoPlayerLite.Tizen.Tizen.TV.Renderer
{
    public class MediaRenderingViewRenderer : ViewRenderer<MediaRenderingView, MediaView>
    {
        protected override void OnElementChanged(ElementChangedEventArgs<MediaRenderingView> e)
        {
            base.OnElementChanged(e);

            if (Control == null)
            {
                SetNativeControl(new MediaView(Forms.Context.MainWindow));
            }
        }

        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
        }
    }
}