# Smartthings Device Manager Application

* forked from [SES/SmartthingsDevice](https://github.sec.samsung.net/SES/SmartThingsDevice/tree/ses_2.2_hackertone/sample_release/org.tizen.smartthings-device-manager-app)
