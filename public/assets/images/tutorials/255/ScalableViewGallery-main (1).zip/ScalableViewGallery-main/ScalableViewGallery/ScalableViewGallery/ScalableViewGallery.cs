﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Tizen.Applications;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Binding;
using Tizen.NUI.Components;
using Tizen.NUI.Xaml;

namespace ScalableViewGallery
{
    public class Gallery
    {
        public Gallery(string name, string fullName = null)
        {
            Name = name;
            FullName = fullName;
        }

        public string Name { get; set; }

        public string ViewLabel
        {
            get
            {
                return Name;
            }
        }

        public bool Selected { get; set; }

        internal string FullName { get; set; }
    }

    public class GalleryViewModel
    {
        public List<Tuple<string, string>> NamePool = new List<Tuple<string, string>>();

        public GalleryViewModel()
        {
            //CreateData();
        }

        public List<Gallery> CreateData()
        {
            GetXamlPages();

            List<Gallery> result = new List<Gallery>();
            foreach (var name in NamePool)
            {
                result.Add(new Gallery(name.Item1, name.Item2));
            }
            return result;
        }

        private void GetXamlPages()
        {
            Assembly assembly = this.GetType().Assembly;
            Type exampleType = assembly.GetType("ScalableViewGallery.IExample");

            foreach (Type type in assembly.GetTypes())
            {
                if (exampleType.IsAssignableFrom(type) && type.Name != "SampleMain" && this.GetType() != type && type.IsClass)
                {
                    Logger.Debug($"type.Name={type.Name}, type.FullName={type.FullName}");
                    NamePool.Add(new Tuple<string, string>(type.Name, type.FullName));
                }
            }
        }
    }

    public class ScalableViewGallery : NUIApplication
    {
        private Window window;
        private Navigator navigator;
        private ContentPage page;
        private CollectionView colView;
        private ItemSelectionMode selMode;
        private List<Gallery> testSource;
        private IExample currentExample = null;
        // private View mainView;

        private void Initialize()
        {
            Logger.Debug("");
            window = GetDefaultWindow();
            window.Title = "ScalableViewGallery";
            window.KeyEvent += OnKeyEvent;

            navigator = window.GetDefaultNavigator();
        }

        private void RunSample(string name)
        {
            IExample example = typeof(Program).Assembly?.CreateInstance(name) as IExample;

            Logger.Debug($"@@@ typeof(Program).Assembly={typeof(Program).Assembly}, name={name}");
            Console.WriteLine($"@@@ typeof(Program).Assembly={typeof(Program).Assembly}, name={name}");
             
            if (example != null)
            {
                example.Activate();
            }
            else
            {
                Logger.Debug($"@@@ examle is null!");
                Console.WriteLine($"@@@ examle is null!");
            }
            currentExample = example;
        }

        private void ExitSample()
        {
            currentExample?.Deactivate();
            currentExample = null;

            FullGC();
        }

        private void FullGC()
        {
            global::System.GC.Collect();
            global::System.GC.WaitForPendingFinalizers();
            global::System.GC.Collect();
        }

        public void OnSelectionChanged(object sender, SelectionChangedEventArgs ev)
        {
            Logger.Debug($"@@@ OnSelectionChanged() {ev.CurrentSelection}");
            Console.WriteLine($"@@@ OnSelectionChanged() {ev.CurrentSelection}");

            foreach (object item in ev.CurrentSelection)
            {
                Logger.Debug("enter foreach");
                if (item == null)
                {
                    Logger.Debug("break");
                    break;
                }

                var selItem = item as Gallery;
                if (selItem == null)
                {
                    Logger.Debug("break");
                    break;
                }
            
                Logger.Debug($"@@@ selItem.Name={selItem.Name}, selItem.FullName={selItem.FullName}");
                Console.WriteLine($"@@@ selItem.Name={selItem.Name}, selItem.FullName={selItem.FullName}");
                RunSample(selItem.FullName);
                colView.SelectedItem = null;
            }
        }

        private void SetMainPage()
        {
            Logger.Debug("");
            var appBar = new AppBar()
            {
                Title = "Scalable View Gallery",
                AutoNavigationContent = false,
            };

            var appBarStyle = ThemeManager.GetStyle("Tizen.NUI.Components.AppBar");

            var pageContent = new View()
            {
                Layout = new LinearLayout()
                {
                    LinearOrientation = LinearLayout.Orientation.Vertical,
                },
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
            };

            testSource = new GalleryViewModel().CreateData();
            selMode = ItemSelectionMode.SingleAlways;
            var myTitle = new DefaultTitleItem()
            {
                Text = "View Cases",
                WidthSpecification = LayoutParamPolicies.MatchParent,
            };

            colView = new CollectionView()
            {
                ItemsSource = testSource,
                ItemsLayouter = new LinearLayouter(),
                ItemTemplate = new DataTemplate(() =>
                {
                    DefaultLinearItem item = new DefaultLinearItem()
                    {
                        WidthSpecification = LayoutParamPolicies.MatchParent,
                    };
                    item.Label.SetBinding(TextLabel.TextProperty, "ViewLabel");
                    item.Label.HorizontalAlignment = HorizontalAlignment.Begin;
                    return item;
                }),
                Header = myTitle,
                ScrollingDirection = ScrollableBase.Direction.Vertical,
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
                SelectionMode = selMode,
            };
            colView.SelectionChanged += OnSelectionChanged;

            pageContent.Add(colView);

            page = new ContentPage()
            {
                AppBar = appBar,
                Content = pageContent,
            };
            navigator.Push(page);
        }

        override protected void OnCreate()
        {
            Logger.Debug("");
            base.OnCreate();

            // NOTE To use theme.xaml, uncomment below line.
            // ThemeManager.ApplyTheme(new Theme(Tizen.Applications.Application.Current.DirectoryInfo.Resource + "theme/theme.xaml"));

            //window = GetDefaultWindow();
            //window.KeyEvent += OnKeyEvent;

            Initialize();
            SetMainPage();

            //ScrollableBase scrollableBase = new ScrollableBase();
            //scrollableBase.WidthSpecification = LayoutParamPolicies.MatchParent;
            //scrollableBase.HeightSpecification = LayoutParamPolicies.MatchParent;
            //scrollableBase.ScrollingDirection = ScrollableBase.Direction.Vertical;

            //window.Add(scrollableBase);

            //MainView mainView = new MainView();
            //mainView.WidthSpecification = LayoutParamPolicies.MatchParent;
            //mainView.HeightSpecification = LayoutParamPolicies.MatchParent;

            //window.Add(mainView);

        }



        private void OnKeyEvent(object sender, Window.KeyEventArgs e)
        {
            //if (e.Key.State == Key.StateType.Down && (e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "Escape"))
            //{
            //    Exit();
            //}

            if (e.Key.State == Key.StateType.Up)
            {
                if (e.Key.KeyPressedName == "Escape" || e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "BackSpace")
                {
                    if (null != currentExample)
                    {
                        ExitSample();
                    }
                    else
                    {
                        Exit();
                    }
                }
            }
        }

        override protected void OnPause()
        {
            Logger.Debug("");
            base.OnPause();
        }

        override protected void OnResume()
        {
            Logger.Debug("");
            base.OnResume();
        }

        override protected void OnTerminate()
        {
            Logger.Debug("");
            base.OnTerminate();
        }

        override protected void OnAppControlReceived(AppControlReceivedEventArgs e)
        {
            base.OnAppControlReceived(e);
        }
    }
}
