﻿using System;
using Tizen.NUI;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.MusicView
{
    internal class MusicView : IExample
    {
        private Window window;
        private MusicViewPage page;

        public void Activate()
        {
            Logger.Debug("");
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Activate()");
            Console.WriteLine($"@@@ this.GetType().Name={this.GetType().Name}, Activate()");

            window = NUIApplication.GetDefaultWindow();
            page = new MusicViewPage();

            /* navigator를 쓰기 위해서 contentPage로 작성되어야 함 */
            //window.Add(page);
            window.GetDefaultNavigator().Push(page);
        }

        public void Deactivate()
        {
            Logger.Debug("");
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Deactivate()");
            Console.WriteLine($"@@@ this.GetType().Name={this.GetType().Name}, Deactivate()");
            
            /* navigator를 쓰기 위해서 contentPage로 작성되어야 함 */
            //page.Unparent();
            //page.Dispose();
            window.GetDefaultNavigator().Pop();
            page = null;
        }
    }
}
