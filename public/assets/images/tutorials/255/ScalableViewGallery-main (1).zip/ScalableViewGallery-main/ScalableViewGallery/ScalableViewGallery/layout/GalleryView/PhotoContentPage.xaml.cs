﻿using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.GalleryView
{
    public partial class PhotoContentPage : View
    {
        public PhotoContentPage()
        {
            InitializeComponent();

            for (int i = 0; i < 10; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox1.Add(imageBoxPage);
            }

            for (int i = 0; i < 8; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox2.Add(imageBoxPage);
            }

            for (int i = 0; i < 2; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox3.Add(imageBoxPage);
            }

        }
    }
}
