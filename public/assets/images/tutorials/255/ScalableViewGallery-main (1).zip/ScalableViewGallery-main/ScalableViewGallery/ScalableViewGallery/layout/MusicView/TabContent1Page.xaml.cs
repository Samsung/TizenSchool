﻿using System.Collections.Generic;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class TabContent1Page : View
    {
        private readonly int ItemCount = 10;
        private List<ListItemPage> items;

        public TabContent1Page()
        {
            InitializeComponent();

            items = new List<ListItemPage>();

            for (int i = 0; i < ItemCount; ++i)
            {
                ListItemPage listItemPage = new ListItemPage();
                items.Add(listItemPage);
                Scoller.Add(items[i]);
            }

            TrackCount.Text = ItemCount.ToString() + " tracks";
        }
    }
}
