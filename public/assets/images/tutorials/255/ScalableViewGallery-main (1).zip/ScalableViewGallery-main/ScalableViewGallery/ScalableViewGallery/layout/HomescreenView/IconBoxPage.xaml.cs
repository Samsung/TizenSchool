﻿using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.HomescreenView
{
    public partial class IconBoxPage : View
    {
        public IconBoxPage()
        {
            InitializeComponent();
        }
    }
}
