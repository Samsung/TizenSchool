﻿using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class QuickSettingBoxPage : View
    {
        public QuickSettingBoxPage()
        {
            InitializeComponent();
        }
    }
}
