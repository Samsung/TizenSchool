﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class MusicViewPage : ContentPage
    {
        private void CreateTabView()
        {
            TabView tabView = new TabView()
            {
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
            };

            int tabCount = 0;
            TabButton tabButton;
            View tabContent;

            for (int i = 1; i < 5; ++i)
            {
                tabButton = new TabButton()
                {
                    Text = "Tab" + i.ToString(),
                };

                tabContent = new TextLabel()
                {
                   // Text = "Content" + i.ToString(),
                    BackgroundColor = Color.White,
                    WidthSpecification = LayoutParamPolicies.MatchParent,
                    HeightSpecification = LayoutParamPolicies.MatchParent,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                };

                tabView.AddTab(tabButton, tabContent);
                tabCount++;

                if (i == 1)
                {
                    // tabContent가 TextLable로 Layout 설정이 되어있기 때문에 다시 Layout 설정을 한 번 해줘야 한다 (수정 예정)
                    LinearLayout linearLayout = new LinearLayout();
                    linearLayout.LinearOrientation = LinearLayout.Orientation.Horizontal;
                    linearLayout.LinearAlignment = LinearLayout.Alignment.Begin;
                    tabContent.Layout = linearLayout;

                    TabContent1Page tabContent1Page = new TabContent1Page();
                    tabContent.Add(tabContent1Page);
                }
            }
            LibraryContent.Add(tabView);
        }

        private void setMiniPlayerHeight()
        {
            // 실제 ContentView의 크기를 가져와서 계산해야함
            // ContentView의 width가 mini player 보다 크면 100
            // ContentView의 width가 mini player 보다 작으면 200
            // => 렌더링이 끝난 뒤 사이즈를 가져와야해서 생성자에서는 0,0을 가져옴
            // => 콜백으로 등록해야함
            //Size2D contentViewSize = new Size2D();
            //contentViewSize = (Size2D)ContentView.Size2D.Clone();

            //float w = contentViewSize.Width;
            //float h = contentViewSize.Height;

            //Logger.Debug($"contentViewSize w={w}, h={h}");

            // 임시 코드
            Window window = NUIApplication.GetDefaultWindow();

            bool isLandscape = window.Size.Width > window.Size.Height ? true : false;
            Logger.Debug($"window size w={window.Size.Width}, h={window.Size.Height}");

            if (isLandscape)
            {
                MiniPlayerContent.HeightSpecification = 100;
            }
            else
            {
                MiniPlayerContent.HeightSpecification = 200;
            }
        }

        public MusicViewPage()
        {
            InitializeComponent();

            setMiniPlayerHeight();

            CreateTabView();
        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }
    }
}
