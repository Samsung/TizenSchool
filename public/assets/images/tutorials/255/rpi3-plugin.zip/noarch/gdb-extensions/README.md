# GDB dashboard

GDB dashboard is a standalone `.gdbinit` file written using the [Python API][] that enables a modular interface showing relevant information about the program being debugged. Its main goal is to reduce the number of GDB commands needed to inspect the status of current program thus allowing the developer to primarily focus on the control flow.

![Screenshot](https://raw.githubusercontent.com/wiki/cyrus-and/gdb-dashboard/Screenshot.png)

[Python API]: https://sourceware.org/gdb/onlinedocs/gdb/Python-API.html

## Quickstart

Just place `.gdbinit` in your home directory, for example with:

Then debug as usual, the dashboard will appear automatically every time the inferior program stops.

Keep in mind that no GDB command has been redefined, instead all the features are available via the main `dashboard` command (see `help dashboard`).


## Usage

#### Enable gdb-dashboard

When you run gdb, dashboard is disabled. If you want to use gdb-dashboard, you must set enable-command below :
```bash
>>> dashboard -enabled
The dashboard is disabled
>>> dashboard -enabled on
>>> dashboard -enabled
The dashboard is enabled
```



#### List of dashboard subcommands
```bash
>>> help dashboard
Redisplay the dashboard.

List of dashboard subcommands:

dashboard -configuration -- Dump or save the dashboard configuration
dashboard -enabled -- Enable or disable the dashboard
dashboard -layout -- Set or show the dashboard layout
dashboard -output -- Set the output file/TTY for the whole dashboard or single modules
dashboard -style -- Access the stylable attributes
dashboard assembly -- Configure the assembly module
dashboard breakpoints -- Configure the breakpoints module
dashboard expressions -- Configure the expressions module
dashboard history -- Configure the history module
dashboard memory -- Configure the memory module
dashboard registers -- Configure the registers module
dashboard source -- Configure the source module
dashboard stack -- Configure the stack module
dashboard threads -- Configure the threads module
dashboard variables -- Configure the variables module

Type "help dashboard" followed by dashboard subcommand name for full documentation.
Type "apropos word" to search for commands related to "word".
Command name abbreviations are allowed if unambiguous.
```

#### Multiple terminal

The whole dashboard or individual modules can be displayed in a different terminal, this is useful since the vertical space is often limited, plus in this way the GDB prompt and program I/O are separated from the dashboard.

The `-output` command applies to both the dashboard and individual modules and allows to specify the output file of each component. For example to display the dashboard in another terminal and the assembly and source modules in yet other terminals on their own use:

1. Please check terminal tty used as dashboard

*Viewer terminal*
```bash
$tty
/dev/pts/6
```

2. Set output tty in gdb
*gdb terminal*
```bash
$gdb {program}
>>> dashboard -enabled on
>>> dashboard -output /dev/pts/6
```
