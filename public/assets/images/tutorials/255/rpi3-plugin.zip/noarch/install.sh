#
# Add only noarch packages here
#

# change to local directory
LOCALPATH=`dirname $0`
cd ${LOCALPATH}

echo -e "\n\n----- Push noarch rpm and firmware files (sdb push)-----"

# Firmware for wifi-mesh
sdb push connectivity/wifi-mesh/* /usr/lib/firmware/

#tmpdir="/tmp/plugin_noarch"
#sdb shell mkdir -p $tmpdir

# noarch packages

#echo -e "\n\n----- Install noarch rpm files -----"
#sdb shell rpm -Uvh --force --nodeps $tmpdir/*.rpm
#sdb shell rm -rf $tmpdir


echo -e "\n\n----- Install GDB Extension -----"
sdb -d push gdb-extensions/gdb-dashboard /root/.gdbinit
sdb -d push gdb-extensions/gdb-heap /root/.gdb-heap
sdb -d push gdb-extensions/gdb-stl-viewer /root/.gdb-stl-viewer

#
# Do not add reboot command here, it will be done in the upper layer
#
