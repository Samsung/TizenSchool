# Plugins for RPI 4 & 3 targets
#
# Note: RPI 4 & 3 work with both armv7l and aarch64, so you need to consider both cases.
#
# If the file is for aarch64, then please add it to 64bit directory.
# If the file is for armv7l, then please add it to 32bit directory.
# If the file is independent from armv7l or aarch64, then please add it to noarch directory.
# 
