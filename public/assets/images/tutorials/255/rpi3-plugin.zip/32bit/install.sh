#
# Add only ARM 32bit packages here
#

# change to local directory
LOCALPATH=`dirname $0`
cd ${LOCALPATH}

# 32bit pacakges
echo -e "\n\n----- ARM 32bit rpm files -----"

# Uninstall not required packages
sdb shell rpm -e --nodeps wlandrv-plugin-tizen

echo -e "\n\n----- Push library files (sdb push) -----"
tmpdir="/tmp/tmp_plugin"
sdb shell mkdir -p $tmpdir

sdb push connectivity/*.rpm $tmpdir

echo -e "\n\n----- Install libraries -----"
sdb shell rpm -Uvh --force --nodeps $tmpdir/*.rpm

# remove tmp directory
sdb shell rm -rf $tmpdir

#
# Do not add reboot command here, it will be done in the upper layer
#
