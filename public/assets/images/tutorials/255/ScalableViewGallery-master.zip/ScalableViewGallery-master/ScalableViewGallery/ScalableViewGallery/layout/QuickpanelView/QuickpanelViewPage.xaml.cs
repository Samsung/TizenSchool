﻿using System.Collections.Generic;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;
// CollectionView 사용 시 필요
using Tizen.NUI.Binding;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class QuickpanelViewPage : ContentPage
    {
       
        private void CreateColView()
        {
            /*BindingContext = new TestSourceModel(10);

            ColView.ItemTemplate = new DataTemplate(() =>
            {
                var item = new DefaultLinearItem()
                {
                    WidthSpecification = LayoutParamPolicies.MatchParent,
                };
                item.Label.SetBinding(TextLabel.TextProperty, "Name");

                var icon = new View()
                {
                    WidthSpecification = 60,
                    HeightSpecification = 60
                };
                icon.SetBinding(BackgroundColorProperty, "BgColor");
                item.Icon = icon;

                return item;
            });*/
        }

        private readonly int ItemCount = 10;
        private List<NotiItemPage> items;

        private void CreateNotiList()
        {
            items = new List<NotiItemPage>();

            for (int i = 0; i < ItemCount; ++i)
            {
                NotiItemPage notiItemPage = new NotiItemPage();
                items.Add(notiItemPage);
                NotiScroller.Add(items[i]);
            }

            NotiNum.Text = "Notification(" + ItemCount.ToString() + ")";
        }

        public QuickpanelViewPage()
        {
            InitializeComponent();

            //CreateColView();
            CreateNotiList();

        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }
    }
}
