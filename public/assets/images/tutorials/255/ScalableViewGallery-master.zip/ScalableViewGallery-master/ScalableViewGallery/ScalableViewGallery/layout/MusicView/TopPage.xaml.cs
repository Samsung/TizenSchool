﻿using System;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class TopPage : View
    {
        public TopPage()
        {
            InitializeComponent();
        }
    }
}
