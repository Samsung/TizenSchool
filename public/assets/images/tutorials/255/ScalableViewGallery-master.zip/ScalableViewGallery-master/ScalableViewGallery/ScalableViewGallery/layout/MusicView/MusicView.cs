﻿using System;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.MusicView
{
    internal class MusicView : IExample
    {
        private Window window;
        private MusicViewPage page;

        private View rootView, leftMargin, rightMargin;
        private View contentView, content1, content2;
        private TabView tabView;
        private View flexView;

        public void Activate()
        {
            Logger.Debug("");
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Activate()");
            Console.WriteLine($"@@@ this.GetType().Name={this.GetType().Name}, Activate()");

            window = NUIApplication.GetDefaultWindow();
            page = new MusicViewPage();

            /* navigator를 쓰기 위해서 contentPage로 작성되어야 함 */
            //window.Add(page);
            window.GetDefaultNavigator().Push(page);

            //setPage();

            //page = new MusicViewPage();
            //window.Add(page);

        }

        public void Deactivate()
        {
            Logger.Debug("");
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Deactivate()");
            Console.WriteLine($"@@@ this.GetType().Name={this.GetType().Name}, Deactivate()");
            
            /* navigator를 쓰기 위해서 contentPage로 작성되어야 함 */
            //page.Unparent();
            //page.Dispose();
            window.GetDefaultNavigator().Pop();
            page = null;
        }

        private void setPage()
        {
            CreateRootView();
            CreateContentView();
            CreateTabView();
        }

        private void CreateRootView()
        {
            // root veiw (linear layout)
            rootView = new View();
            rootView.Size = new Size(window.Size);

            rootView.PositionUsesPivotPoint = true;
            rootView.ParentOrigin = ParentOrigin.Center;
            rootView.PivotPoint = PivotPoint.Center;
            rootView.WidthResizePolicy = ResizePolicyType.FillToParent;
            rootView.HeightResizePolicy = ResizePolicyType.FillToParent;

            LinearLayout rootLayout = new LinearLayout();
            rootLayout.LinearAlignment = LinearLayout.Alignment.Begin;
            rootLayout.LinearOrientation = LinearLayout.Orientation.Horizontal;

            rootView.Layout = rootLayout;

            window.Add(rootView);

            // left margin
            leftMargin = new View();
            leftMargin.WidthSpecification = LayoutParamPolicies.MatchParent;
            leftMargin.HeightSpecification = LayoutParamPolicies.MatchParent;
            leftMargin.Weight = 0.05f;

            // content view (linear layout)
            contentView = new View();
            contentView.WidthSpecification = LayoutParamPolicies.MatchParent;
            contentView.HeightSpecification = LayoutParamPolicies.MatchParent;
            contentView.Weight = 0.9f;

            LinearLayout contentLayout = new LinearLayout();
            contentLayout.LinearAlignment = LinearLayout.Alignment.Begin;
            contentLayout.LinearOrientation = LinearLayout.Orientation.Vertical;

            contentView.Layout = contentLayout;

            // right margin
            rightMargin = new View();
            rightMargin.WidthSpecification = LayoutParamPolicies.MatchParent;
            rightMargin.HeightSpecification = LayoutParamPolicies.MatchParent;
            rightMargin.Weight = 0.05f;

            rootView.Add(leftMargin);
            rootView.Add(contentView);
            rootView.Add(rightMargin);
        }

        private void CreateContentView()
        {
            content1 = new View();
            content1.WidthSpecification = LayoutParamPolicies.MatchParent;
            content1.HeightSpecification = LayoutParamPolicies.MatchParent;
            content1.Weight = 0.09f;

            content2 = new View();
            content2.WidthSpecification = LayoutParamPolicies.MatchParent;
            content2.HeightSpecification = LayoutParamPolicies.MatchParent;
            content2.Weight = 0.01f;

            contentView.Add(content1);
            contentView.Add(content2);
        }

        private void CreateTabView()
        {
            tabView = new TabView()
            {
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
            };

            int tabCount = 0;
            TabButton tabButton;
            View tabContent;

            for (int i = 1; i <= 5; ++i)
            {
                tabButton = new TabButton()
                {
                    Text = "Tab" + i.ToString(),
                };

                tabContent = new TextLabel()
                {
                    Text = "Content" + i.ToString(),
                    BackgroundColor = Color.White,
                    WidthSpecification = LayoutParamPolicies.MatchParent,
                    HeightSpecification = LayoutParamPolicies.MatchParent,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                };

                tabView.AddTab(tabButton, tabContent);
                tabCount++;

                if (i == 1)
                {
                    LinearLayout tabContentLayout = new LinearLayout();
                    tabContentLayout.LinearAlignment = LinearLayout.Alignment.Begin;
                    tabContentLayout.LinearOrientation = LinearLayout.Orientation.Vertical;

                    tabContent.Layout = tabContentLayout;

                    CreatetabContentView(tabContent);
                }
            }
            content1.Add(tabView);
        }

        private void CreatetabContentView(View parent)
        {
            // top page
            TopPage topPage = new TopPage();
            topPage.Weight = 0.1f;
            topPage.WidthSpecification = LayoutParamPolicies.MatchParent;
            topPage.HeightSpecification = LayoutParamPolicies.MatchParent;

            parent.Add(topPage);

            // flex view
            flexView = new View();
            flexView.WidthSpecification = LayoutParamPolicies.MatchParent;
            flexView.HeightSpecification = LayoutParamPolicies.MatchParent;
            flexView.Weight = 0.9f;

            ScrollableBase scrollableBase = new ScrollableBase();
            scrollableBase.WidthSpecification = LayoutParamPolicies.MatchParent;
            scrollableBase.HeightSpecification = LayoutParamPolicies.MatchParent;
            scrollableBase.ScrollingDirection = ScrollableBase.Direction.Vertical;

            flexView.Add(scrollableBase);

            MusicViewPage musicViewPage = new MusicViewPage();
            musicViewPage.WidthSpecification = LayoutParamPolicies.MatchParent;
            musicViewPage.HeightSpecification = LayoutParamPolicies.MatchParent;

            scrollableBase.Add(musicViewPage);

            parent.Add(flexView);

        }
    }
}
