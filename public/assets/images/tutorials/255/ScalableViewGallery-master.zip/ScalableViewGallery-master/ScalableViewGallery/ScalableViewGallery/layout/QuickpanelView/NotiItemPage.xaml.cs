﻿using System;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class NotiItemPage : View
    {
        public NotiItemPage()
        {
            InitializeComponent();
        }
    }
}
