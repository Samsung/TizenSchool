﻿using System;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using System.Collections.Generic;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class ListItemClickedEventArgs : EventArgs
    {
        public string ClickedItemText;
        public int Index;

        public ListItemClickedEventArgs(string text, int index)
        {
            ClickedItemText = text;
            Index = index;
        }
    }

    public class ListItem : TextLabel
    {
        private int Index = -1;
        public event EventHandler<ListItemClickedEventArgs> Clicked;

        public ListItem(string text, int index)
        {
            Text = text;
            Index = index;
            TouchEvent += OnTouchEvent;
            Size2D = new Tizen.NUI.Size2D(570, 50);
            BackgroundColor = Color.White;
            PixelSize = 22;
        }

        private bool OnTouchEvent(object sender, TouchEventArgs args)
        {
            if (args.Touch.GetState(0) == Tizen.NUI.PointStateType.Finished)
            {
                Clicked.Invoke(this, new ListItemClickedEventArgs(Text, Index));
            }

            return true;
        }

        public void ChangeSelectionState(bool selected)
        {
            Logger.Debug("Clicked");
            if (selected == true)
            {
                Logger.Debug("slected");
                BackgroundColor = new Color(0.5f, 0.5f, 0.5f, 0.5f); ;
            }
            else
            {
                Logger.Debug("not slected");
                BackgroundColor = Color.White;
            }
        }
    }

    public partial class MusicViewPage : ContentPage
    {
        private readonly int ItemCount = 20;
        private int SelectedItemIndex = -1;
        private List<ListItem> items;

        public MusicViewPage()
        {
            InitializeComponent();
            items = new List<ListItem>();

            for (int i = 0; i < ItemCount; ++i)
            {
                // ListItemPage를 쓰면 스크롤이 안됨
                //ListItemPage listItemPage = new ListItemPage();
                //ListView.Add(listItemPage);

                items.Add(new ListItem(string.Format("{0}th list item", i + 1), i));
                items[i].Clicked += OnClicked;
                ListView.Add(items[i]);
            }

            TrackCount.Text = ItemCount.ToString() + " tracks";
        }
        private void OnClicked(object sender, ListItemClickedEventArgs args)
        {
            //TrackCount.Text = args.ClickedItemText;

            if (SelectedItemIndex != -1)
            {
                items[SelectedItemIndex].ChangeSelectionState(false);
            }

            Logger.Debug($"selected item={args.Index}");
            SelectedItemIndex = args.Index;
            items[SelectedItemIndex].ChangeSelectionState(true);

        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }
    }
}
