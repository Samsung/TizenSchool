﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace Browser
{
    public class MainPageViewModel : INotifyPropertyChanged
    {

        // Command for Hidden button
        public Command HiddenSettingCommand { get; set; }

        // FlyBook WebUrl
        private string _webViewUrl;
        public string WebViewUrl
        {
            get => _webViewUrl;
            set {
                _webViewUrl = value;
                OnPropertyChanged();
            }
        }

        // Constructor
        public MainPageViewModel()
        {
            // Basic Test URL
            WebViewUrl = "http://flybookscreen.flybook.kr/";

            // This feature is disalbed because of keyboard issue.
            //HiddenSettingCommand = new Command(displaySetting);
        }

        private async void displaySetting()
        {
            string subdomain = await Application.Current.MainPage.DisplayPromptAsync("FlyBook", "Please input a subdomain.");
            if(!string.IsNullOrEmpty(subdomain))
                WebViewUrl = "http://" + subdomain + ".bookscreen.flybook.kr/";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
