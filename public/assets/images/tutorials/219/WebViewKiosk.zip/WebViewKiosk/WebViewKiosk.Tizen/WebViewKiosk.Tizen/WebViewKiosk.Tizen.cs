using System;
using Xamarin.Forms;

namespace WebViewKiosk.Tizen
{
    class Program : global::Xamarin.Forms.Platform.Tizen.FormsApplication
    {
        protected override void OnCreate()
        {
            base.OnCreate();

            // Hide the indicator
            MainWindow.IndicatorMode = ElmSharp.IndicatorMode.Hide;

            // Rotate to Portrait
            MainWindow.SetRotation(90, true);

            LoadApplication(new WebViewKiosk.App());
        }

        static void Main(string[] args)
        {
            var app = new Program();
            Forms.Init(app);
            app.Run(args);
        }
    }
}
