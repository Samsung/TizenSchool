﻿namespace AppNavigation.Tizen.Mobile.Views
{
    /// <summary>
    /// Blue page class.
    /// </summary>
    public partial class BluePage
    {
        #region methods

        /// <summary>
        /// Blue page constructor.
        /// </summary>
        public BluePage ()
        {
            InitializeComponent();
        }

        #endregion
    }
}