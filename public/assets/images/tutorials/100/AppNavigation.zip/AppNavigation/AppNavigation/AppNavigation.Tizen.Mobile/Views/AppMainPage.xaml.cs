﻿namespace AppNavigation.Tizen.Mobile.Views
{
	/// <summary>
    /// Main page class.
    /// </summary>
	public partial class AppMainPage
	{
        #region methods

	    /// <summary>
	    /// Main page constructor
	    /// </summary>
	    public AppMainPage()
	    {
	        InitializeComponent();
	    }

        #endregion
    }
}