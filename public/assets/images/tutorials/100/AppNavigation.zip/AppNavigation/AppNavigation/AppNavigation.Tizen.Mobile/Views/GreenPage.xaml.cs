﻿namespace AppNavigation.Tizen.Mobile.Views
{
    /// <summary>
    /// Green page class.
    /// </summary>
    public partial class GreenPage
	{
	    #region methods

        /// <summary>
        /// Green page constructor.
        /// </summary>
        public GreenPage ()
		{
			InitializeComponent();
		}

	    #endregion
    }
}