﻿namespace AppNavigation.Tizen.Mobile.Views
{
    /// <summary>
    /// Red page class.
    /// </summary>
	public partial class RedPage
	{
	    #region methods

        /// <summary>
        /// Red page constructor.
        /// </summary>
        public RedPage ()
		{
			InitializeComponent();
		}

	    #endregion
    }
}