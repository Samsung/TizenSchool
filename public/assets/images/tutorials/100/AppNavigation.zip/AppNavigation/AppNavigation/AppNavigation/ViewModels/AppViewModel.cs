﻿namespace AppNavigation.ViewModels
{
    /// <summary>
    /// Main view model for application.
    /// </summary>
    public class AppViewModel : ViewModelBase
    {
    }
}
