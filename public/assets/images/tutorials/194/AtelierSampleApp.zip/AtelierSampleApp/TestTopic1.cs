﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Net;
using System.Net.Http;
using System.IO;

namespace AtelierSampleApp
{
    using tlog = Tizen.Log;
    class TestTopic1
    {
        static string tag = "ATELIER";


        string m_sensorDataFile;
        string m_url;

        public TestTopic1(string datafile, string url)
        {
            m_sensorDataFile = datafile;
            m_url = url;
        }


        public void Testcase()
        {
            string m_postData = "";
            string m_nowString = "";
            int m_deviceID = 9001;

            tlog.Debug(tag, "Send Data Start!!!");
            tlog.Debug(tag, "");

            string[] readString = File.ReadAllLines(m_sensorDataFile);
            tlog.Debug(tag, "# of readString : " + readString.Length.ToString());

            foreach (string show in readString)
            {
                m_nowString = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                m_postData = "{\"DEVICE_ID\" : " + m_deviceID + ", \"SENSOR_INPUT_TIME\" : \"" + m_nowString + "\", " + show + "\"}";
                tlog.Debug(tag, m_postData);

                try
                {
                    ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] data = Encoding.GetEncoding("UTF-8").GetBytes(m_postData);

                    WebRequest request = WebRequest.Create(m_url);

                    request.Method = "POST";
                    request.ContentType = "application/json; charset=UTF-8";
                    request.ContentLength = data.Length;

                    Stream stream = request.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    stream.Close();

                    WebResponse response = request.GetResponse();
                    stream = response.GetResponseStream();

                    StreamReader sr = new StreamReader(stream);
                    string responseFromServer = sr.ReadToEnd();
                    tlog.Debug(tag, responseFromServer);

                    sr.Close();
                    stream.Close();
                    response.Close();
                }
                catch (Exception ex)
                {
                    tlog.Debug(tag, "Error : " + ex.Message);
                }
                Thread.Sleep(1000);
            }
        }
    }
}
