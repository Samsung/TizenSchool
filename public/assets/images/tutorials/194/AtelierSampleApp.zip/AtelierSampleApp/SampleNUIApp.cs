﻿using System;

using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;


using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
//using System.Drawing;
using System.Linq;
using System.Text;

using System.Threading;
using System.Threading.Tasks;


namespace AtelierSampleApp
{
    using tlog = Tizen.Log;

    class Program : NUIApplication
    {
        static string tag = "ATELIER";

        protected override void OnCreate()
        {
            base.OnCreate();
            Initialize();
        }

        TextLabel m_text;


        void Initialize()
        {
            Window.Instance.KeyEvent += OnKeyEvent;

            m_text = new TextLabel("Atelier Test Sample");
            m_text.HorizontalAlignment = HorizontalAlignment.Center;
            m_text.VerticalAlignment = VerticalAlignment.Center;
            m_text.TextColor = Color.Blue;
            m_text.PointSize = 12.0f;
            m_text.Position = new Position(0, 100);
            Window.Instance.GetDefaultLayer().Add(m_text);

            Animation animation = new Animation(2000);
            animation.AnimateTo(m_text, "Orientation", new Rotation(new Radian(new Degree(180.0f)), PositionAxis.X), 0, 500);
            animation.AnimateTo(m_text, "Orientation", new Rotation(new Radian(new Degree(0.0f)), PositionAxis.X), 500, 1000);
            animation.Looping = true;
            animation.Play();

            Button button1 = new Button();
            button1.BackgroundImage = ApplicationInfo.SharedResourcePath + "rectangle_point_btn_normal.png";
            button1.BackgroundImageBorder = new Rectangle(4, 4, 5, 5);
            button1.TextColor = Color.Black;
            button1.Size = new Size(300, 80);
            button1.Position = new Position(100, 300);
            button1.TextLabel.Text = "Test Topic1";
            Window.Instance.GetDefaultLayer().Add(button1);
            button1.Clicked += OnClick_Topic1;

            Button button2 = new Button();
            button2.BackgroundImage = ApplicationInfo.SharedResourcePath + "rectangle_point_btn_normal.png";
            button2.BackgroundImageBorder = new Rectangle(4, 4, 5, 5);
            button2.TextColor = Color.Black;
            button2.Size = new Size(300, 80);
            button2.Position = new Position(100, 400);
            button2.TextLabel.Text = "Test Topic2";
            Window.Instance.GetDefaultLayer().Add(button2);
            button2.Clicked += OnClick_Topic2;

            Button exitButton = new Button();
            exitButton.BackgroundImage = ApplicationInfo.SharedResourcePath + "rectangle_point_btn_normal.png";
            exitButton.BackgroundImageBorder = new Rectangle(4, 4, 5, 5);
            exitButton.TextColor = Color.Black;
            exitButton.Size = new Size(300, 80);
            exitButton.Position = new Position(100, 500);
            exitButton.TextLabel.Text = "EXIT";
            Window.Instance.GetDefaultLayer().Add(exitButton);
            exitButton.Clicked += OnClick_Exit;
        }

        public void OnKeyEvent(object sender, Window.KeyEventArgs e)
        {
            if (e.Key.State == Key.StateType.Down)
            {
                tlog.Debug(tag, e.Key.KeyPressedName + " pressed!");

                if (e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "Escape")
                {
                    Exit();
                }
            }
        }

        private void OnClick_Topic1(object sender, ClickedEventArgs e)
        {
            tlog.Debug(tag, "Topic1 Button is clicked!");

            string url = "http://183.109.124.73:15301";
            string sensorDataFile = "sensor_data_temp.txt";

            string resourcepath = ApplicationInfo.SharedResourcePath;
            tlog.Debug(tag, "resourcepath : " + resourcepath);
            TestTopic1 test = new TestTopic1(resourcepath + sensorDataFile, url);

            ThreadStart ts = new ThreadStart(test.Testcase);
            Thread testThread = new Thread(ts);
            testThread.Name = "Topic1";

            testThread.Start();
        }

        private void OnClick_Topic2(object sender, ClickedEventArgs e)
        {
            tlog.Debug(tag, "Topic2 Button is clicked!");

            string url = "http://183.109.124.73:18002/model/predict_images/images";
            string imagefile = "giantPanda.jpeg";

            string resourcepath = ApplicationInfo.SharedResourcePath;
            tlog.Debug(tag, "resourcepath : " + resourcepath);
            TestTopic2 test = new TestTopic2(resourcepath + imagefile, url);

            ThreadStart ts = new ThreadStart(test.Testcase);
            Thread testThread = new Thread(ts);
            testThread.Name = "Topic2";

            testThread.Start();
        }
        private void OnClick_Exit(object sender, ClickedEventArgs e)
        {
            tlog.Debug(tag, "EXIT!");
            
            Exit();
        }

        static void Main(string[] args)
        {
            var app = new Program();
            app.Run(args);
        }
    }
}
