﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Net;
using System.Net.Http;
using System.IO;

namespace AtelierSampleApp
{
    using tlog = Tizen.Log;
    class TestTopic2
    {
        static string tag = "ATELIER";


        string m_imageDataFile;
        string m_url;

        public TestTopic2(string datafile, string url)
        {
            m_imageDataFile = datafile;
            m_url = url;
        }
        public void Testcase()
        {
            try
            {
                FileStream fs = new FileStream(m_imageDataFile, FileMode.Open, FileAccess.Read);
                tlog.Debug(tag, "fs.Length : " + fs.Length.ToString());

                BinaryReader br = new BinaryReader(fs);
                byte[] fileBytes = br.ReadBytes((int)fs.Length);

                WebRequest request = WebRequest.Create(new Uri(m_url));

                request.Method = "POST";

                request.ContentType = "image/jpeg";
                request.ContentLength = fileBytes.Length;

                Stream dataStream = request.GetRequestStream();
                dataStream.Write(fileBytes, 0, fileBytes.Length);

                dataStream.Close();
                WebResponse response = request.GetResponse();
                tlog.Debug(tag, ((HttpWebResponse)response).StatusDescription);


                dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                string responseFromServer = reader.ReadToEnd();
                tlog.Debug(tag, responseFromServer);

                reader.Close();
                dataStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                tlog.Debug(tag, "Error : " + ex.Message);
            }
            Thread.Sleep(1000);
        }
    }
}
