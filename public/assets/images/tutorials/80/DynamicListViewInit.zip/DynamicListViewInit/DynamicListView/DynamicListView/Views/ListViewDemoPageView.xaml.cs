﻿using Xamarin.Forms;

namespace DynamicListView.Views
{
    public partial class ListViewDemoPageView : ContentPage
    {
        public ListViewDemoPageView()
        {   
            InitializeComponent();
        }
    }
}