﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace DynamicListView.ViewModels
{
    public class ListViewDemoPageViewModel : ViewModelBase
    {
        public ListViewDemoPageViewModel()
        {
            
        }
    }
}