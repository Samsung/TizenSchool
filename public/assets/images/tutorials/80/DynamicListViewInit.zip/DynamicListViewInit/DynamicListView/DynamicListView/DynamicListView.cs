using Xamarin.Forms;

namespace DynamicListView
{
    public class App : Application
    {
        public App()
        {
            MainPage = new Views.ListViewDemoPageView();
        }
    }
}
