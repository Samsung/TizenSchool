﻿using Xamarin.Forms;

namespace Compass.Tizen.Wearable.Views
{
    /// <summary>
    /// Main application page class.
    /// Page presenting compass rose and azimuth.
    /// </summary>
    public partial class CompassPage : ContentPage
    {
        #region methods

        /// <summary>
        /// Main application page class constructor.
        /// </summary>
        public CompassPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}