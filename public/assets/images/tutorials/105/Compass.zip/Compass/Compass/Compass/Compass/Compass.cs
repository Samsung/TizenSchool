using Xamarin.Forms;

namespace Compass
{
    /// <summary>
    /// App class.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// App class constructor.
        /// Calls platform specific page manager to create main page.
        /// </summary>
        public App()
        {
            MainPage = new ContentPage();
        }

        #endregion
    }
}
