﻿/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System.Collections.ObjectModel;
using System.Windows.Input;
using NotificationsMonitor.Models;
using NotificationsMonitor.Services;
using NotificationsMonitor.Views;
using Xamarin.Forms;

namespace NotificationsMonitor.ViewModels
{
    /// <summary>
    /// ViewModel of the <see cref="NotificationsPage"/>.
    /// </summary>
    public class NotificationsPageViewModel : ViewModelBase
    {
        private const string START_BUTTON_TEXT = "Start";
        private const string STOP_BUTTON_TEXT = "Stop";

        private readonly NotificationMonitorService _notificationService;

        private string _buttonText = START_BUTTON_TEXT;

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationsPageViewModel"/> class.
        /// </summary>
        public NotificationsPageViewModel()
        {
            _notificationService = new NotificationMonitorService();
            Notifications = _notificationService.Notifications;

            ToggleMonitoringCommmand = new Command(ToggleMonitoring);
            GoToBluetoothPageCommand = new Command(GoToBluetoothPage);
        }

        /// <summary>
        /// Gets or sets the value of the button text.
        /// </summary>
        public string ButtonText
        {
            get => _buttonText;
            set => SetProperty(ref _buttonText, value);
        }

        /// <summary>
        /// Gets the list of notifications.
        /// </summary>
        public ObservableCollection<NotificationInfo> Notifications { get; }

        /// <summary>
        /// Gets the command for toggling monitoring notifications.
        /// </summary>
        public ICommand ToggleMonitoringCommmand { get; }

        /// <summary>
        /// Gets the command for going to <see cref="Views.BluetoothDevicesPage"/>.
        /// </summary>
        public ICommand GoToBluetoothPageCommand { get; }

        private void ToggleMonitoring()
        {
            if (_notificationService.IsMonitoring)
            {
                _notificationService.Stop();
                ButtonText = START_BUTTON_TEXT;
            }
            else
            {
                _notificationService.Start();
                ButtonText = STOP_BUTTON_TEXT;
            }
        }

        private void GoToBluetoothPage()
        {
            Application.Current.MainPage = new BluetoothDevicesPage();
        }
    }
}
