﻿/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using System.Collections.ObjectModel;
using System.Text;
using Newtonsoft.Json;
using NotificationsMonitor.Models;

namespace NotificationsMonitor.Services
{
    /// <summary>
    /// Provides all methods and properties to monitor notifications.
    /// </summary>
    public class NotificationMonitorService
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationMonitorService"/> class.
        /// </summary>
        public NotificationMonitorService()
        {
            Notifications = new ObservableCollection<NotificationInfo>();
        }

        /// <summary>
        /// Gets a value indicating whether monitoring is started.
        /// </summary>
        public bool IsMonitoring { get; private set; }

        /// <summary>
        /// Gets the notifications.
        /// </summary>
        public ObservableCollection<NotificationInfo> Notifications { get; }

        /// <summary>
        /// Starts monitoring notifications.
        /// </summary>
        public void Start()
        {
            if (BluetoothService.Instance.IsRfcommStarted)
            {
                IsMonitoring = true;
                BluetoothService.Instance.Received += NotificationReceived;
            }
        }

        /// <summary>
        /// Stops monitoring notifications.
        /// </summary>
        public void Stop()
        {
            BluetoothService.Instance.Received -= NotificationReceived;
            IsMonitoring = false;
        }

        private void NotificationReceived(object sender, byte[] raw)
        {
            if (GetNotificationInfo(raw) is NotificationInfo notificationInfo)
            {
                Notifications.Insert(0, notificationInfo);
            }
        }

        private NotificationInfo GetNotificationInfo(byte[] raw)
        {
            try
            {
                string message = Encoding.ASCII.GetString(raw);

                return JsonConvert.DeserializeObject<NotificationInfo>(message);
            }
            catch (Exception ex)
            {
                Tizen.Log.Debug(Config.LogTag, $"Cannot convert {raw} to ASCI string.\n {ex.StackTrace}");
            }

            return null;
        }
    }
}
