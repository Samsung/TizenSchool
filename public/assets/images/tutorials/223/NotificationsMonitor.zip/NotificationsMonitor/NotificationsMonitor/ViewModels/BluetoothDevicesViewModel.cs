﻿/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Input;
using NotificationsMonitor.Models;
using NotificationsMonitor.Services;
using NotificationsMonitor.Views;
using Xamarin.Forms;

namespace NotificationsMonitor.ViewModels
{
    /// <summary>
    /// ViewModel of the <see cref="NotificationsMonitor.Views.BluetoothDevicesPage"/>.
    /// </summary>
    public class BluetoothDevicesViewModel : ViewModelBase
    {
        private const string START_SEARCH_TEXT = "Search device";
        private const string CANCEL_SEARCH_TEXT = "Cancel searching";

        private readonly CancellationTokenSource _searchDevicesTokenSource;

        private bool _isSearching;
        private bool _isBluetoothEnabled;
        private string _searchButtonText = START_SEARCH_TEXT;

        /// <summary>
        /// Initializes a new instance of the <see cref="BluetoothDevicesViewModel"/> class.
        /// </summary>
        public BluetoothDevicesViewModel()
        {
            Devices = new ObservableCollection<BluetoothDevice>();

            BluetoothService.Instance.DeviceFound += DeviceFound;
            IsBluetoothEnabled = BluetoothService.Instance.IsBluetoothEnabled;

            _searchDevicesTokenSource = new CancellationTokenSource();
            SearchCommand = new Command(Search);
            PairCommand = new Command(Pair);
        }

        /// <summary>
        /// Gets the list of names of the available bluetooth devices.
        /// </summary>
        public ObservableCollection<BluetoothDevice> Devices { get; }

        /// <summary>
        /// Gets or sets the command which is responsible for invoke
        /// method that connects to selected device.
        /// </summary>
        public ICommand PairCommand { get; set; }

        /// <summary>
        /// Gets or sets the command which is responsible for invoke
        /// method that search for available bluetooth devices.
        /// </summary>
        public ICommand SearchCommand { get; set; }

        /// <summary>
        /// Gets the name of the bluetooth device.
        /// </summary>
        public string DeviceName => BluetoothService.Instance.Name;

        /// <summary>
        /// Gets or sets the text of the search button.
        /// </summary>
        public string SearchButtonText
        {
            get => _searchButtonText;
            set => SetProperty(ref _searchButtonText, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether the bluetooth is enabled or not.
        /// </summary>
        public bool IsBluetoothEnabled
        {
            get => _isBluetoothEnabled;
            set => SetProperty(ref _isBluetoothEnabled, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether search is currently being performed.
        /// </summary>
        public bool IsSearching
        {
            get => _isSearching;
            set => SetProperty(ref _isSearching, value);
        }

        private void DeviceFound(object sender, string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                var device = new BluetoothDevice() { Name = name };
                Devices.Add(device);
            }
        }

        private void Pair(object bluetoothDevice)
        {
            try
            {
                if (BluetoothService.Instance.IsSearching)
                {
                    _searchDevicesTokenSource?.Cancel();
                }

                Tizen.Log.Debug(Config.LogTag, $"Pairing...");
                if (bluetoothDevice is BluetoothDevice device)
                {
                    device.Status = BluetoothDevice.BoundStatus.Pairing;
                    BluetoothService.Instance.Pair(device.Name);
                    BluetoothService.Instance.Paired += DevicePaired;
                }
            }
            catch (Exception ex)
            {
                Tizen.Log.Debug(Config.LogTag, $"{ex}");
            }
        }

        private async void DevicePaired(object sender, string name)
        {
            await Application.Current.MainPage.DisplayAlert("Paired", $"Paired with {name}!", "OK")
                .ConfigureAwait(true);

            BluetoothService.Instance.StartRfcommServer();
            Tizen.Log.Debug(Config.LogTag, "Changing page");

            try
            {
                Device.BeginInvokeOnMainThread(
                    () => Application.Current.MainPage = new NotificationsPage());
            }
            catch (Exception ex)
            {
                Tizen.Log.Debug(Config.LogTag, $"{ex}");
            }
        }

        private async void Search()
        {
            if (BluetoothService.Instance.IsSearching)
            {
                SearchButtonText = START_SEARCH_TEXT;
                _searchDevicesTokenSource?.Cancel();
            }
            else
            {
                Devices.Clear();

                SearchButtonText = CANCEL_SEARCH_TEXT;
                IsSearching = true;

                await BluetoothService.Instance.StartSearching(_searchDevicesTokenSource.Token, 30000)
                    .ConfigureAwait(true);

                IsSearching = false;
                SearchButtonText = START_SEARCH_TEXT;
            }
        }
    }
}
