﻿/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tizen.Network.Bluetooth;

namespace NotificationsMonitor.Services
{
    /// <summary>
    /// Provides all methods and properties to manage bluetooth connections and data transfer.
    /// </summary>
    public sealed class BluetoothService
    {
        private static BluetoothService _instance;
        private readonly HashSet<BluetoothDevice> _devices;

        private BluetoothDevice _boundedDevice;
        private BluetoothServerSocket _serverSocket;
        private IBluetoothServerSocket _client;

        private BluetoothService()
        {
            _devices = new HashSet<BluetoothDevice>();
        }

        /// <summary>
        /// The DeviceFound event occurs when available device to pair has been found.
        /// </summary>
        public event EventHandler<string> DeviceFound;

        /// <summary>
        /// The Paired event occurs when device has been correctly paired(bound).
        /// </summary>
        public event EventHandler<string> Paired;

        /// <summary>
        /// The Received event occurs when the notification has been received from the client.
        /// </summary>
        public event EventHandler<byte[]> Received;

        /// <summary>
        /// Gets the instance of the BluetoothService. As the singleton pattern defines.
        /// </summary>
        public static BluetoothService Instance
            => _instance ?? (_instance = new BluetoothService());

        /// <summary>
        /// Gets a value indicating whether defines if the searching is currently in progress.
        /// </summary>
        public bool IsSearching
            => BluetoothAdapter.IsDiscoveryInProgress;

        /// <summary>
        /// Gets a value indicating whether the bluetooth is enabled or not.
        /// </summary>
        public bool IsBluetoothEnabled
            => false;

        /// <summary>
        /// Gets the name of the bluetooth device.
        /// </summary>
        public string Name => BluetoothAdapter.Name;

        /// <summary>
        /// Gets a value indicating whether the RFComm communication is started.
        /// </summary>
        public bool IsRfcommStarted { get; private set; }

        /// <summary>
        /// Pairs with the device of the provided name.
        /// </summary>
        /// <param name="deviceName">The name of the device to pair with.</param>
        public void Pair(string deviceName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Starts searching for the available to pair bluetooth device.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <param name="searchingPeriod">Amount of searching time.</param>
        public async Task StartSearching(CancellationToken cancellationToken, int searchingPeriod = 3000)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Starts the RFComm server.
        /// </summary>
        public void StartRfcommServer()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Stops the RFComm server and destroys bound with the device.
        /// </summary>
        public void Close()
        {
        }
    }
}
