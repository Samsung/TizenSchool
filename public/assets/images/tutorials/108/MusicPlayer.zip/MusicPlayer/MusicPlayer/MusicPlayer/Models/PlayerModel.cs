﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MusicPlayer.Models
{
    /// <summary>
    /// Responsible for managing the logic of the player.
    /// </summary>
    public class PlayerModel
    {
        #region fields

        #endregion

        #region properties

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public PlayerModel()
        {

        }

        #endregion
    }
}
