﻿using MusicPlayer.ViewModels;

namespace MusicPlayer.Views
{
    /// <summary>
    /// Interface of classes handling navigation over views.
    /// </summary>
    interface IViewNavigation
    {
        #region methods

        /// <summary>
        /// Navigates to the view containing list of available soundtracks.
        /// </summary>
        /// <param name="clearHistory">
        /// Flag indicating if navigation history should be cleared.
        /// </param>
        void GoToSoundtracksList(bool clearHistory = false);

        /// <summary>
        /// Navigates to the view with track preview.
        /// </summary>
        void GoToPreview();

        #endregion
    }
}
