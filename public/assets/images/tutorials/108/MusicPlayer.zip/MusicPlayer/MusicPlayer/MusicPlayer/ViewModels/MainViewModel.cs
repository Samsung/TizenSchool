﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using MusicPlayer.Models;
using MusicPlayer.Views;
using Xamarin.Forms;

namespace MusicPlayer.ViewModels
{
    /// <summary>
    /// The application's main view model class (abstraction of the view).
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Reference to class handling navigation over views.
        /// </summary>
        private readonly IViewNavigation _navigation;

        #endregion

        #region properties

        /// <summary>
        /// Command which shows actual application (after welcome screen).
        /// </summary>
        public ICommand GoToApplicationCommand { get; private set; }

        /// <summary>
        /// Command which shows the preview page.
        /// </summary>
        public ICommand GoToPreviewPageCommand { get; private set; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public MainViewModel()
        {
            _navigation = DependencyService.Get<IViewNavigation>();
            InitCommands();
        }

        /// <summary>
        /// Initializes commands.
        /// </summary>
        private void InitCommands()
        {
            GoToApplicationCommand = new Command(ExecuteGoToApplication);
            GoToPreviewPageCommand = new Command(ExecuteGoToPreview);
        }

        /// <summary>
        /// Handles execution of "GoToApplicationCommand".
        /// Navigates to page with soundtracks list (with clearing navigation history).
        /// </summary>
        private void ExecuteGoToApplication()
        {
            _navigation.GoToSoundtracksList(clearHistory: true);
        }

        /// <summary>
        /// Handles execution of "GoToPreviewPageCommand".
        /// Navigates to page with preview.
        /// </summary>
        private void ExecuteGoToPreview()
        {
            _navigation.GoToPreview();
        }

        #endregion
    }
}
