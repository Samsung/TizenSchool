﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer
{
    /// <summary>
    /// Music Player cross-platform application class.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MusicPlayer : Application
    {
        #region methods

        /// <summary>
        /// The application constructor.
        /// </summary>
        public MusicPlayer()
        {
            InitializeComponent();
        }

        #endregion
    }
}