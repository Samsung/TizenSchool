﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Control
{
    /// <summary>
    /// Represents single item of tracklist.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TrackListViewCell : ContentView
    {
        #region properties

        #endregion

        #region methods

        /// <summary>
        /// Creates new instance of class.
        /// </summary>
        public TrackListViewCell()
        {
            InitializeComponent();
        }

        #endregion
    }
}