﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MusicPlayer.Models;
using MusicPlayer.Tizen.TV.Services;
using Tizen.Multimedia;

[assembly: Xamarin.Forms.Dependency(typeof(PlayerService))]
namespace MusicPlayer.Tizen.TV.Services
{
    /// <summary>
    /// The service class handling loading and playback of audio file.
    /// </summary>
    class PlayerService : IPlayerService
    {
        #region fields

        /// <summary>
        /// Event invoked when playback state was changed.
        /// Current state of playback is provided by "Playing" property.
        /// </summary>
        public event EventHandler PlayStateChanged;

        /// <summary>
        /// Event invoked when playback was completed.
        /// </summary>
        public event EventHandler PlaybackCompleted;

        #endregion

        #region properties

        /// <summary>
        /// Indicates if there is ongoing playback.
        /// </summary>
        public bool Playing => throw new NotImplementedException();

        /// <summary>
        /// Current playback position (in milliseconds).
        /// In case of no loaded file, 0 value is returned.
        /// </summary>
        public int PlaybackPosition => throw new NotImplementedException();

        #endregion

        #region methods

        /// <summary>
        /// Initializes a new instance of the service class.
        /// </summary>
        public PlayerService()
        {

        }

        /// <summary>
        /// Asynchronously loads specified audio file (by path) into player.
        /// The playback can be automatically started by setting "play" parameter (false by default).
        /// </summary>
        /// <param name="path">Path to the audio file.</param>
        /// <param name="play">Indicates if playback should be automatically started as soon as file is loaded.</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// The task result indicates if operation completes successfully.</returns>
        public async Task<bool> Load(string path, bool play = false)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Asynchronously starts/resumes the playback.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public Task Play()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Asynchronously pauses the playback.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public Task Pause()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Asynchronously sets position of the playback (milliseconds).
        /// </summary>
        /// <param name="msec">The value indicating a desired position in milliseconds.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task SeekTo(int msec)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
