﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace MusicPlayer.Converters
{
    /// <summary>
    /// Provides methods to negate boolean value.
    /// </summary>
    class NegateBooleanConverter : IValueConverter
    {
        /// <summary>
        /// Converts boolean value to opposite value.
        /// </summary>
        /// <param name="value">Boolean value.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Opposite boolean value.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts boolean value to opposite value.
        ///
        /// Not required by the application (not implemented).
        /// </summary>
        /// <param name="value">Boolean value.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Opposite boolean value.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
