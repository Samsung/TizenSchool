﻿using System;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Control
{
    /// <summary>
    /// Button which allows to set images for its states.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ImageButton : ContentView
    {
        #region fields

        #endregion

        #region properties

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public ImageButton()
        {
            InitializeComponent();
        }

        #endregion
    }
}