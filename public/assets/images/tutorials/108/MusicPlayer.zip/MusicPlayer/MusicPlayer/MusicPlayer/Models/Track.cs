﻿namespace MusicPlayer.Models
{
    /// <summary>
    /// Class that holds information about track.
    /// </summary>
    public class Track
    {
        #region properties

        /// <summary>
        /// Title of the track.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Represents the artist name.
        /// </summary>
        public string Artist { get; set; }

        /// <summary>
        /// Represents the album name.
        /// </summary>
        public string Album { get; set; }

        /// <summary>
        /// Represents the track artwork.
        /// </summary>
        public byte[] Artwork { get; set; }

        /// <summary>
        /// Path to the track.
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// Duration of the track (in milliseconds).
        /// </summary>
        public int Duration { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes Track class instance.
        /// </summary>
        /// <param name="title">Title of the track.</param>
        /// <param name="artist">Name of the artist.</param>
        /// <param name="album">Title of the album.</param>
        /// <param name="artwork">Artwork of the track.</param>
        /// <param name="path">Path to the track.</param>
        /// <param name="duration">Duration of the track (in milliseconds).</param>
        public Track(string title, string artist, string album, byte[] artwork, string path, int duration)
        {
            Title = title;
            Artist = artist;
            Album = album;
            Artwork = artwork;
            Path = path;
            Duration = duration;
        }

        #endregion
    }
}
