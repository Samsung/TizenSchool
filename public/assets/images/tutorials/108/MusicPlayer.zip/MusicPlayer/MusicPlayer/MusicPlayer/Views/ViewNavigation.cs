﻿using Xamarin.Forms;
using MusicPlayer.Views;
using MusicPlayer.Models;
using MusicPlayer.ViewModels;

[assembly: Dependency(typeof(ViewNavigation))]

namespace MusicPlayer.Views
{
    /// <summary>
    /// Class handling navigation over application views.
    /// </summary>
    class ViewNavigation : IViewNavigation
    {
        #region methods

        /// <summary>
        /// Navigates to the view containing list of available soundtracks.
        /// </summary>
        /// <param name="clearHistory">
        /// Flag indicating if navigation history should be cleared.
        /// </param>
        public void GoToSoundtracksList(bool clearHistory = false)
        {
            if (clearHistory)
            {
                Application.Current.MainPage = new NavigationPage(new SoundtracksListPage());
            }
            else
            {
                Application.Current.MainPage.Navigation.PushAsync(new SoundtracksListPage());
            }
        }

        /// <summary>
        /// Navigates to page with track preview.
        /// </summary>
        public void GoToPreview()
        {
            Application.Current.MainPage.Navigation.PushAsync(new PreviewPage());
        }

        #endregion
    }
}
