﻿using MusicPlayer.Models;
using MusicPlayer.Tizen.TV.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Tizen;
using Tizen.Content.MediaContent;
using Tizen.Multimedia;
using Tizen.System;

[assembly: Xamarin.Forms.Dependency(typeof(MusicContentService))]
namespace MusicPlayer.Tizen.TV.Services
{
    /// <summary>
    /// Responsible for providing tracks from device.
    /// </summary>
    class MusicContentService : IMusicContentService
    {
        #region fields

        #endregion

        #region methods

        /// <summary>
        /// MusicContentService class constructor.
        /// </summary>
        public MusicContentService()
        {

        }

        /// <summary>
        /// Gets tracks from device.
        /// </summary>
        /// <returns>A collection of audio tracks.</returns>
        public List<Track> GetTracksFromDevice()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
