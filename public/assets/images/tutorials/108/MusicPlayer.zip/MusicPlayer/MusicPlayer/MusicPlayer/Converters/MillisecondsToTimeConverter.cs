﻿using System;
using Xamarin.Forms;

namespace MusicPlayer.Converters
{
    /// <summary>
    /// Allows to convert milliseconds to time string.
    /// </summary>
    public class MillisecondsToTimeConverter : IValueConverter
    {
        /// <summary>
        /// Converts milliseconds to time string.
        /// </summary>
        /// <param name="value">Number of milliseconds.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>String representing time (in format "hh:mm:ss").</returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts time string to milliseconds.
        ///
        /// Not required by the application (not implemented).
        /// </summary>
        /// <param name="value">Time string.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Integer representing time in milliseconds.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
