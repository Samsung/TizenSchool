﻿using System;
using System.IO;
using Xamarin.Forms;

namespace MusicPlayer.Converters
{
    /// <summary>
    /// Allows to convert image in byte array to image source.
    /// </summary>
    public class ByteArrayToImageSourceConverter : IValueConverter
    {
        /// <summary>
        /// Converts byte array to image source.
        /// </summary>
        /// <param name="value">Value of the byte array.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Image source object from byte array or cover for unknown artwork.</returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts image source to byte array.
        ///
        /// Not required by the application (not implemented).
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">Parameters of conversion.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Converted object.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
