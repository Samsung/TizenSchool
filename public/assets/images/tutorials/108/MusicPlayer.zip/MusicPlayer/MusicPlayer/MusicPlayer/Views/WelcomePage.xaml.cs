﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Views
{
    /// <summary>
    /// The application welcome page.
    /// It contains general information about application.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class WelcomePage : ContentPage
    {
        #region methods

        /// <summary>
        /// The page constructor.
        /// </summary>
        public WelcomePage()
        {
            InitializeComponent();
        }

        #endregion
    }
}