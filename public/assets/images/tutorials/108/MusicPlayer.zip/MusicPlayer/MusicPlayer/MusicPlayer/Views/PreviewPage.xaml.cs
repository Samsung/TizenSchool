﻿using MusicPlayer.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Views
{
    /// <summary>
    /// Page displaying preview of the track.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PreviewPage : ContentPage
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public PreviewPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}