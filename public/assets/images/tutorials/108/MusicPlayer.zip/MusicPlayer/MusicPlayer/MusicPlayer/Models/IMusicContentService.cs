﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicPlayer.Models
{
    /// <summary>
    /// Responsible for providing tracks from device.
    /// </summary>
    public interface IMusicContentService
    {
        #region methods

        /// <summary>
        /// Gets tracks from device.
        /// </summary>
        /// <returns>Returns audio tracks (information) stored on device.</returns>
        List<Track> GetTracksFromDevice();

        #endregion
    }
}
