﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Views
{
    /// <summary>
    /// The page displaying available soundtracks list.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SoundtracksListPage : ContentPage
    {
        #region methods

        /// <summary>
        /// Default class constructor.
        /// </summary>
        public SoundtracksListPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}