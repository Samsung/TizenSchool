﻿using System.Collections;
using System.Collections.Generic;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MusicPlayer.Control
{
    /// <summary>
    /// Vertically scrollable grid.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ScrollableGrid : ContentView
    {
        #region properties

        #endregion

        #region methods

        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        public ScrollableGrid()
        {
            InitializeComponent();
        }

        #endregion
    }
}