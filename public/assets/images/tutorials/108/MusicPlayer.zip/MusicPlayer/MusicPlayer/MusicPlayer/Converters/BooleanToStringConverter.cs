﻿using System;
using Xamarin.Forms;

namespace MusicPlayer.Converters
{
    /// <summary>
    /// Allows to convert boolean value to one of the strings from array.
    /// </summary>
    public class BooleanToStringConverter : IValueConverter
    {
        /// <summary>
        /// Converters boolean value to string (possible values passed as parameter).
        /// </summary>
        /// <param name="value">Boolean value.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">String array with possible values.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Proper string for given boolean value.</returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts string to boolean value.
        ///
        /// Not required by the application (not implemented).
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Target type of conversion.</param>
        /// <param name="parameter">String array with possible values.</param>
        /// <param name="culture">Provides information about a specific culture.</param>
        /// <returns>Proper boolean value for given string.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
