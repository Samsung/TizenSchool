﻿using MetalDetector.Models;
using System;

namespace MetalDetector.Tizen.Wearable.Service
{
    /// <summary>
    /// Class defining structure of object being parameter of the MagnetometerDataUpdated event.
    /// </summary>
    class MagnetometerDataUpdatedArgs : EventArgs, IMagnetometerDataUpdatedArgs
    {
    }
}
