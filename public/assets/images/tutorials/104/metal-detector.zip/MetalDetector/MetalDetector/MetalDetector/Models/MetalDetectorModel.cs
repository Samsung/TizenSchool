﻿namespace MetalDetector.Models
{
    /// <summary>
    /// Class defining metal detector model which allow the application to use properties
    /// describing metal detector state.
    /// </summary>
    public class MetalDetectorModel
    {
        #region methods

        /// <summary>
        /// MagnetometerModel class constructor.
        /// Initializes the model.
        /// </summary>
        public MetalDetectorModel()
        {
        }

        #endregion
    }
}
