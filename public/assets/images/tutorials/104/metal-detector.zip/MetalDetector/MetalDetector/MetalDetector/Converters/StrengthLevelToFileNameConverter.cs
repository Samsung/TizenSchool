﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace MetalDetector.Converters
{
    /// <summary>
    /// Class to convert strength level to corresponding image file name.
    /// </summary>
    public class StrengthLevelToFileNameConverter : IValueConverter
    {
        #region methods

        /// <summary>
        /// Converts strength level to corresponding image file name.
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Optional conversion parameter.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>String representing converted date.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts back image file name to strength level.
        /// Not required by the application, so it is not implemented.
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Optional conversion parameter.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>Date object representing converted string.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
