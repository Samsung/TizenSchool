﻿using MetalDetector.Models;
using MetalDetector.Tizen.Wearable.Service;

[assembly: Xamarin.Forms.Dependency(typeof(MagnetometerService))]
namespace MetalDetector.Tizen.Wearable.Service
{
    /// <summary>
    /// Magnetometer service which allows to obtain the magnetometer data.
    /// </summary>
    class MagnetometerService : IMagnetometerService
    {
        #region methods

        /// <summary>
        /// MagnetometerService class constructor.
        /// </summary>
        public MagnetometerService()
        {
        }

        #endregion
    }
}
