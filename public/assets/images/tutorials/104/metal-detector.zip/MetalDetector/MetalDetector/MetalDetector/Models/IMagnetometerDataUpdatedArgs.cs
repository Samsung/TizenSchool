﻿namespace MetalDetector.Models
{
    /// <summary>
    /// IMagnetometerDataUpdatedArgs interface class.
    /// Defines properties that should be implemented by class used to notifying about the magnetometer data update.
    /// </summary>
    public interface IMagnetometerDataUpdatedArgs
    {
    }
}
