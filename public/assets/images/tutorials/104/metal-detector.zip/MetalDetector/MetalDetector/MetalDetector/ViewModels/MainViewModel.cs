﻿namespace MetalDetector.ViewModels
{
    /// <summary>
    /// Main view model class for the application.
    /// Encapsulates presentation logic and state of the application.
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region methods

        /// <summary>
        /// MainViewModel class constructor.
        /// Initializes the view model.
        /// </summary>
        public MainViewModel()
        {
        }

        #endregion
    }
}
