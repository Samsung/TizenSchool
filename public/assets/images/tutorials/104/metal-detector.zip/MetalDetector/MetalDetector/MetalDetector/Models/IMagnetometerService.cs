﻿namespace MetalDetector.Models
{
    /// <summary>
    /// Interface of magnetometer service which allows to obtain the magnetometer data.
    /// </summary>
    public interface IMagnetometerService
    {
    }
}
