/*
 * Copyright (c) 2020 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
using ElmSharp.Wearable;
using System;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;

namespace Pedometer.Views
{
    /// <summary>
    /// Main page of the application.
    /// </summary>
    public partial class MainPage : CirclePage
    {
        #region fields

        /// <summary>
        /// Value of single rotation.
        /// </summary>
        private const double SINGLE_ROTATION = 46.2;

        /// <summary>
        /// Single screen width value.
        /// </summary>
        private const int SCREEN_WIDTH = 200;

        /// <summary>
        /// Rotation time value.
        /// </summary>
        private const int ROTATION_TIME = 450;

        /// <summary>
        /// Initial value of X position.
        /// </summary>
        private const int INITIAL_POSITION_X = -118;

        /// <summary>
        /// Initial value of Y position.
        /// </summary>
        private const int INITIAL_POSITION_Y = 75;

        /// <summary>
        /// Identification number of currently used screen.
        /// </summary>
        private int _currentScreen = 1;

        /// <summary>
        /// Last time when RotaryEvent was raised.
        /// </summary>
        private DateTime _lastMoveTime = DateTime.Now;

        #endregion

        #region methods

        /// <summary>
        /// Initializes MainPage class instance.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
            RotaryEventManager.Rotated += RotaryEventManager_Rotated;
            GetLabelImage(0).FadeTo(0);
            GetLabelImage(2).FadeTo(0);
            GetLabelImage(3).FadeTo(0);
        }

        /// <summary>
        /// Switches view to selected screen.
        /// </summary>
        /// <param name="screen">Screen's index.</param>
        public void SwitchScreen(int screen)
        {
            if (_currentScreen == screen)
            {
                return;
            }

            GetLabelImage(_currentScreen).FadeTo(0);
            _currentScreen = screen;
            GetLabelImage(_currentScreen).FadeTo(1);

            double rotation = SINGLE_ROTATION;
            int positionX = INITIAL_POSITION_X;

            switch (screen)
            {
                case 0:
                    rotation -= SINGLE_ROTATION;
                    positionX += SCREEN_WIDTH;
                    break;
                case 1:
                    break;
                case 2:
                    rotation += SINGLE_ROTATION;
                    positionX -= SCREEN_WIDTH;
                    break;
                case 3:
                    rotation += (SINGLE_ROTATION * 2) + 0.5;
                    positionX -= SCREEN_WIDTH * 2;
                    break;
            }

            uint length = (uint)(Math.Abs(blueShape.Rotation - rotation) / SINGLE_ROTATION * ROTATION_TIME);
            blueShape.RotateTo(rotation, length, Easing.SpringOut);
            grid.LayoutTo(new Rectangle(positionX, INITIAL_POSITION_Y, SCREEN_WIDTH * 4, SCREEN_WIDTH), (uint)(length * 0.6), Easing.SinInOut);
        }

        /// <summary>
        /// Returns image of particular label.
        /// </summary>
        /// <param name="number">Label's index.</param>
        /// <returns>Specified image.</returns>
        private Image GetLabelImage(int number)
        {
            switch (number)
            {
                case 0:
                    return label0;
                case 1:
                    return label1;
                case 2:
                    return label2;
                case 3:
                    return label3;
            }

            return null;
        }

        /// <summary>
        /// Handles execution of Rotated event.
        /// </summary>
        /// <param name="args">RotaryEvent Args.</param>
        private void RotaryEventManager_Rotated(ElmSharp.Wearable.RotaryEventArgs args)
        {
            DateTime currentMoveTime = DateTime.Now;
            TimeSpan span = currentMoveTime - _lastMoveTime;
            _lastMoveTime = currentMoveTime;

            if (span.TotalMilliseconds <= 4)
            {
                return;
            }

            if (args.IsClockwise)
            {
                if (_currentScreen == 3)
                {
                    return;
                }

                SwitchScreen(_currentScreen + 1);
            }
            else
            {
                if (_currentScreen == 0)
                {
                    return;
                }

                SwitchScreen(_currentScreen - 1);
            }
        }

        #endregion
    }
}