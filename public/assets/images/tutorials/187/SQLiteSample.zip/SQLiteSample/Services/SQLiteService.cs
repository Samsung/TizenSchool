﻿using SQLiteSample.Models;
using SQLite;
using System;
using Xamarin.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using SQLitePCL;

namespace SQLiteSample.Services
{
    public class SQLiteService
    {
        private static SQLiteService instance;
        public static SQLiteService Instance
        {
            get => instance ?? (instance = new SQLiteService());
        }

        private static SQLiteAsyncConnection conn;

        public SQLiteService()
        {
            conn = GetConnection();
            conn.CreateTableAsync<TodoItem>().Wait();
        }

        public SQLiteAsyncConnection GetConnection()
        {
            var document = global::Tizen.Applications.Application.Current.DirectoryInfo.Data;
            var path = Path.Combine(document, "MySQLite.db");

            raw.SetProvider(new SQLite3Provider_sqlite3());
            raw.FreezeProvider(true);

            return new SQLiteAsyncConnection(path);
        }

        public Task<int> Create(TodoItem todo)
        {
            return conn.InsertAsync(todo);
        }

        public Task<int> Modify(TodoItem item)
        {
            item.TimeTodo = DateTime.Now;
            return conn.UpdateAsync(item);
        }

        public Task<int> Delete(TodoItem item)
        {
            return conn.DeleteAsync(item);
        }

        public Task<List<TodoItem>> GetListAsync()
        {
            return conn.Table<TodoItem>().ToListAsync();
        }
    }
}
