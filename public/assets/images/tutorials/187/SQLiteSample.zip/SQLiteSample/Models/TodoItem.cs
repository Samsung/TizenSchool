﻿using SQLite;
using System;

namespace SQLiteSample.Models
{
    [Table("TodoItems")]
    public class TodoItem
    {
        [PrimaryKey, AutoIncrement, Column("TodoItemId")]
        public int Id { get; set; }
        public DateTime TimeTodo { get; set; }
        public string Title { get; set; }
    }
}