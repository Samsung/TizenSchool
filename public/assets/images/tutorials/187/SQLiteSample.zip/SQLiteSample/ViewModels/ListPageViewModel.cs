﻿using SQLiteSample.Models;
using SQLiteSample.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.IO;

namespace SQLiteSample.ViewModels
{
    class ListPageViewModel : ViewModelBase
    {
		public Action OnScrollDown { get; set; }

		private List<TodoItem> todoList;

		public List<TodoItem> TodoList
		{
			get => todoList;
			set => SetProperty(ref todoList, value);
		}

		private string inputTodo;

		public string InputTodo
		{
			get => inputTodo;
			set => SetProperty(ref inputTodo, value);
		}
		public Command CreateCommand { get; set; }
		public Command<object> ModifyCommand { get; set; }
		public Command<object> DeleteCommand { get; set; }

		public ListPageViewModel()
		{
			Task.Run(async () =>
			{
				TodoList = await SQLiteService.Instance.GetListAsync();
			});

			CreateCommand = new Command(async () =>
			{
				var todo = new TodoItem
				{
					TimeTodo = DateTime.Now,
					Title = InputTodo
				};

				await SQLiteService.Instance.Create(todo);
				InputTodo = "";
				TodoList = await SQLiteService.Instance.GetListAsync();
				OnScrollDown?.Invoke();
			});

			ModifyCommand = new Command<object>(async (object obj) =>
			{
				await SQLiteService.Instance.Modify((TodoItem)obj);
				await Application.Current.MainPage.DisplayAlert("Update", "It has been updated.", "OK");
				TodoList = await SQLiteService.Instance.GetListAsync();
			});

			DeleteCommand = new Command<object>(async (object obj) =>
			{
				var result = await Application.Current.MainPage.DisplayAlert("Delete", "Do you want to remove it?", "Yes", "No");
				if (result == true)
				{
					await SQLiteService.Instance.Delete((TodoItem)obj);
					TodoList = await SQLiteService.Instance.GetListAsync();
				}
			});
		}
	}
}
