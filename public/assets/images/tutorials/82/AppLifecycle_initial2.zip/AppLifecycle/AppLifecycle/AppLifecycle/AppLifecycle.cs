using AppLifecycle.View;
using Xamarin.Forms;

namespace AppLifecycle
{
    /// <summary>
    /// Portable application main class.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// Portable application constructor class.
        /// </summary>
        public App()
        {
            MainPage = new AppLifecyclePage();
        }

        #endregion
    }
}
