﻿namespace AppLifecycle.ViewModel
{
    /// <summary>
    /// ViewModel class for AppLifecyclePage.
    /// </summary>
    public class AppLifecycleViewModel : ViewModelBase
    {
    }
}
