﻿using VideoPlayerLite.Models;

namespace VideoPlayerLite.ViewModels
{
    public class ItemViewModel : ViewModelBase
    {
        private MediaItem videoItem;

        public MediaItem VideoItem
        {
            get => videoItem;
            set
            {
                videoItem = value;
                InvokePropertyChanged();
            }
        }

        public ItemViewModel(MediaItem item)
        {
            VideoItem = item;
        }
    }
}
