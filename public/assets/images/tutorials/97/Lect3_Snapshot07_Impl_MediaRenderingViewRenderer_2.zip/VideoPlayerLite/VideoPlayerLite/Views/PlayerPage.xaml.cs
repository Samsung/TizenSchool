﻿using Xamarin.Forms;

namespace VideoPlayerLite.Views
{
    public partial class PlayerPage : ContentPage
    {
        public static readonly BindableProperty FetchVideoCommandProperty = BindableProperty.Create("FetchVideoCommand", typeof(Command), typeof(PlayerPage), null);
        public Command FetchVideoCommand
        {
            get => (Command)GetValue(FetchVideoCommandProperty);
        }

        public PlayerPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            FetchVideoCommand.Execute(null);
        }
    }
}