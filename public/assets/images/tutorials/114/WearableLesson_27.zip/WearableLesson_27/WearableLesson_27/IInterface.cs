﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WearableLesson_27
{
    public interface IInterface
    {
        T GetPreference<T>(string key);
        bool ContainsPreference(string key);
        void SetPreference(string key, object value);
    }
}
