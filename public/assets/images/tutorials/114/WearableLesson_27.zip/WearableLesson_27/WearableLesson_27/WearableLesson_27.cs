using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;



namespace WearableLesson_27
{
    public class MyData
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

    public class App : Application
    {
        private const string PREF_KEY = "org.tizen.myApp.myKey";

        List<MyData> personData = new List<MyData>();
        int selectedIndex = 0;
        Label nameLabel = new Label();
        Label ageLabel = new Label();

        public App()
        {
            for (int i = 0; i < 4; i++)
                personData.Add(new MyData() { Name = "Name_" + i, Age = 20 + i });

            if(DependencyService.Get<IInterface>().ContainsPreference(PREF_KEY))
                selectedIndex = DependencyService.Get<IInterface>().GetPreference<int>(PREF_KEY);

            Button button = new Button();
            button.Text = "Change";
            button.HorizontalOptions = LayoutOptions.FillAndExpand;
            button.Clicked += OnChangeClicked;

            nameLabel.Text  = "Name :" + personData[selectedIndex].Name;
            nameLabel.HorizontalOptions = LayoutOptions.Center;

            ageLabel.Text ="Age : " + Convert.ToString(personData[selectedIndex].Age);
            ageLabel.HorizontalOptions = LayoutOptions.Center;
           
            MainPage = new ContentPage
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children = {
                        nameLabel,
                        ageLabel,
                        button
                    }
                }
            };
        }
        void OnChangeClicked(object sender, EventArgs args)
        {
            //incrementing currently selected item.
            selectedIndex = (selectedIndex + 1)%4;

            nameLabel.Text = "Name :" + personData[selectedIndex].Name;
            ageLabel.Text = "Age :" + Convert.ToString(personData[selectedIndex].Age);

            //setting the currently selected item in our key.
            DependencyService.Get<IInterface>().SetPreference(PREF_KEY, selectedIndex);
        }
        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
