﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tizen.Applications;
using System.Collections;
using System.Diagnostics;
using Tizen;
using WearableLesson_27.Tizen.Wearable;

[assembly: Xamarin.Forms.Dependency(typeof(PlatformAPI))]
namespace WearableLesson_27.Tizen.Wearable
{
    class PlatformAPI : IInterface
    {
        public T GetPreference<T>(string key)
        {
            return Preference.Get<T>(key);
        }

        public bool ContainsPreference(string key)
        {
            return Preference.Contains(key);
        }

        public void SetPreference(string key, object value)
        {
            Preference.Set(key, value);
        }
    }
}
