using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace WearableLesson_20
{
    public class App : Application
    {
        public App()
        {
            IndexPage p = new IndexPage();
            var image1 = new Image()
            {
                VerticalOptions = LayoutOptions.FillAndExpand,
                HorizontalOptions = LayoutOptions.FillAndExpand
            };
            image1.Source = "img1.jpg";
            var image2 = new Image()
            {
                VerticalOptions = LayoutOptions.FillAndExpand,
                HorizontalOptions = LayoutOptions.FillAndExpand
            };
            image2.Source = "img2.jpg";
            var image3 = new Image()
            {
                VerticalOptions = LayoutOptions.FillAndExpand,
                HorizontalOptions = LayoutOptions.FillAndExpand
            };
            image3.Source = "img3.jpg";
            ContentPage mypage1 = new ContentPage
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children = {
                        image1,
                     }
                }
            };
            ContentPage mypage2 = new ContentPage
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children = {
                        image2,
                    }
                }
            };
            ContentPage mypage3 = new ContentPage
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children = {
                        image3,
                    }
                }
            };
            p.Children.Add(mypage1);
            p.Children.Add(mypage2);
            p.Children.Add(mypage3);
            // The root page of your application
            MainPage = p;
        }


        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
