using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.TizenSpecific;

namespace Wearable_Lesson014
{
    // public class App : Application
    public class App : Xamarin.Forms.Application

    {
        public App()
        {
            // The root page of your application
            int clicks = 0;
            Xamarin.Forms.Label label = new Xamarin.Forms.Label
            {
                Text = String.Format("Number of clicks: {0}", clicks),
                VerticalOptions = LayoutOptions.CenterAndExpand,
                HorizontalOptions = LayoutOptions.Center
            };

            Button button = new Button
            {
                Text = "Click on me!",
                VerticalOptions = LayoutOptions.CenterAndExpand,
                HorizontalOptions = LayoutOptions.Center
            };

            button.On<Xamarin.Forms.PlatformConfiguration.Tizen>().SetStyle(ButtonStyle.Default);

            button.Clicked += OnButtonClicked;
            void OnButtonClicked(object sender, EventArgs args)
            {
                clicks++;
                label.Text = String.Format("Number of clicks: {0}", clicks);
            }


            MainPage = new ContentPage
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children = {
                        label,
                        button
                    }
                }
            };
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
