﻿using System;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;

namespace Wearable_lesson22
{
    public class App : Application
    {
        public App()
        {
            CirclePage cp = new CirclePage();
            for (int i = 1; i <= 13; i++)
            {
                ToolbarItem item = new ToolbarItem
                {
                    Text = "tool " + i,
                    Icon = "default.png",
                };
                item.Clicked += Item_Clicked;
                cp.ToolbarItems.Add(item);
            }
            MainPage = cp;
        }

        private void Item_Clicked(object sender, EventArgs e)
        {
            ToolbarItem item = sender as ToolbarItem;
            ContentPage mypage = new ContentPage()
            {
                Content = new StackLayout
                {
                    VerticalOptions = LayoutOptions.Center,
                    Children =
                    {
                        new Label
                        {
                             HorizontalTextAlignment = TextAlignment.Center,
                             Text =  item.Text + " opened!"
                        },
                    }
                }
            };
            MainPage.Navigation.PushModalAsync(mypage);
        }
        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
