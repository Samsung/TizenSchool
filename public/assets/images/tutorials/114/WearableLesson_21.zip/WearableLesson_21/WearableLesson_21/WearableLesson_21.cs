using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace WearableLesson_21
{
    public class App : Application
    {
        public App()
        {
            // The root page of your application
            var image1 = new Image()
            {
                HeightRequest = 400,
                WidthRequest = 300,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };
            image1.Source = "img1.jpg";
            var image2 = new Image()
            {
                HeightRequest = 400,
                WidthRequest = 300,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };
            image2.Source = "img2.jpg";
            var image3 = new Image()
            {
                HeightRequest = 400,
                WidthRequest = 300,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };
            image3.Source = "img3.jpg";
            CirclePage p = new CirclePage();
            CircleScrollView sv = new CircleScrollView()
            {
                Orientation = ScrollOrientation.Horizontal,
                Content = new StackLayout
                {
                    Orientation = StackOrientation.Horizontal,
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center,
                    Children =
                    {
                        image1,
                        image2,
                        image3,
                    }
                }
            };
            p.RotaryFocusObject = sv;
            p.Content = sv;
            MainPage = p;
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
