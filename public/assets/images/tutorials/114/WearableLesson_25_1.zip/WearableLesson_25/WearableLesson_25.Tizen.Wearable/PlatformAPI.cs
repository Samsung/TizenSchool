﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Tizen.Applications;
using WearableLesson_25.Tizen.Wearable;

[assembly: Xamarin.Forms.Dependency(typeof(PlatformAPI))]
namespace WearableLesson_25.Tizen.Wearable
{
    class PlatformAPI : IInterface
    {
       public async Task<List<AppsInfo>> GetApplicationList()
       {
            ApplicationInfoFilter appInfoFilter = new ApplicationInfoFilter();
            appInfoFilter.Filter.Add(ApplicationInfoFilter.Keys.NoDisplay, "false");

            List<AppsInfo> myApps = new List<AppsInfo>();
            IEnumerable<ApplicationInfo> task = await ApplicationManager.GetInstalledApplicationsAsync(appInfoFilter);
            foreach (ApplicationInfo info in task)
            {
                AppsInfo appInfo = new AppsInfo();
                appInfo.Name = info.Label;
                appInfo.AppId = info.ApplicationId;
                appInfo.Icon = info.IconPath;
                myApps.Add(appInfo);
            }
            return myApps;
       }
        public void LaunchApp(string appId)
        {
            AppControl control = new AppControl();
            control.Operation = AppControlOperations.Default;
            control.ApplicationId = appId;
            AppControl.SendLaunchRequest(control);
        }
    }
}
