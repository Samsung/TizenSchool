﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Tizen;

namespace WearableLesson_25
{
    public interface IInterface
    {
        Task<List<AppsInfo>> GetApplicationList();
        void LaunchApp(string appId);
    }
}
