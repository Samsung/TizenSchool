﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WearableLesson_25
{
    public class AppsInfo
    {
        public string Name { get; set; }
        public string AppId { get; set; }
        public string Icon { get; set; }
    }
}
