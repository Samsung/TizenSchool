using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Tizen.Wearable.CircularUI.Forms;

namespace WearableLesson_25
{
    public class App : Application
    {
        CirclePage circlePage = new CirclePage();
        async Task GetAppListAsync()
        {
            List<AppsInfo> appList = await DependencyService.Get<IInterface>().GetApplicationList();
            for (int i = 0; i < appList.Count; i++)
            {
                CircleToolbarItem item = new CircleToolbarItem
                {
                    SubText = appList[i].Name,
                    Icon = appList[i].Icon,
                    Text = appList[i].AppId,
                };
                item.Clicked += Item_Clicked;
                
                circlePage.ToolbarItems.Add(item);
            }
        }

        private void Item_Clicked(object sender, EventArgs e)
        {
             string appId = (sender as CircleToolbarItem).Text;
             DependencyService.Get<IInterface>().LaunchApp(appId);
        }

        public App()
        {
            GetAppListAsync();
            
            MainPage = circlePage;
        }


        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {

        }
    }
}
