﻿using System;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BadgeCounter.Controls
{
    /// <summary>
    /// Control which behaves like button but uses images to define its appearance.
    /// Two images need to be specified, one for default/normal state, second one for pressed state.
    /// Pressed state is simulated by changing image for specified amount of time after tap on the control.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ImageButton : ContentView
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// The control constructor.
        /// </summary>
        public ImageButton()
        {
            InitializeComponent();
        }

        #endregion
    }
}