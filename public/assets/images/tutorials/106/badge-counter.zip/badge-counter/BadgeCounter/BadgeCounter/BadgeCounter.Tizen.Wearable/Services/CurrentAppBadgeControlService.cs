﻿using System;
using BadgeCounter.Models;
using BadgeCounter.Tizen.Wearable.Services;
using global::Tizen.Applications;

namespace BadgeCounter.Tizen.Wearable.Services
{
    /// <summary>
    /// Service which allows to manage badge count for current application.
    /// </summary>
    class CurrentAppBadgeControlService
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// Creates instance of the service.
        /// </summary>
        public CurrentAppBadgeControlService()
        {
        }

        #endregion
    }
}
