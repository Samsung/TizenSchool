﻿using System;

namespace BadgeCounter.Models
{
    /// <summary>
    /// Interface of services which allow to manage badge count for current application.
    /// </summary>
    public interface ICurrentAppBadgeControlService
    {
        #region properties

        /// <summary>
        /// Badge count for current application.
        /// </summary>
        int BadgeCount { get; set; }

        /// <summary>
        /// Event invoked when badge count for current application was changed.
        /// </summary>
        event EventHandler Changed;

        #endregion
    }
}
