﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BadgeCounter
{
    /// <summary>
    /// Xamarin application class for Badge Counter application.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BadgeCounterApp : Application
    {
        #region methods

        /// <summary>
        /// The application constructor.
        /// </summary>
        public BadgeCounterApp()
        {
            InitializeComponent();
        }

        #endregion
    }
}