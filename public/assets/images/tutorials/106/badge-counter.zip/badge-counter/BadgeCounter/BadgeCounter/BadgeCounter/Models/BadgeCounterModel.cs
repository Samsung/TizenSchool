﻿using System;
using Xamarin.Forms;

namespace BadgeCounter.Models
{
    /// <summary>
    /// Model class which allows to manage current application's badge counter.
    /// </summary>
    class BadgeCounterModel
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// Creates instance of the model.
        /// </summary>
        public BadgeCounterModel()
        {
        }

        #endregion
    }
}
