﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BadgeCounter.Views
{
    /// <summary>
    /// Main (and only one) page of the application.
    /// Handles UI logic for the application.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : ContentPage
    {
        /// <summary>
        /// The page constructor.
        /// Creates page structure defined in the XAML file.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
        }
    }
}