﻿using BadgeCounter.Models;
using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace BadgeCounter.ViewModels
{
    /// <summary>
    /// Main view model class for the application.
    /// Encapsulates presentation logic and state of the application.
    /// </summary>
    class MainViewModel : ViewModelBase
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// Creates instance of the view model.
        /// </summary>
        public MainViewModel()
        {
        }

        #endregion
    }
}
