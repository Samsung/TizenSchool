﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BadgeCounter.Controls
{
    /// <summary>
    /// Button control which toggles between two states (toggle switch).
    /// Images for the states and button text are defined as bindable properties.
    /// The control provides simple images morphing animation when state is toggling (only when control is tapped).
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ToggleButton : ContentView
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// Creates instance of the control.
        /// </summary>
        public ToggleButton()
        {
            InitializeComponent();
        }

        #endregion
    }
}