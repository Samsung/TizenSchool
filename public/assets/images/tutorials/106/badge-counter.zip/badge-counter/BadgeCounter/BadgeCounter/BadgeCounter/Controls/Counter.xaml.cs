﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BadgeCounter.Controls
{
    /// <summary>
    /// The control which displays integer value and performs animation during value change.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Counter : ContentView
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region methods

        /// <summary>
        /// Creates the control instance.
        /// </summary>
        public Counter()
        {
            InitializeComponent();
        }

        #endregion
    }
}