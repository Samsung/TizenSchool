using System;

using BarcodeScanner.Tizen.Services.Privilege;

using Xamarin.Forms;

namespace BarcodeScanner
{
    internal class Program : global::Xamarin.Forms.Platform.Tizen.FormsApplication
    {
        protected override void OnCreate()
        {
            base.OnCreate();
            PrivilegeManager.Instance.PrivilegesChecked += OnPrivilegesChecked;
            PrivilegeManager.Instance.CheckPrivileges();
        }

        private void OnPrivilegesChecked(object sender, EventArgs e)
        {
            PrivilegeManager.Instance.PrivilegesChecked -= OnPrivilegesChecked;
            LoadApplication(new App());
        }

        private static void Main(string[] args)
        {
            var app = new Program();
            Forms.Init(app);
            app.Run(args);
        }
    }
}
