﻿
using System;

using BarcodeScanner.Tizen.Renderers;
using BarcodeScanner.Views;

using Tizen.Multimedia;

using Xamarin.Forms;
using Xamarin.Forms.Platform.Tizen;

[assembly: ExportRenderer(typeof(CameraView), typeof(CameraViewRenderer))]
namespace BarcodeScanner.Tizen.Renderers
{
    /// <summary>
    /// Tizen-specific renderer for <see cref="CameraView"/>.
    /// </summary>
    public class CameraViewRenderer : VisualElementRenderer<CameraView>
    {
        private MediaView mediaView;

        protected override void OnElementChanged(ElementChangedEventArgs<CameraView> e)
        {
            if (mediaView is null)
            {
                mediaView = new MediaView(Forms.NativeParent);
                SetNativeView(mediaView);
            }

            if (e.OldElement is object)
            {
                mediaView.Resized -= MediaViewResized;
            }

            if (e.NewElement is object)
            {
                mediaView.Resized += MediaViewResized;
                Element.CameraPreview = mediaView;
                (Element as CameraView)?.InvokeCameraViewCreated();
            }

            base.OnElementChanged(e);
        }

        private void MediaViewResized(object sender, EventArgs e)
        {
            ((CameraView)Element).NativeSizeChanged();
        }
    }
}
