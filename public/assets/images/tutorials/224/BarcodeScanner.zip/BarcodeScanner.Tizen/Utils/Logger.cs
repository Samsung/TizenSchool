﻿using System;
using System.Runtime.CompilerServices;
using TLog = Tizen.Log;

namespace BarcodeScanner.Tizen.Utils
{
    /// <summary>
    /// Class with static methods for the purpose of logging.
    /// </summary>
    internal class Logger
    {
        private const string LogTag = "BarcodeScanner";

        /// <summary>
        /// Writes the given message to the Debug logging channel.
        /// </summary>
        /// <param name="message">Message to be logged.</param>
        internal static void Log(string message)
        {
            TLog.Debug(LogTag, message);
        }

        /// <summary>
        /// Writes the given exception's message and stack trace to the Debug logging channel.
        /// </summary>
        /// <param name="exception">Exception to be logged.</param>
        internal static void Log(Exception exception)
        {
            var message = $"{exception.Message}\n{exception.StackTrace}";
            Log(message);
        }

        /// <summary>
        /// Writes a log message with the ERROR priority.
        /// </summary>
        /// <param name="message">The log message to print.</param>
        /// <param name="file">The source file path of the caller function. This argument will be set automatically by the compiler.</param>
        /// <param name="func">The function name of the caller function. This argument will be set automatically by the compiler.</param>
        /// <param name="line">The line number of the calling position. This argument will be set automatically by the compiler.</param>
        internal static void Error(string msg = "", [CallerFilePath] string file = "", [CallerMemberName] string func = "", [CallerLineNumber] int line = 0)
        {
            TLog.Error(LogTag, msg, file, func, line);
        }
    }
}
