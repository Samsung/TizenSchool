﻿namespace BarcodeScanner.Tizen.Services.Privilege
{
    /// <summary>
    /// Model for privileges.
    /// </summary>
    public class Privilege
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Privilege"/> class.
        /// </summary>
        /// <param name="key">Key of the privilege.</param>
        public Privilege(string key)
        {
            Key = key;
        }

        /// <summary>
        /// Gets a value indicating whether the privilege has been checked.
        /// </summary>
        public bool Checked { get; private set; } = false;

        /// <summary>
        /// Gets a value indicating whether the privilege has been granted.
        /// </summary>
        public bool Granted { get; private set; } = false;

        /// <summary>
        /// Gets the key of the privilege.
        /// </summary>
        public string Key { get; }

        /// <summary>
        /// Denies the privilege, setting it's <see cref="Granted"/> value to <c>false</c>.
        /// Also sets the privilege's <see cref="Checked"/> value to <c>true</c>.
        /// </summary>
        public void Deny()
        {
            Checked = true;
            Granted = false;
        }

        /// <summary>
        /// Grants the privilege, setting it's <see cref="Granted"/> value to <c>true</c>.
        /// Also sets the privilege's <see cref="Checked"/> value to <c>true</c>.
        /// </summary>
        public void Grant()
        {
            Checked = true;
            Granted = true;
        }
    }
}
