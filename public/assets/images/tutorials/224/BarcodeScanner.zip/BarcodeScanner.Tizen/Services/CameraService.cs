﻿using System;
using System.Collections.Generic;
using System.Linq;

using BarcodeScanner.Services;
using BarcodeScanner.Services.Args;
using BarcodeScanner.Tizen.Utils;

using Tizen.Multimedia;
using Tizen.Multimedia.Vision;

using Xamarin.Forms;

using TSize = Tizen.Multimedia.Size;

[assembly: Dependency(typeof(CameraService))]

namespace BarcodeScanner.Services
{
    /// <summary>
    /// Tizen-specific implementation of <see cref="ICameraService" />.
    /// </summary>
    public sealed class CameraService : ICameraService
    {
        private static BarcodeDetectionConfiguration configuration;
        private readonly Camera camera;
        private readonly IRepository<Models.Barcode> repository;

        static CameraService()
        {
            configuration = new BarcodeDetectionConfiguration()
            {
                Target = BarcodeDetectionTarget.All,
            };
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CameraService" /> class.
        /// </summary>
        public CameraService()
        {
            camera = new Camera(CameraDevice.Rear);
            InitializeCamera();

            repository = new JsonFileRepository<Models.Barcode>("barcodes.json");
            LoadSavedBarcodes();
        }

        /// <inheritdoc />
        public event EventHandler<BarcodeDetectedEventArgs> BarcodeDetected;

        /// <inheritdoc />
        public ICollection<Models.Barcode> Barcodes { get; private set; }

        /// <inheritdoc />
        public void InitializeCameraDisplay(object mediaView)
        {
            if (mediaView is MediaView mv)
            {
                camera.Display = new Display(mv);
            }
        }

        /// <inheritdoc />
        public void StartCameraPreview()
        {
            if (camera.State is CameraState.Created)
            {
                try
                {
                    camera.StartPreview();
                    bool autofocusIsSupported = camera.Capabilities.SupportedAutoFocusModes
                                                                    .Contains(CameraAutoFocusMode.Normal);
                    if (autofocusIsSupported)
                    {
                        camera.StartFocusing(true);
                    }
                }
                catch (Exception e)
                {
                    Logger.Log(e);
                }
            }
        }

        ///<inheritdoc/>
        public void StartDetection()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                camera.Preview -= OnPreviewUpdated;
                camera.Preview += OnPreviewUpdated;
            });
        }

        /// <inheritdoc />
        public void StopDetection()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                camera.Preview -= OnPreviewUpdated;
            });
        }

        private TSize GetBestPreviewResolutionByRatio(double ratio)
        {
            return camera.Capabilities.SupportedPreviewResolutions.LastOrDefault(res => res.Width / res.Height == ratio);
        }

        private byte[] GetImageBufferFromPlane(IPreviewPlane plane) =>
            plane switch
            {
                SinglePlane p => p.Data,
                DoublePlane p => p.Y.Concat(p.UV)
                                    .ToArray(),
                TriplePlane p => p.Y.Concat(p.U)
                                    .Concat(p.V)
                                    .ToArray(),
                DepthPlane p => p.Data,
                EncodedPlane p => p.Data,
                RgbPlane p => p.Data,
                _ => null,
            };

        private void InitializeCamera()
        {
            try
            {
                camera.Settings.PreviewResolution = GetBestPreviewResolutionByRatio(3 / 4);
                camera.DisplaySettings.Mode = CameraDisplayMode.Full;
                camera.Settings.PreviewPixelFormat = CameraPixelFormat.I420;
                camera.Settings.EnableTag = false;
                camera.Settings.ImageQuality = 100;
            }
            catch (Exception e)
            {
                Logger.Log(e);
            }
        }

        private void LoadSavedBarcodes()
        {
            Barcodes = repository.GetAll().ToList();
        }

        private async void OnPreviewUpdated(object sender, PreviewEventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                Logger.Log(ex);
            }
        }

        private void SaveBarcodes()
        {
            repository.SaveAll(Barcodes);
        }
    }
}
