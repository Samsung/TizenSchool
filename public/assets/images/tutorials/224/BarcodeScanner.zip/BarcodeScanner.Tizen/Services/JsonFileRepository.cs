﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using Newtonsoft.Json;

namespace BarcodeScanner.Services
{
    /// <summary>
    /// Repository with JSON file storage.
    /// </summary>
    /// <typeparam name="T">Model object type.</typeparam>
    public class JsonFileRepository<T> : IRepository<T>
    {
        private static readonly object obj = new object();
        private readonly string path;

        /// <summary>
        /// Initializes a new instance of the <see cref="JsonFileRepository" /> class.
        /// </summary>
        public JsonFileRepository(string filename = "saved_data.json")
        {
            path = Path.Combine(Program.Current.DirectoryInfo.Data, filename);
        }

        /// <summary>
        /// Adds item to the JSON file.
        /// </summary>
        /// <param name="item">Item to be added into repository.</param>
        public void Add(T item)
        {
            var items = GetAll();
            items.Append(item);
            SaveAll(items);
        }

        /// <summary>
        /// Gets all items from the JSON file.
        /// </summary>
        /// <returns>Collection of items.</returns>
        public IEnumerable<T> GetAll()
        {
            bool acquiredLock = false;

            IEnumerable<T> items = null;
            try
            {
                Monitor.Enter(obj, ref acquiredLock);
                string text = File.ReadAllText(path);
                items = JsonConvert.DeserializeObject<IEnumerable<T>>(text);
            }
            catch (Exception exception)
            {
                BarcodeScanner.Tizen.Utils.Logger.Error(exception.StackTrace);
            }
            finally
            {
                if (acquiredLock)
                {
                    Monitor.Exit(obj);
                }
                items ??= new List<T>();
            }
            return items;
        }

        /// <summary>
        /// Saves all items into JSON file.
        /// </summary>
        /// <param name="items">Collection of item to be saved into repository.</param>
        public void SaveAll(IEnumerable<T> items)
        {
            bool acquiredLock = false;
            try
            {
                Monitor.Enter(obj, ref acquiredLock);
                string text = JsonConvert.SerializeObject(items);
                File.WriteAllText(path, text);
            }
            catch (Exception exception)
            {
                BarcodeScanner.Tizen.Utils.Logger.Error(exception.StackTrace);
            }
            finally
            {
                if (acquiredLock)
                {
                    Monitor.Exit(obj);
                }
            }
        }
    }
}
