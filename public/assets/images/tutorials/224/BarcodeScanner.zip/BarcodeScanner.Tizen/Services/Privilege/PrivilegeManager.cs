﻿using System;
using System.Collections.Generic;
using System.Linq;

using Tizen.Security;

namespace BarcodeScanner.Tizen.Services.Privilege
{
    /// <summary>
    /// Manager for privileges and their status.
    /// </summary>
    public sealed class PrivilegeManager
    {
        private static readonly string cameraPrivilegeKey = @"http://tizen.org/privilege/camera";
        private readonly IEnumerable<Privilege> privileges;

        static PrivilegeManager()
        {
            Instance = new PrivilegeManager();
        }

        private PrivilegeManager()
        {
            privileges = new List<Privilege>()
            {
                new Privilege(cameraPrivilegeKey),
            };
        }

        /// <summary>
        /// Event invoked when all privileges are checked.
        /// </summary>
        public event EventHandler PrivilegesChecked;

        /// <summary>
        /// Gets the instance of the <see cref="PrivilegeManager"/> class.
        /// </summary>
        public static PrivilegeManager Instance { get; }

        /// <summary>
        /// Gets a value indicating whether all privileges are checked.
        /// </summary>
        public bool AllPrivilegesChecked => privileges.All(privilege => privilege.Checked);

        /// <summary>
        /// Performs a check of application privileges.
        /// </summary>
        public void CheckPrivileges()
        {
            foreach (var privilege in privileges)
            {
                switch (PrivacyPrivilegeManager.CheckPermission(privilege.Key))
                {
                    case CheckResult.Allow:
                        privilege.Grant();
                        break;

                    case CheckResult.Ask:
                        RequestPrivilege(privilege);
                        break;

                    default:
                        privilege.Deny();
                        break;
                };
            }

            TryInvokePrivilegesChecked();
        }

        private void OnRequestResponse(object sender, RequestResponseEventArgs e)
        {
            if (e.cause is CallCause.Answer)
            {
                var privilege = privileges.FirstOrDefault(p =>
                    p.Key == e.privilege);

                switch (e.result)
                {
                    case RequestResult.AllowForever:
                        privilege.Grant();
                        break;

                    default:
                        privilege.Deny();
                        break;
                }
            }

            TryInvokePrivilegesChecked();
        }

        private void RequestPrivilege(Privilege privilege)
        {
            PrivacyPrivilegeManager.GetResponseContext(privilege.Key)
                .TryGetTarget(out PrivacyPrivilegeManager.ResponseContext context);

            if (context != null)
            {
                context.ResponseFetched += OnRequestResponse;
            }

            PrivacyPrivilegeManager.RequestPermission(privilege.Key);
            PrivacyPrivilegeManager.GetResponseContext(privilege.Key)
                .TryGetTarget(out context);
        }

        private void TryInvokePrivilegesChecked()
        {
            if (AllPrivilegesChecked)
            {
                PrivilegesChecked?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
