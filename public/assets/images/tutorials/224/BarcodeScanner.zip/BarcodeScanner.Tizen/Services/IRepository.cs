﻿using System.Collections.Generic;

namespace BarcodeScanner.Services
{
    /// <summary>
    /// Interface for repository.
    /// </summary>
    /// <typeparam name="T">Model object type.</typeparam>
    public interface IRepository<T>
    {
        /// <summary>
        /// Adds item to the repository.
        /// </summary>
        /// <param name="item">Item to be added into repository.</param>
        void Add(T item);

        /// <summary>
        /// Gets all items from the repository.
        /// </summary>
        /// <returns>Collection of items.</returns>
        IEnumerable<T> GetAll();

        /// <summary>
        /// Saves all items into repository.
        /// </summary>
        /// <param name="items">Collection of item to be saved into repository.</param>
        void SaveAll(IEnumerable<T> items);
    }
}
