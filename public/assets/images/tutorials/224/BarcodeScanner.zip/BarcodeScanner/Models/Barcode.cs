using System;

namespace BarcodeScanner.Models
{
    /// <summary>
    /// Model of the barcode.
    /// </summary>
    public class Barcode
    {
        /// <summary>
        /// Gets or sets the date of scan.
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets the message encoded in the barcode.
        /// </summary>
        public string Message { get; set; }
    }
}
