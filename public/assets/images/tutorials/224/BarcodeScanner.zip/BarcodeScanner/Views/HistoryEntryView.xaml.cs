﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarcodeScanner.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HistoryEntryView : ContentView
    {
        public HistoryEntryView()
        {
            InitializeComponent();
        }

        private void OnButtonClicked(object sender, EventArgs e)
        {
            MessageLabel.IsVisible = !MessageLabel.IsVisible;
            var cell = Parent as ViewCell;
            cell?.ForceUpdateSize();
        }
    }
}
