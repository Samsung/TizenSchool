﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarcodeScanner.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : Shell
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
