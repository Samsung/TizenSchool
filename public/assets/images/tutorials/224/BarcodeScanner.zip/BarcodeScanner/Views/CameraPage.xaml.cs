﻿using System;

using BarcodeScanner.Services;
using BarcodeScanner.ViewModels;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarcodeScanner.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CameraPage : ContentPage
    {
        public CameraPage()
        {
            InitializeComponent();
            CameraViewControl.CameraViewCreated += OnCameraViewControlCreated;
        }

        private void OnPageDisappearing(object sender, EventArgs e)
        {
            (BindingContext as CameraViewModel)?.PageDisappearingCommand
                .Execute(null);
        }

        private void OnPageAppearing(object sender, EventArgs e)
        {
            (BindingContext as CameraViewModel)?.PageAppearingCommand
                .Execute(null);
        }

        private void OnCameraViewControlCreated(object sender, EventArgs e)
        {
            var cameraService = DependencyService.Get<ICameraService>();
            cameraService.InitializeCameraDisplay(CameraViewControl.CameraPreview);
            cameraService.StartCameraPreview();
        }
    }
}
