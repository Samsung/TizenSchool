﻿using System;

using Xamarin.Forms;

namespace BarcodeScanner.Views
{
    /// <summary>
    /// Custom view used to display camera preview.
    /// </summary>
    public class CameraView : View
    {
        public static readonly BindableProperty CameraPreviewProperty = BindableProperty.Create(
            propertyName: nameof(CameraPreview),
            returnType: typeof(object),
            declaringType: typeof(CameraView),
            defaultValue: default
        );

        /// <summary>
        /// Event raised when the view is created.
        /// </summary>
        public event EventHandler CameraViewCreated;

        /// <summary>
        /// Gets or sets the CameraPreview control.
        /// </summary>
        public object CameraPreview
        {
            get => GetValue(CameraPreviewProperty);
            set => SetValue(CameraPreviewProperty, value);
        }

        /// <summary>
        /// Invokes the <see cref="CameraViewCreated"/> event.
        /// </summary>
        public void InvokeCameraViewCreated()
        {
            CameraViewCreated?.Invoke(this, EventArgs.Empty);
        }
    }
}
