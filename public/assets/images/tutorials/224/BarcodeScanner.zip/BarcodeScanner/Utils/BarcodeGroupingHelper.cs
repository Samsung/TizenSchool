﻿
using BarcodeScanner.Models;

namespace BarcodeScanner.Utils
{
    public class BarcodeGroupingHelper
    {
        public BarcodeGroupingHelper()
        {
        }

        public string GetGroupingHeader(Barcode barcode)
        {
            return "";
        }
    }
}
