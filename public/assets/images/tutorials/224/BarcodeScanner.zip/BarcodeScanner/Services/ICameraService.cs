﻿using System;
using System.Collections.Generic;

using BarcodeScanner.Models;
using BarcodeScanner.Services.Args;

namespace BarcodeScanner.Services
{
    /// <summary>
    /// Interface for camera service.
    /// </summary>
    public interface ICameraService
    {
        /// <summary>
        /// Event raised when a barcode is detected.
        /// </summary>
        event EventHandler<BarcodeDetectedEventArgs> BarcodeDetected;

        /// <summary>
        /// Gets the collection of previously detected barcodes.
        /// </summary>
        ICollection<Barcode> Barcodes { get; }

        /// <summary>
        /// Sets the view that will be used to display the camera preview.
        /// </summary>
        /// <param name="mediaView">The view to be used as the camera preview.</param>
        void InitializeCameraDisplay(object mediaView);

        /// <summary>
        /// Starts the camera preview.
        /// </summary>
        void StartCameraPreview();

        /// <summary>
        /// Starts barcode detection.
        /// </summary>
        void StartDetection();

        /// <summary>
        /// Stops barcode detection.
        /// </summary>
        void StopDetection();
    }
}
