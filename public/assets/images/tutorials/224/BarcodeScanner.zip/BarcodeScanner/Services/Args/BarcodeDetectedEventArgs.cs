﻿using System;

using BarcodeScanner.Models;

namespace BarcodeScanner.Services.Args
{
    /// <summary>
    /// EventArgs for the <see cref="IBarcodeService.BarcodeDetected"/> event.
    /// </summary>
    public class BarcodeDetectedEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BarcodeDetectedEventArgs"/> class.
        /// </summary>
        /// <param name="barcode">The detected barcode.</param>
        public BarcodeDetectedEventArgs(Barcode barcode)
        {
            Barcode = barcode;
        }

        /// <summary>
        /// Gets the detected barcode.
        /// </summary>
        public Barcode Barcode { get; }
    }
}
