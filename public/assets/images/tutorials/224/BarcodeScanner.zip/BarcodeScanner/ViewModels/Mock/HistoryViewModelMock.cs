﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using BarcodeScanner.Models;

namespace BarcodeScanner.ViewModels.Mock
{
    public class HistoryViewModelMock
    {
        private static readonly DateTime Today = DateTime.Now.Date;

        public HistoryViewModelMock()
        {
            Barcodes = CreateMockBarcodes();
        }

        public ObservableCollection<Barcode> Barcodes { get; }

        private static Barcode Create(DateTime date, string message) =>
                    new Barcode()
                    {
                        Date = date,
                        Message = message,
                    };

        private static ObservableCollection<Barcode> CreateMockBarcodes()
        {
            {
                var enumerator = Enumerable.Range(1, 9);
                var collection = new List<Barcode>();
                // Today
                foreach (int number in enumerator.Take(2))
                {
                    collection.Add(
                        Create(Today, $"Mock barcode today #{number}"));
                }

                // Yesterday
                foreach (int number in enumerator.Take(3))
                {
                    collection.Add(
                        Create(Today.AddDays(-1), $"Mock barcode yesterday #{number}"));
                }

                // Last week
                foreach (int number in enumerator.Take(5))
                {
                    collection.Add(
                        Create(Today.AddDays(-7), $"Mock barcode last week #{number}"));
                }

                // This year
                foreach (int monthDiff in enumerator.Take(3))
                {
                    foreach (int number in enumerator.Take(4))
                    {
                        collection.Add(
                            Create(Today.AddMonths(-monthDiff), $"Mock barcode last month #{number}"));
                    }
                }

                // Last year
                foreach (int number in enumerator)
                {
                    collection.Add(
                        Create(Today.AddYears(-1), $"Mock barcode last year #{number}"));
                }

                // Previous years
                foreach (int yearDiff in enumerator.Take(4))
                {
                    foreach (int number in enumerator.Take(6))
                    {
                        collection.Add(
                            Create(Today.AddYears(-yearDiff), $"Mock barcode previous years #{number}"));
                    }
                }

                return new ObservableCollection<Barcode>(collection);
            }
        }
    }
}
