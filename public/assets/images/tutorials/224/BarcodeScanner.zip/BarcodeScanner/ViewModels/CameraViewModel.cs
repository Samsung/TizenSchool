﻿using System.Windows.Input;

using BarcodeScanner.Models;
using BarcodeScanner.Services;
using BarcodeScanner.Services.Args;

using Xamarin.Forms;

namespace BarcodeScanner.ViewModels
{
    public class CameraViewModel : ViewModelBase
    {
        private readonly ICameraService cameraService;
        private Barcode barcode;
        private bool isScanning;

        /// <summary>
        /// Gets or sets the detected barcode.
        /// </summary>
        public Barcode Barcode
        {
            get => barcode;
            set => SetProperty(ref barcode, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether the camera preview will be scanned for barcodes.
        /// </summary>
        public bool IsScanning
        {
            get => isScanning;
            set => SetProperty(ref isScanning, value);
        }

        /// <summary>
        /// Gets the command to handle the PageDisappearing behavior.
        /// </summary>
        public ICommand PageDisappearingCommand { get; }

        /// <summary>
        /// Gets the command to handle the PageAppearing behavior.
        /// </summary>
        public ICommand PageAppearingCommand { get; }

        /// <summary>
        /// Gets the command to start scanning for barcodes in the camera preview.
        /// </summary>
        public ICommand StartScanningCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CameraViewModel"/> class.
        /// </summary>
        public CameraViewModel()
        {
            cameraService = DependencyService.Get<ICameraService>();
            cameraService.BarcodeDetected += OnBarcodeDetected;
            cameraService.StartDetection();

            PageAppearingCommand = new Command(StartBarcodeDetection);
            PageDisappearingCommand = new Command(StopBarcodeDetection);
            StartScanningCommand = new Command(StartBarcodeDetection);
        }

        private void StopBarcodeDetection()
        {
            cameraService.StopDetection();
            IsScanning = false;
        }

        private void StartBarcodeDetection()
        {
            Barcode = null;
            IsScanning = true;
            cameraService.StartDetection();
        }

        private void OnBarcodeDetected(object sender, BarcodeDetectedEventArgs e)
        {
            Barcode = e.Barcode;
            StopBarcodeDetection();
        }
    }
}
