﻿using System.Collections.ObjectModel;

using BarcodeScanner.Models;
using BarcodeScanner.Services;
using BarcodeScanner.Services.Args;
using BarcodeScanner.ViewModels.Mock;

using Xamarin.Forms;

namespace BarcodeScanner.ViewModels
{
    public class HistoryViewModel : ViewModelBase
    {
        private ICameraService cameraService;

        private ObservableCollection<Barcode> barcodes;

        public HistoryViewModel()
        {
            cameraService = DependencyService.Get<ICameraService>();
            Barcodes = GetBarcodes();

            cameraService.BarcodeDetected += OnBarcodeDetected;
        }

        private void OnBarcodeDetected(object sender, BarcodeDetectedEventArgs e)
        {
            Barcodes = GetBarcodes();
        }

        private ObservableCollection<Barcode> GetBarcodes()
        {
            var barcodesCollection = new ObservableCollection<Barcode>(cameraService.Barcodes);
            if (barcodesCollection.Count is 0)
            {
                barcodesCollection = new HistoryViewModelMock().Barcodes;
            }

            return barcodesCollection;
        }

        public ObservableCollection<Barcode> Barcodes
        {
            get => barcodes;
            set => SetProperty(ref barcodes, value);
        }
    }
}
