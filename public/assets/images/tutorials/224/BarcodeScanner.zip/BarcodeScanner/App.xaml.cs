﻿using BarcodeScanner.Views;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarcodeScanner
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented", Justification = "Pre-generated code.")]
    public partial class App : Application
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1600:Elements should be documented", Justification = "Pre-generated code.")]
        public App()
        {
            InitializeComponent();

            MainPage = new MainPage();
        }
    }
}
