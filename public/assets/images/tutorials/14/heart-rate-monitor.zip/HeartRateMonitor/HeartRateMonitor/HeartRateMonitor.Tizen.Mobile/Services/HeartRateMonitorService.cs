﻿using System;
using HeartRateMonitor.Models;
using HeartRateMonitor.Tizen.Mobile.Services;
using Tizen.Sensor;
using HRM = Tizen.Sensor.HeartRateMonitor;

[assembly: Xamarin.Forms.Dependency(typeof(HeartRateMonitorService))]
namespace HeartRateMonitor.Tizen.Mobile.Services
{
    /// <summary>
    /// HeartRateMonitorService class.
    /// Provides methods that allow the application to use the Tizen Sensor API.
    /// Implements IHeartRateMonitorService interface to be available
    /// from portable part of the application source code.
    /// </summary>
    public class HeartRateMonitorService : IHeartRateMonitorService
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// HeartRateMonitorDataChanged event.
        /// It notifies UI about heart rate value update.
        /// </summary>
        public event EventHandler HeartRateMonitorDataChanged;

        #endregion

        #region methods

        /// <summary>
        /// Initializes HeartRateMonitorService class.
        /// </summary>
        public void Init()
        {

        }

        /// <summary>
        /// Returns current heart rate value provided by the Tizen Sensor API.
        /// </summary>
        /// <returns>Current heart rate value provided by the Tizen Sensor API.</returns>
        public int GetHeartRate()
        {
            return 0;
        }

        /// <summary>
        /// Starts notification about changes of heart rate value.
        /// </summary>
        public void StartHeartRateMonitor()
        {

        }

        /// <summary>
        /// Stops notification about changes of heart rate value.
        /// </summary>
        public void StopHeartRateMonitor()
        {

        }

        #endregion
    }
}