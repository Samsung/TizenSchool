﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HeartRateMonitor.Views
{
    /// <summary>
    /// SettingsPage class.
    /// Provides logic for UI SettingsPage.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SettingsPage : ContentPage
    {
        #region methods

        /// <summary>
        /// SettingsPage class constructor.
        /// </summary>
        public SettingsPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}