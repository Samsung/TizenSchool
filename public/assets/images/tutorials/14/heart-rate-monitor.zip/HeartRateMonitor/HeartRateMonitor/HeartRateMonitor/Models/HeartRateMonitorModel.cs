﻿using System;
using Xamarin.Forms;

namespace HeartRateMonitor.Models
{
    /// <summary>
    /// HeartRateMonitorModel class.
    /// Provides methods that allow the application to use the Tizen Sensor API.
    /// </summary>
    public class HeartRateMonitorModel
    {
        #region properties

        /// <summary>
        /// HeartRateMonitorDataChanged event.
        /// It notifies UI about heart rate value update.
        /// </summary>
        public event EventHandler HeartRateMonitorDataChanged;

        #endregion

        #region methods

        /// <summary>
        /// HeartRateMonitorModel class constructor.
        /// </summary>
        public HeartRateMonitorModel()
        {
            var service = DependencyService.Get<IHeartRateMonitorService>();

            service.HeartRateMonitorDataChanged += ServiceOnHeartRateMonitorDataChanged;

            DependencyService.Get<IHeartRateMonitorService>().Init();
        }

        /// <summary>
        /// Returns current heart rate value provided by the Tizen Sensor API.
        /// </summary>
        /// <returns>Current heart rate value provided by the Tizen Sensor API.</returns>
        public int GetHeartRate()
        {
            return DependencyService.Get<IHeartRateMonitorService>().GetHeartRate();
        }

        /// <summary>
        /// Starts notification about changes of heart rate value.
        /// </summary>
        public void StartHeartRateMonitor()
        {
            DependencyService.Get<IHeartRateMonitorService>().StartHeartRateMonitor();
        }

        /// <summary>
        /// Stops notification about changes of heart rate value.
        /// </summary>
        public void StopHeartRateMonitor()
        {
            DependencyService.Get<IHeartRateMonitorService>().StopHeartRateMonitor();
        }

        /// <summary>
        /// Handles "HeartRateMonitorDataChanged" of the IHeartRateMonitorService object.
        /// Invokes "HeartRateMonitorDataChanged" to other application's modules.
        /// </summary>
        private void ServiceOnHeartRateMonitorDataChanged(object sender, EventArgs e)
        {
            HeartRateMonitorDataChanged?.Invoke(this, new EventArgs());
        }

        #endregion
    }
}