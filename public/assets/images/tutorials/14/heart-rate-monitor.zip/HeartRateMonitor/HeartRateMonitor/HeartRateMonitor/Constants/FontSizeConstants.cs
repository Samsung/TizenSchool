﻿namespace HeartRateMonitor.Constants
{
    /// <summary>
    /// FontSizeConstants class.
    /// Provides definition of font sizes used in application.
    /// </summary>
    public class FontSizeConstants
    {
        #region fields

        /// <summary>
        /// Primary font size used in the applicaiton.
        /// </summary>
        public static readonly double BASE_LABEL_FONT_SIZE = 30;

        /// <summary>
        /// Font size used by the application's message labels.
        /// </summary>
        public static readonly double MESSAGE_LABEL_FONT_SIZE = 24;

        /// <summary>
        /// Font size used by the application's heart rate unit labels.
        /// </summary>
        public static readonly double HEART_RATE_VALUE_UNIT_FONT_SIZE = 24;

        /// <summary>
        /// Font size used by the application's heart rate value labels.
        /// </summary>
        public static readonly double HEART_RATE_VALUE_TEXT_FONT_SIZE = 60;

        /// <summary>
        /// Font size used by the application's heart rate limit value.
        /// </summary>
        public static readonly double HEART_RATE_LIMIT_LABEL_FONT_SIZE = 15;

        #endregion
    }
}