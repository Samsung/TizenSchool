using HeartRateMonitor.Constants;
using HeartRateMonitor.Navigation;
using HeartRateMonitor.ViewModels;
using HeartRateMonitor.Views;
using Xamarin.Forms;

namespace HeartRateMonitor
{
    /// <summary>
    /// App class.
    /// </summary>
    public class App : Application
    {
        #region properties

        /// <summary>
        /// An instance of the MainViewModel class.
        /// </summary>
        public MainViewModel AppMainViewModel { private set; get; }

        #endregion

        #region methods

        /// <summary>
        /// App class constructor.
        /// </summary>
        public App()
        {
            MainPage = new NavigationPage(new MeasurementPage())
            {
                BarBackgroundColor = ColorConstants.BASE_APP_COLOR
            };
        }

        #endregion
    }
}