﻿using Xamarin.Forms;

namespace HeartRateMonitor.Constants
{
    /// <summary>
    /// ColorConstants class.
    /// Provides definition of colors used in application.
    /// </summary>
    public class ColorConstants
    {
        #region fields

        /// <summary>
        /// Primary color used in the applicaiton.
        /// </summary>
        public static readonly Color BASE_APP_COLOR = Color.FromRgb(209, 77, 77);

        /// <summary>
        /// Color used by the application's buttons labels.
        /// </summary>
        public static readonly Color BUTTON_TEXT_COLOR = Color.FromRgb(255, 255, 255);

        /// <summary>
        /// Color used by the page's backgrounds.
        /// </summary>
        public static readonly Color PAGE_BACKGROUND_COLOR = Color.FromRgb(255, 255, 255);

        /// <summary>
        /// Color used by labels on the welcome layer.
        /// </summary>
        public static readonly Color WELCOME_TEXT_COLOR = Color.FromRgb(250, 250, 250);

        /// <summary>
        /// Color used by labels displaying heart rate value.
        /// </summary>
        public static readonly Color HEART_RATE_VALUE_TEXT_COLOR = Color.FromRgb(0, 0, 0);

        /// <summary>
        /// Color used by page's title labels.
        /// </summary>
        public static readonly Color PAGE_TITLE_TEXT_COLOR = Color.FromRgb(0, 0, 0);

        /// <summary>
        /// Color used by page's message labels.
        /// </summary>
        public static readonly Color PAGE_MESSAGE_TEXT_COLOR = Color.FromRgb(115, 115, 115);

        /// <summary>
        /// Color used by label displaying heart rate value to indicate disabled digits.
        /// </summary>
        public static readonly Color HEART_RATE_VALUE_DISABLED_TEXT_COLOR = Color.FromRgb(214, 214, 214);

        /// <summary>
        /// Color used by label displaying heart rate unit.
        /// </summary>
        public static readonly Color HEART_RATE_VALUE_UNIT_COLOR = Color.FromRgb(214, 214, 214);

        /// <summary>
        /// Color used by label displaying heart rate limit value.
        /// </summary>
        public static readonly Color HEART_RATE_LIMIT_LABEL_COLOR = Color.FromRgb(214, 214, 214);

        #endregion
    }
}