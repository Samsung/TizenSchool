﻿using System;
using System.Threading.Tasks;
using HeartRateMonitor.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HeartRateMonitor.Views
{
    /// <summary>
    /// MeasurementPage class.
    /// Provides logic for UI MeasurementPage.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MeasurementPage : ContentPage
    {
        #region fields

        #endregion

        #region methods

        /// <summary>
        /// MeasurementPage class constructor.
        /// </summary>
        public MeasurementPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}