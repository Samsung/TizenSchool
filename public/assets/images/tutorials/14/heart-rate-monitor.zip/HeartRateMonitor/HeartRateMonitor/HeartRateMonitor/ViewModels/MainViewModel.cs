﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using HeartRateMonitor.Models;
using HeartRateMonitor.Navigation;
using Xamarin.Forms;

namespace HeartRateMonitor.ViewModels
{
    /// <summary>
    /// MainViewModel class.
    /// Provides commands and methods responsible for application view model state.
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region fields

        #endregion

        #region properties

        /// <summary>
        /// Sets a property of the view model indicating that the application is in started state.
        /// </summary>
        public ICommand GetStartedCommand { private set; get; }

        /// <summary>
        /// Starts and stops measurement process.
        /// </summary>
        public ICommand ToggleMeasurementCommand { private set; get; }

        /// <summary>
        /// Prepares view model state before displaying SettingsPage.
        /// </summary>
        public ICommand ShowSettingsCommand { private set; get; }

        /// <summary>
        /// Updates view model properties responsible for UI representation of heart rate limit.
        /// </summary>
        public ICommand UpdateHeartRateLimitCommand { private set; get; }

        #endregion

        #region methods

        /// <summary>
        /// MainViewModel class constructor.
        /// </summary>
        /// <param name="properties"></param>
        /// <param name="pageMavigation"></param>
        public MainViewModel(IDictionary<string, object> properties, PageNavigation pageMavigation)
        {
            GetStartedCommand = new Command(ExecuteGetStartedCommand);
            ToggleMeasurementCommand = new Command(ExecuteToggleMeasurementCommand);
            ShowSettingsCommand = new Command(ExecuteShowSettingsCommand, CanExecuteShowSettingsCommand);
            UpdateHeartRateLimitCommand = new Command(ExecuteUpdateHeartRateLimitCommand);
        }

        /// <summary>
        /// Executes UpdateHeartRateLimitCommand command.
        /// Updates value of the HeartRateLimitSliderValue property.
        /// Navigates back to the measurement page by executing NavigateBackCommand command
        /// of the PageNavigation class.
        /// </summary>
        private void ExecuteUpdateHeartRateLimitCommand()
        {

        }

        /// <summary>
        /// Checks whether the ShowSettingsCommand command can be executed.
        /// </summary>
        /// <param name="arg"></param>
        /// <returns>Returns true if the ShowSettingsCommand can be executed, false otherwise.</returns>
        private bool CanExecuteShowSettingsCommand(object arg)
        {
            return false;
        }

        /// <summary>
        /// Executes the ShowSettingsCommand command.
        /// Updates value of the HeartRateLimitSliderBufferValue property.
        /// Navigates to the settings page by executing NavigateToCommand command
        /// of the PageNavigation class.
        /// </summary>
        /// <param name="obj"></param>
        private void ExecuteShowSettingsCommand(object obj)
        {

        }

        /// <summary>
        /// Executes the GetStartedCommand command.
        /// Updates value of the IsStarted property.
        /// </summary>
        private void ExecuteGetStartedCommand()
        {

        }

        /// <summary>
        /// Executes the ToggleMeasurementCommand command.
        /// Depending on the IsMeasuring property state it starts or stops measurement process.
        /// Additionally it calls ChangeCanExecute method
        /// to update execution state of the ShowSettingsCommand command.
        /// </summary>
        private void ExecuteToggleMeasurementCommand()
        {

        }

        #endregion
    }
}