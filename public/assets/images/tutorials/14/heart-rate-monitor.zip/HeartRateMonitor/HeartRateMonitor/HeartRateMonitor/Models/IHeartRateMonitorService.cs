﻿using System;

namespace HeartRateMonitor.Models
{
    /// <summary>
    /// IHeartRateMonitorService interface class.
    /// It defines methods and properties
    /// that should be implemented by HeartRateMonitorService class.
    /// </summary>
    public interface IHeartRateMonitorService
    {
        #region properties

        /// <summary>
        /// HeartRateMonitorDataChanged event.
        /// It notifies UI about heart rate value update.
        /// </summary>
        event EventHandler HeartRateMonitorDataChanged;

        #endregion

        #region methods

        /// <summary>
        /// Initializes HeartRateMonitorService class.
        /// </summary>
        void Init();

        /// <summary>
        /// Returns current heart rate value provided by the Tizen Sensor API.
        /// </summary>
        /// <returns>Current heart rate value provided by the Tizen Sensor API.</returns>
        int GetHeartRate();

        /// <summary>
        /// Starts notification about changes of heart rate value.
        /// </summary>
        void StartHeartRateMonitor();

        /// <summary>
        /// Stops notification about changes of heart rate value.
        /// </summary>
        void StopHeartRateMonitor();

        #endregion
    }
}