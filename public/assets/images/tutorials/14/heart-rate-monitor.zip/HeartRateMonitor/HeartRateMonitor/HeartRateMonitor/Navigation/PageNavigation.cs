﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace HeartRateMonitor.Navigation
{
    /// <summary>
    /// PageNavigation class.
    /// Provides commands that allows navigation through the application pages.
    /// </summary>
    public class PageNavigation
    {
        #region properties

        /// <summary>
        /// Switches application to the page given as a command parameter.
        /// </summary>
        public ICommand NavigateToCommand { private set; get; }

        /// <summary>
        /// Switches application to the previous page.
        /// </summary>
        public ICommand NavigateBackCommand { private set; get; }

        #endregion

        #region methods

        #endregion
    }
}