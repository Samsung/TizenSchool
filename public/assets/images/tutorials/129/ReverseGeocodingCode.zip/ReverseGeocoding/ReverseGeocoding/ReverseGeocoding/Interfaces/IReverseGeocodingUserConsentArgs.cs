﻿namespace ReverseGeocoding.ViewModels
{
    /// <summary>
    /// Defines properties that should be implemented by class used to notifying about the user consent status.
    /// </summary>
    public interface IReverseGeocodingUserConsentArgs
    {
        #region properties

        /// <summary>
        /// Consent status value.
        /// </summary>
        bool Consent { get; }

        #endregion
    }
}
