﻿using ReverseGeocoding.Tizen.Wearable.Services;
using Tizen.Maps;

[assembly: Xamarin.Forms.Dependency(typeof(MapServiceProvider))]

namespace ReverseGeocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Manages map service.
    /// </summary>
    public class MapServiceProvider : IMapServiceProvider
    {
        #region fields

        /// <summary>
        /// MapService class instance.
        /// </summary>
        private readonly MapService _mapService;

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public MapServiceProvider()
        {
            _mapService = new MapService(Config.ProviderName, Config.AuthenticationToken);
        }

        /// <summary>
        /// Gets MapService class instance.
        /// </summary>
        /// <returns>MapService instance.</returns>
        public MapService GetService()
        {
            return _mapService;
        }

        #endregion
    }
}
