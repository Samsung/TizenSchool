﻿namespace ReverseGeocoding.Common
{
    /// <summary>
    /// Stores information about geocoordinates.
    /// </summary>
    public class PointGeocoordinates
    {
    }
}
