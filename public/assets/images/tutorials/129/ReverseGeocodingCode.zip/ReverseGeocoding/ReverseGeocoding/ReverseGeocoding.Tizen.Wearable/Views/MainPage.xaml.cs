﻿using ReverseGeocoding.Tizen.Wearable.Services;
using Tizen.Maps;
using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ElmSharp.Wearable;
using ReverseGeocoding.Tizen.Wearable.Controls;

namespace ReverseGeocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Main page of the application displaying the map.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : CirclePage
    {
        #region fields

        /// <summary>
        /// Initial map latitude.
        /// </summary>
        private const double MAP_CENTER_LATITUDE = 52.229676;

        /// <summary>
        /// Initial map longitude.
        /// </summary>
        private const double MAP_CENTER_LONGITUDE = 21.012229;

        /// <summary>
        /// Default zoom level.
        /// </summary>
        private const int DEFAULT_ZOOM_LEVEL = 14;

        /// <summary>
        /// Device screen size.
        /// </summary>
        private const int SCREEN_SIZE = 360;

        /// <summary>
        /// MapService class instance used for getting the map service data.
        /// </summary>
        private MapService _mapService;

        /// <summary>
        /// TizenMapView class instance used for interacting with the map view.
        /// </summary>
        private TizenMapView _mapView;

        /// <summary>
        /// Indicates if map was displayed.
        /// </summary>
        private bool _mapAppeared;

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();

            _mapService = DependencyService.Get<IMapServiceProvider>().GetService();

            _mapAppeared = false;

            _mapView = new TizenMapView
            {
                Service = _mapService,
                ControlWidth = SCREEN_SIZE,
                ControlHeight = SCREEN_SIZE
            };

            Content = _mapView;
        }

        /// <summary>
        /// Zooms in/out map on rotary event.
        /// </summary>
        /// <param name="args">Rotary arguments.</param>
        private void OnRotaryChange(ElmSharp.Wearable.RotaryEventArgs args)
        {
            if (args.IsClockwise)
            {
                _mapView.Map.ZoomLevel++;
            }
            else
            {
                _mapView.Map.ZoomLevel--;
            }
        }

        /// <summary>
        /// Overrides OnAppearing method.
        /// Registers event handlers and sets map properties.
        /// </summary>
        protected override void OnAppearing()
        {
            if (!_mapAppeared)
            {
                _mapView.Map.MapType = MapTypes.Normal;
                _mapView.Map.ZoomLevel = DEFAULT_ZOOM_LEVEL;
                _mapView.Map.Center = new Geocoordinates(MAP_CENTER_LATITUDE, MAP_CENTER_LONGITUDE);
                _mapAppeared = true;
            }

            RotaryEventManager.Rotated += OnRotaryChange;
        }

        /// <summary>
        /// Overrides OnDisappearing method.
        /// Unregisters event handlers.
        /// </summary>
        protected override void OnDisappearing()
        {
            RotaryEventManager.Rotated -= OnRotaryChange;
        }

        #endregion
    }
}