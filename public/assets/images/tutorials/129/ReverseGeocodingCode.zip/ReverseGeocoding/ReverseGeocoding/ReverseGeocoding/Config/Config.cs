﻿namespace ReverseGeocoding
{
    /// <summary>
    /// Provides application settings.
    /// </summary>
    public static class Config
    {
        #region fields

        /// <summary>
        /// Map provider's name.
        /// </summary>
        private const string PROVIDER_NAME = "HERE";

        /// <summary>
        /// ID registered with provider.
        /// Please visit http://developer.here.com to obtain application id.
        /// </summary>
        private const string APP_ID = "***";

        /// <summary>
        /// Key assigned with application ID.
        /// Please visit http://developer.here.com to obtain application key.
        /// </summary>
        private const string APP_KEY = "***";

        #endregion

        #region properties

        /// <summary>
        /// Provider name.
        /// </summary>
        public static string ProviderName => PROVIDER_NAME;

        /// <summary>
        /// Authentication token used to initialize map library.
        /// </summary>
        public static string AuthenticationToken => APP_ID + "/" + APP_KEY;

        /// <summary>
        /// Map credentials indicator.
        /// True if map application ID and key are not empty.
        /// </summary>
        /// <returns>True if both fields are not empty.</returns>
        public static bool IsMapProviderConfigured() => APP_ID.Length > 0 && APP_KEY.Length > 0;

        #endregion
    }
}