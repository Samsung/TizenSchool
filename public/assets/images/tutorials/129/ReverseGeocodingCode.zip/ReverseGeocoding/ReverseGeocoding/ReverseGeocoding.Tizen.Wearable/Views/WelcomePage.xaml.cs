﻿using Xamarin.Forms.Xaml;
using Tizen.Wearable.CircularUI.Forms;

namespace ReverseGeocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Welcome page.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class WelcomePage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public WelcomePage()
        {
            InitializeComponent();
        }

        #endregion
    }
}