﻿using ReverseGeocoding.Interfaces;
using ReverseGeocoding.Tizen.Wearable.Services;
using ReverseGeocoding.ViewModels;
using System;
using Tizen.Maps;
using Xamarin.Forms;

[assembly: Xamarin.Forms.Dependency(typeof(ReverseGeocodingService))]

namespace ReverseGeocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Provides methods to use the maps and their services.
    /// </summary>
    public class ReverseGeocodingService : IReverseGeocodingService
    {
        #region fields

        /// <summary>
        /// MapService class instance used for getting the map service data.
        /// </summary>
        private MapService _mapService;

        #endregion

        #region properties

        /// <summary>
        /// Notifies about user consent.
        /// </summary>
        public event EventHandler<IReverseGeocodingUserConsentArgs> UserConsent;

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public ReverseGeocodingService()
        {
             _mapService = DependencyService.Get<IMapServiceProvider>().GetService();
        }

        /// <summary>
        /// Requests to check user consent.
        /// </summary>
        public async void RequestUserConsent()
        {
            bool consent = await _mapService.RequestUserConsent();
            UserConsent?.Invoke(this, new ReverseGeocodingUserConsentArgs(consent));
        }

        #endregion
    }
}
