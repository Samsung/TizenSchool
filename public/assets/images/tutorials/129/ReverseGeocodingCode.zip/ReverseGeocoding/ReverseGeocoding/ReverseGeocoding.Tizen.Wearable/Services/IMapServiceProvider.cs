﻿using Tizen.Maps;

namespace ReverseGeocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Provides methods to get map service.
    /// </summary>
    public interface IMapServiceProvider
    {
        #region methods

        /// <summary>
        /// Gets MapService class instance.
        /// </summary>
        /// <returns>MapService class instance.</returns>
        MapService GetService();

        #endregion
    }
}
