using ReverseGeocoding.Interfaces;
using ReverseGeocoding.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ReverseGeocoding
{
    /// <summary>
    /// Main application class.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class App : Application
    {
        #region methods

        /// <summary>
        /// Initializes application.
        /// </summary>
        public App()
        {
            InitializeComponent();

            DependencyService.Get<IPageNavigation>().CreateWelcomePage();

            IInformationPopupService popupService = DependencyService.Get<IInformationPopupService>();
            popupService.LoadingText = "Loading";
            popupService.ErrorPopupText = "Connection failed.";
            popupService.ErrorPopupButtonText = "OK";
        }

        #endregion
    }
}
