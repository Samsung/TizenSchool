﻿using ReverseGeocoding.Interfaces;
using System;

namespace ReverseGeocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Defines properties that are used for the service response.
    /// </summary>
    class ReverseGeocodingResponseArgs : EventArgs, IReverseGeocodingResponseArgs
    {
    }
}
