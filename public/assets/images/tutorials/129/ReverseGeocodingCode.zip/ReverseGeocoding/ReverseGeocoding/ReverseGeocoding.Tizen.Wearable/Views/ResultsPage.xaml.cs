﻿using Tizen.Wearable.CircularUI.Forms;
using Xamarin.Forms.Xaml;

namespace ReverseGeocoding.Tizen.Wearable.Views
{
    /// <summary>
    /// Presents the information about the previously selected point on map.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ResultsPage : CirclePage
    {
        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public ResultsPage()
        {
            InitializeComponent();
        }

        #endregion
    }
}