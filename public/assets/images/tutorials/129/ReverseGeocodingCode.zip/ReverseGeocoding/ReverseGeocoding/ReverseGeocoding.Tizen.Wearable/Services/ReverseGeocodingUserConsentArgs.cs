﻿using ReverseGeocoding.ViewModels;
using System;

namespace ReverseGeocoding.Tizen.Wearable.Services
{
    /// <summary>
    /// Event arguments providing information about user consent.
    /// </summary>
    public class ReverseGeocodingUserConsentArgs : EventArgs, IReverseGeocodingUserConsentArgs
    {
        #region properties

        /// <summary>
        /// Consent status value.
        /// </summary>
        public bool Consent { get; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        /// <param name="consent">Consent status value.</param>
        public ReverseGeocodingUserConsentArgs(bool consent)
        {
            Consent = consent;
        }

        #endregion
    }
}