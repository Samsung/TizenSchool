﻿namespace ReverseGeocoding.Interfaces
{
    /// <summary>
    /// Provides methods to use the information popup service.
    /// </summary>
    public interface IInformationPopupService
    {
        #region properties

        /// <summary>
        /// Gets or sets text displayed on the loading popup.
        /// </summary>
        string LoadingText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the error popup.
        /// </summary>
        string ErrorPopupText { get; set; }

        /// <summary>
        /// Gets or sets text displayed on the error popup button.
        /// </summary>
        string ErrorPopupButtonText { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Displays loading popup.
        /// </summary>
        void ShowLoadingPopup();

        /// <summary>
        /// Dismisses the popup.
        /// </summary>
        void Dismiss();

        /// <summary>
        /// Shows error popup with action button.
        /// </summary>
        void ShowErrorPopup();

        #endregion
    }
}
