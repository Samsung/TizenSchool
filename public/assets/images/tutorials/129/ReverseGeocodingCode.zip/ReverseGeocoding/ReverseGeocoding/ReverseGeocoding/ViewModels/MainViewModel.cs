﻿using Xamarin.Forms;
using ReverseGeocoding.Views;
using System.Windows.Input;
using ReverseGeocoding.Interfaces;
using ReverseGeocoding.Common;

namespace ReverseGeocoding.ViewModels
{
    /// <summary>
    /// The application's main view model class (abstraction of the view).
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region fields

        /// <summary>
        /// Reference to object handling navigation between pages obtained in constructor using DependencyService.
        /// </summary>
        private readonly IPageNavigation _navigation;

        /// <summary>
        /// Reference to object handling reverse geocoding services obtained in constructor using DependencyService.
        /// </summary>
        private readonly IReverseGeocodingService _reverseGeocodingService;

        /// <summary>
        /// Reference to object handling information popup obtained in constructor using DependencyService.
        /// </summary>
        private readonly IInformationPopupService _informationPopupService;

        #endregion

        #region properties

        /// <summary>
        /// Navigates to main page.
        /// </summary>
        public ICommand GoToMainPageCommand { get; private set; }

        /// <summary>
        /// Navigates to results page.
        /// </summary>
        public ICommand GoToResultsPageCommand { get; private set; }

        /// <summary>
        /// Navigates to previous page.
        /// </summary>
        public ICommand GoToPreviousPageCommand { get; private set; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes class instance.
        /// </summary>
        public MainViewModel()
        {
            _navigation = DependencyService.Get<IPageNavigation>();
            _reverseGeocodingService = DependencyService.Get<IReverseGeocodingService>();
            _informationPopupService = DependencyService.Get<IInformationPopupService>();

            _reverseGeocodingService.UserConsent += ServiceOnUserConsented;

            InitCommands();
        }

        /// <summary>
        /// Initializes commands.
        /// </summary>
        private void InitCommands()
        {
            GoToMainPageCommand = new Command(ExecuteGoToMainPage);
            GoToPreviousPageCommand = new Command(ExecuteGoToPreviousPage);
            GoToResultsPageCommand = new Command<PointGeocoordinates>(ExecuteGoToResultsPage);
        }

        /// <summary>
        /// Handles execution of "GoToResultsPageCommand".
        /// </summary>
        /// <param name="geocoordinates">Geocoordinates of the selected point.</param>
        private void ExecuteGoToResultsPage(PointGeocoordinates geocoordinates)
        {
        }

        /// <summary>
        /// Handles execution of "GoToMainPageCommand".
        /// </summary>
        private void ExecuteGoToMainPage()
        {
            _reverseGeocodingService.RequestUserConsent();
        }

        /// <summary>
        /// Handles "UserConsent" event of the geocoding service.
        /// </summary>
        /// <param name="sender">Object firing the event.</param>
        /// <param name="e">Event arguments.</param>
        private void ServiceOnUserConsented(object sender, IReverseGeocodingUserConsentArgs e)
        {
            if (e.Consent)
            {
                _navigation.CreateMainPage();
            }
            else
            {
                _navigation.Close();
            }
        }

        /// <summary>
        /// Handles the execution of "GoToPreviousPageCommand".
        /// </summary>
        private void ExecuteGoToPreviousPage()
        {
            _navigation.GoBack();
        }

        #endregion
    }
}
