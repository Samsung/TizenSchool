﻿using ReverseGeocoding.ViewModels;
using System;

namespace ReverseGeocoding.Interfaces
{
    /// <summary>
    /// Provides methods to use the maps and their services.
    /// </summary>
    public interface IReverseGeocodingService
    {
        #region properties

        /// <summary>
        /// Notifies about user consent.
        /// </summary>
        event EventHandler<IReverseGeocodingUserConsentArgs> UserConsent;

        #endregion

        #region methods

        /// <summary>
        /// Requests to check user consent.
        /// </summary>
        void RequestUserConsent();

        #endregion
    }
}
