﻿namespace ReverseGeocoding.Interfaces
{
    /// <summary>
    /// Defines properties that are used for the service response.
    /// </summary>
    public interface IReverseGeocodingResponseArgs
    {
    }
}
