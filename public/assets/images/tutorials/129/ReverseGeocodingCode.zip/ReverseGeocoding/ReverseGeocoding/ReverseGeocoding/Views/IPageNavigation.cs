﻿namespace ReverseGeocoding.Views
{
    /// <summary>
    /// Provides methods which allow to navigate between pages.
    /// </summary>
    public interface IPageNavigation
    {
        #region methods

        /// <summary>
        /// Creates welcome page and sets it as active.
        /// </summary>
        void CreateWelcomePage();

        /// <summary>
        /// Creates main page and sets it as active.
        /// </summary>
        void CreateMainPage();

        /// <summary>
        /// Closes the application.
        /// </summary>
        void Close();

        /// <summary>
        /// Creates welcome page and sets it as active.
        /// </summary>
        void CreateResultsPage();

        /// <summary>
        /// Navigates to previous page.
        /// </summary>
        void GoBack();

        #endregion
    }
}
