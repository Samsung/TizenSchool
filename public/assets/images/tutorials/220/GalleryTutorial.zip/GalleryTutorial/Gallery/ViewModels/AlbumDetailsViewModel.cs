﻿using Gallery.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Forms;

namespace Gallery.ViewModels
{
    /// <summary>
    /// The view model class for AlbumDetailsView.
    /// </summary>
    public class AlbumDetailsViewModel : ViewModelBase
    {
        private ObservableCollection<string> imagePaths;
        private string title;

        /// <summary>
        /// Gets or sets the collection of paths to media items' thumbnails.
        /// </summary>
        public ObservableCollection<string> ImagePaths
        {
            get => imagePaths;
            set => SetProperty(ref imagePaths, value);
        }

        /// <summary>
        /// Gets or sets the title of the album.
        /// </summary>
        public string Title
        {
            get => title;
            set => SetProperty(ref title, value);
        }

        /// <summary>
        /// Gets the command returning to the previous page.
        /// </summary>
        public ICommand GoBackCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlbumDetailsViewModel"/> class.
        /// </summary>
        /// <param name="title">Title of the album.</param>
        public AlbumDetailsViewModel(string title)
        {
            Title = title;
            GoBackCommand = new Command(NavigationService.Instance.PopPage);

            CreateImages();
        }

        private void CreateImages()
        {
            var images = MultimediaService.Instance.GetImages(Title);

            ImagePaths = new ObservableCollection<string>(images.
                OrderByDescending(image => image.Created).
                Select(image => image.Path));
        }
    }
}
