﻿using Gallery.Services;
using System;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NavigationPanelView : Grid
    {
        private int selectedTab;

        /// <summary>
        /// Initializes a new instance of the <see cref="NavigationPanelView"/> class.
        /// </summary>
        public NavigationPanelView()
        {
            InitializeComponent();
            NavigationService.Instance.TabChanged += OnTabChanged;
            SelectTab(NavigationService.Instance.CurrentTabNumber);
        }

        private void OnNavigationButtonTapped(object sender, EventArgs e)
        {
            if (sender is View button)
            {
                NavigationService.Instance.ChangeTab(GetColumn(button));
            }
        }

        private void OnTabChanged(object sender, int newTabNumber)
        {
            SelectTab(newTabNumber);
        }

        private void SelectTab(int newTabNumber)
        {
            (Children.FirstOrDefault(x => x is Label && GetColumn(x) == selectedTab) as Label).TextColor = Constants.ThemeColor.Subtext;
            (Children.FirstOrDefault(x => x is Label && GetColumn(x) == newTabNumber) as Label).TextColor = Constants.ThemeColor.MainText;

            SetColumn(FocusPointer, newTabNumber);

            selectedTab = newTabNumber;
        }
    }
}
