﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery.Controls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NavigationFocusPointer : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NavigationFocusPointer"/> class.
        /// </summary>
        public NavigationFocusPointer()
        {
            InitializeComponent();
        }
    }
}
