﻿using Gallery.Models;
using Gallery.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Gallery.ViewModels
{
    /// <summary>
    /// The view model class for TimelineView.
    /// </summary>
    public class TimelineViewModel : ViewModelBase
    {
        private ObservableCollection<PeriodViewModel> periods;

        /// <summary>
        /// Gets or sets the collection of media items' periods.
        /// </summary>
        public ObservableCollection<PeriodViewModel> Periods
        {
            get => periods;
            set => SetProperty(ref periods, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TimelineViewModel"/> class.
        /// </summary>
        public TimelineViewModel()
        {
            CreatePeriods();
        }

        private void CreatePeriods()
        {
            IEnumerable<Image> imagesCollection = MultimediaService.Instance.GetImages();

            Periods = new ObservableCollection<PeriodViewModel>();

            if (imagesCollection.Any())
            {
                var images = imagesCollection.ToList();
                images.Sort((a, b) => b.Created.CompareTo(a.Created));

                List<string> period = new List<string>();

                (string periodTitle, DateTime lowerBoundary) = GetPeriodInfo(images[0].Created);

                foreach (Image image in images)
                {
                    if (image.Created < lowerBoundary)
                    {
                        Periods.Add(new PeriodViewModel(period, periodTitle));

                        (periodTitle, lowerBoundary) = GetPeriodInfo(image.Created);

                        period = new List<string>();
                    }

                    period.Add(image.Path);
                }

                Periods.Add(new PeriodViewModel(period, periodTitle));
            }
        }

        private static (string title, DateTime lowerBoundary) GetPeriodInfo(DateTime item)
        {
            if (item.Date == DateTime.Today)
            {
                return ("Today", DateTime.Today);
            }
            else if (item.Date == DateTime.Today.AddDays(-1))
            {
                return ("Yesterday", DateTime.Today.AddDays(-1));
            }
            else if (item.Date >= new DateTime(DateTime.Today.AddMonths(-1).Year, DateTime.Today.AddMonths(-1).Month, 1))
            {
                return (item.ToString("d MMMM"), item.Date);
            }
            else if (item.Date >= new DateTime(DateTime.Today.Year, 1, 1))
            {
                return (item.ToString("MMMM"), new DateTime(item.Year, item.Month, 1));
            }
            else if (item.Date >= new DateTime(DateTime.Today.Year - 1, 1, 1))
            {
                return (item.ToString("MMMM yyyy"), new DateTime(item.Year, item.Month, 1));
            }
            else
            {
                return (item.ToString("yyyy"), new DateTime(item.Year, 1, 1));
            }
        }
    }
}
