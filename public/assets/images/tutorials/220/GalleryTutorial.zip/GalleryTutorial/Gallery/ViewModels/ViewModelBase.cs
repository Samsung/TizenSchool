﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Gallery.ViewModels
{
    /// <summary>
    /// Base class for all ViewModels.
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Helper property setter that raises PropertyChanged event.
        /// </summary>
        /// <typeparam name="T">Inferred type of the property.</typeparam>
        /// <param name="property">The property to be set.</param>
        /// <param name="value">The value to be set.</param>
        /// <param name="propertyName">Name of the changed property.</param>
        /// <returns>Value indicating whether a new value was set.</returns>
        protected virtual bool SetProperty<T>(ref T property, T value, [CallerMemberName] string propertyName = null)
        {
            if (object.Equals(property, value)) return false;

            property = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

            return true;
        }
    }
}
