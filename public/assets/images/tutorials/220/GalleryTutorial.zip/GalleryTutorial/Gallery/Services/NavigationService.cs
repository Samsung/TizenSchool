﻿using Gallery.Views;
using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Gallery.Services
{
    /// <summary>
    /// Provides the logic of application navigation.
    /// Implements the singleton pattern.
    /// </summary>
    public sealed class NavigationService
    {
        /// <summary>
        /// Service instance.
        /// </summary>
        private static NavigationService instance;

        private Stack<View>[] tabs;
        private readonly List<View> pagesToRemove;

        /// <summary>
        /// Gets service instance (singleton).
        /// </summary>
        public static NavigationService Instance
        {
            get
            {
                (instance ?? (instance = new NavigationService())).RemovePages();
                return instance;
            }
        }

        /// <summary>
        /// Gets a value indicating the number of the current tab.
        /// </summary>
        public int CurrentTabNumber { get; private set; }

        /// <summary>
        /// Event raised when the tab is changed.
        /// </summary>
        public event EventHandler<int> TabChanged;

        /// <summary>
        /// Prevents a default instance of the <see cref="NavigationService"/> class from being created.
        /// Initializes a new instance of the <see cref="NavigationService"/> class.
        /// </summary>
        private NavigationService()
        {
            pagesToRemove = new List<View>();
            CurrentTabNumber = 0;
            InitPages();
        }

        /// <summary>
        /// Changes the tab.
        /// </summary>
        /// <param name="newTabNumber">Tab number.</param>
        public void ChangeTab(int newTabNumber)
        {
            if (newTabNumber >= tabs.Length || tabs[newTabNumber].Count == 0)
            {
                Tizen.Log.Debug(Constants.Config.LogTag, "Wrong page number");
            }
            else if (CurrentTabNumber != newTabNumber && (Application.Current.MainPage as ContentPage)?.Content is AbsoluteLayout mainPage)
            {
                foreach (View page in tabs[CurrentTabNumber])
                {
                    page.IsVisible = false;
                }

                View newTab = tabs[newTabNumber].Peek();

                if (mainPage.Children.Contains(newTab))
                {
                    newTab.IsVisible = true;
                }
                else
                {
                    SetLayout(newTab);
                    mainPage.Children.Insert(0, newTab);
                }

                CurrentTabNumber = newTabNumber;
                TabChanged?.Invoke(this, newTabNumber);
            }
        }

        /// <summary>
        /// Pushes new page.
        /// </summary>
        /// <param name="newPage">Pushed page.</param>
        public void PushPage(View newPage)
        {
            if ((Application.Current.MainPage as ContentPage)?.Content is AbsoluteLayout mainPage)
            {
                tabs[CurrentTabNumber].Peek().IsVisible = false;

                tabs[CurrentTabNumber].Push(newPage);

                SetLayout(newPage);

                mainPage.Children.Insert(0, newPage);
            }
        }

        /// <summary>
        /// Returns back to previous page.
        /// </summary>
        public void PopPage()
        {
            if (tabs[CurrentTabNumber].Count <= 1)
            {
                Tizen.Log.Debug(Constants.Config.LogTag, "There is no page left.");
            }
            else
            {
                View removedPage = tabs[CurrentTabNumber].Pop();
                pagesToRemove.Add(removedPage);
                removedPage.IsVisible = false;

                tabs[CurrentTabNumber].Peek().IsVisible = true;
            }
        }

        /// <summary>
        /// Initializes navigation service.
        /// </summary>
        public void Initialize()
        {
            if ((Application.Current.MainPage as ContentPage)?.Content is AbsoluteLayout mainPage)
            {
                View firstPage = tabs[CurrentTabNumber].Peek();

                SetLayout(firstPage);
                mainPage.Children.Insert(0, firstPage);
            }
        }

        private void InitPages()
        {
            tabs = new Stack<View>[2];
            for (int i = 0; i < 2; i++)
            {
                tabs[i] = new Stack<View>();
            }

            tabs[0].Push(new TimelineView());
            tabs[1].Push(new AlbumsView());
        }

        private void SetLayout(View view)
        {
            AbsoluteLayout.SetLayoutFlags(view, AbsoluteLayoutFlags.All);
            AbsoluteLayout.SetLayoutBounds(view, new Rectangle(0, 0, 1, 1));
        }

        private void RemovePages()
        {
            if ((Application.Current.MainPage as ContentPage)?.Content is AbsoluteLayout mainPage)
            {
                foreach (View page in pagesToRemove)
                {
                    if (!mainPage.Children.Remove(page))
                    {
                        Tizen.Log.Debug(Constants.Config.LogTag, "Cannot remove the page");
                        throw new NotImplementedException();
                    }
                }

                pagesToRemove.Clear();
            }
        }
    }
}
