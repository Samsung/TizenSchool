using Xamarin.Forms;

namespace Gallery
{
    /// <summary>
    /// Gallery IoT application.
    /// </summary>
    internal class Gallery : global::Xamarin.Forms.Platform.Tizen.FormsApplication
    {
        /// <inheritdoc/>
        protected override void OnCreate()
        {
            base.OnCreate();

            LoadApplication(new App());
        }

        private static void Main(string[] args)
        {
            var app = new Gallery();
            Forms.Init(app);
            app.Run(args);
        }
    }
}
