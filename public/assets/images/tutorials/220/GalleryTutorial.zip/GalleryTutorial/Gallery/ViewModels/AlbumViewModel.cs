﻿using Gallery.Services;
using Gallery.Views;
using System.Windows.Input;
using Xamarin.Forms;

namespace Gallery.ViewModels
{
    /// <summary>
    /// The view model class for AlbumView.
    /// </summary>
    public class AlbumViewModel : ViewModelBase
    {
        private string coverPath;
        private string title;
        private int count;

        /// <summary>
        /// Gets or sets the path to the album's cover picture source file.
        /// </summary>
        public string CoverPath
        {
            get => coverPath;
            set => SetProperty(ref coverPath, value);
        }

        /// <summary>
        /// Gets or sets the title of the album.
        /// </summary>
        public string Title
        {
            get => title;
            set => SetProperty(ref title, value);
        }

        /// <summary>
        /// Gets or sets the number of images inside.
        /// </summary>
        public int Count
        {
            get => count;
            set => SetProperty(ref count, value);
        }

        /// <summary>
        /// Gets the command navigating to the album's details page.
        /// </summary>
        public ICommand GoToAlbumDetailsCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlbumViewModel"/> class.
        /// </summary>
        /// <param name="title">Title of album.</param>
        /// <param name="count">Number of images.</param>
        /// <param name="coverPath">Path to the album's cover picture source file.</param>
        public AlbumViewModel(string title, int count, string coverPath)
        {
            CoverPath = coverPath;
            Title = title;
            Count = count;

            GoToAlbumDetailsCommand = new Command(ExecuteGoToAlbumDetailsCommand);
        }

        private void ExecuteGoToAlbumDetailsCommand()
        {
            if (Application.Current.MainPage is MainPage)
            {
                var view = new AlbumDetailsView();

                view.BindingContext = new AlbumDetailsViewModel(Title);

                NavigationService.Instance.PushPage(view);
            }
        }
    }
}
