﻿using Gallery.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace Gallery.ViewModels
{
    /// <summary>
    /// The view model class for AlbumsView.
    /// </summary>
    public class AlbumsViewModel : ViewModelBase
    {
        private ObservableCollection<AlbumViewModel> albums;

        /// <summary>
        /// Gets or sets the collection of <see cref="AlbumViewModel"/>s.
        /// </summary>
        public ObservableCollection<AlbumViewModel> Albums
        {
            get => albums;
            set => SetProperty(ref albums, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlbumsViewModel"/> class.
        /// </summary>
        public AlbumsViewModel()
        {
            CreateAlbums();
        }

        private void CreateAlbums()
        {
            var albumsCollection = MultimediaService.Instance.GetAlbums();

            Albums = new ObservableCollection<AlbumViewModel>(albumsCollection.
                Select(x => new AlbumViewModel(x.Title, x.Count, x.CoverPath)));
        }
    }
}
