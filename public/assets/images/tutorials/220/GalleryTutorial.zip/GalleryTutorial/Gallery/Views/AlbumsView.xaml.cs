﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AlbumsView : ContentView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AlbumsView"/> class.
        /// </summary>
        public AlbumsView()
        {
            InitializeComponent();
        }
    }
}
