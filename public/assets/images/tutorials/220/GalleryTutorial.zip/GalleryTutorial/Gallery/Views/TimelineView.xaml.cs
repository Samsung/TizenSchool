﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TimelineView : ContentView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TimelineView"/> class.
        /// </summary>
        public TimelineView()
        {
            InitializeComponent();
        }
    }
}
