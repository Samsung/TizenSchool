﻿namespace Gallery.Constants
{
    /// <summary>
    /// Contains constant values used for configuration.
    /// </summary>
    public static class Config
    {
        /// <summary>
        /// Log tag used to identify application-specific events in the logging utility tool.
        /// </summary>
        public const string LogTag = "Gallery";

        /// <summary>
        /// The name of system album containing favourites images.
        /// </summary>
        public const string FavouritesAlbumName = "Favourites";
    }
}
