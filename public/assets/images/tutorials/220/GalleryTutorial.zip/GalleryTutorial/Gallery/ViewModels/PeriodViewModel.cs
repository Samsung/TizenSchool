﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Gallery.ViewModels
{
    /// <summary>
    /// The view model class for PeriodView.
    /// </summary>
    public class PeriodViewModel : ViewModelBase
    {
        private ObservableCollection<string> imagePaths;
        private string title;

        /// <summary>
        /// Gets or sets the collection of paths to media items' thumbnails.
        /// </summary>
        public ObservableCollection<string> ImagePaths
        {
            get => imagePaths;
            set => SetProperty(ref imagePaths, value);
        }

        /// <summary>
        /// Gets or sets the title of the period.
        /// </summary>
        public string Title
        {
            get => title;
            set => SetProperty(ref title, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PeriodViewModel"/> class.
        /// </summary>
        /// <param name="imagePaths">Collection of paths to media items' thumbnails.</param>
        /// <param name="title">Title of the period.</param>
        public PeriodViewModel(IEnumerable<string> imagePaths, string title)
        {
            ImagePaths = new ObservableCollection<string>(imagePaths);

            Title = title;
        }
    }
}
