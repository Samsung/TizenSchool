﻿namespace Gallery.Models
{
    /// <summary>
    /// Holds information about album with images.
    /// </summary>
    public class Album
    {
        /// <summary>
        /// Gets the <see cref="Image"/>s number.
        /// </summary>
        public int Count { get; }

        /// <summary>
        /// Gets the path to the latest <see cref="Image"/> inside.
        /// </summary>
        public string CoverPath { get; }

        /// <summary>
        /// Gets the name to display.
        /// </summary>
        public string Title { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Album"/> class.
        /// </summary>
        /// <param name="title">Name to display.</param>
        /// <param name="count">Number of <see cref="Image"/>s inside.</param>
        /// <param name="coverPath">Path to the latest <see cref="Image"/> inside.</param>
        public Album(string title, int count, string coverPath)
        {
            Title = title;
            Count = count;
            CoverPath = coverPath;
        }
    }
}
