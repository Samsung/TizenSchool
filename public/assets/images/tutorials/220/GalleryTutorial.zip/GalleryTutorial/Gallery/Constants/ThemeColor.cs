﻿using Xamarin.Forms;

namespace Gallery.Constants
{
    /// <summary>
    /// Contains theme colors used in the application.
    /// </summary>
    public static class ThemeColor
    {
        /// <summary>
        /// The primary theme color.
        /// </summary>
        public static readonly Color Primary = Color.FromHex("#0A0E4A");

        /// <summary>
        /// The variant of secondary theme color.
        /// </summary>
        public static readonly Color SecondaryVariant = Color.FromHex("#EEEEF1");

        /// <summary>
        /// The theme color of surface.
        /// </summary>
        public static readonly Color Surface = Color.White;

        /// <summary>
        /// The theme color of main text.
        /// </summary>
        public static readonly Color MainText = Color.FromHex("#000C2B");

        /// <summary>
        /// The theme color of subtext.
        /// </summary>
        public static readonly Color Subtext = Color.FromHex("#C3CAD2");
    }
}
