﻿using System;

namespace Gallery.Models
{
    /// <summary>
    /// Holds information about <see cref="Image"/>.
    /// </summary>
    public class Image
    {
        /// <summary>
        /// Gets the path to the source.
        /// </summary>
        public string Path { get; }

        /// <summary>
        /// Gets the <see cref="DateTime"/> of the <see cref="Image"/> creation.
        /// </summary>
        public DateTime Created { get; }

        /// <summary>
        /// Gets or sets a value indicating whether the <see cref="Image"/> is marked as favourite.
        /// </summary>
        public bool IsFavorite { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class.
        /// </summary>
        /// <param name="path">Path to the source.</param>
        /// <param name="created">Creation time.</param>
        /// <param name="isFavourite">Flag indicating whether is marked as favourite.</param>
        public Image(string path, DateTime created, bool isFavourite = false)
        {
            Path = path;
            Created = created;
            IsFavorite = isFavourite;
        }
    }
}
