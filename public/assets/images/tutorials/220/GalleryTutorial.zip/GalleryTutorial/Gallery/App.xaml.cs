﻿using Gallery.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class App : Application
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="App"/> class.
        /// </summary>
        public App()
        {
            InitializeComponent();

            MainPage = new MainPage();

            Services.NavigationService.Instance.Initialize();
        }
    }
}
