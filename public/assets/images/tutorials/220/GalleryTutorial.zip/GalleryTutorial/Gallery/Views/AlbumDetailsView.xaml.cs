﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Gallery.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AlbumDetailsView : ContentView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AlbumDetailsView"/> class.
        /// </summary>
        public AlbumDetailsView()
        {
            InitializeComponent();
        }
    }
}
