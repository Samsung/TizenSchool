﻿using Gallery.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Gallery.Services
{
    /// <summary>
    /// Provides access to multimedia data.
    /// Implements the singleton pattern.
    /// </summary>
    public sealed class MultimediaService
    {
        /// <summary>
        /// Service instance.
        /// </summary>
        private static MultimediaService instance;

        /// <summary>
        /// Gets service instance (singleton).
        /// </summary>
        public static MultimediaService Instance
        {
            get => instance ?? (instance = new MultimediaService());
        }

        /// <summary>
        /// Prevents a default instance of the <see cref="MultimediaService"/> class from being created.
        /// Initializes a new instance of the <see cref="MultimediaService"/> class.
        /// </summary>
        private MultimediaService() { }

        /// <summary>
        /// Returns the <see cref="Image"/>s.
        /// </summary>
        public IEnumerable<Image> GetImages()
        {
            ICollection<Image> images = new List<Image>();

            images.Add(new Image("pic.png", DateTime.Today));

            return images;
        }

        /// <summary>
        /// Returns the <see cref="Image"/>s from specified album.
        /// </summary>
        /// <param name="albumTitle">Title of the album.</param>
        public IEnumerable<Image> GetImages(string albumTitle)
        {
            ICollection<Image> images = new List<Image>();

            for (int i = 0; i <9; i++)
                images.Add(new Image("pic.png", DateTime.Today));

            return images;
        }

        /// <summary>
        /// Returns the <see cref="Album"/>s.
        /// </summary>
        public IEnumerable<Models.Album> GetAlbums()
        {
            ICollection<Models.Album> albums = new List<Models.Album>();

            albums.Add(new Models.Album("Album1", 2, "pic.png"));
            albums.Add(new Models.Album("Album2", 5, "pic.png"));
            albums.Add(new Models.Album("Album3", 7, "pic.png"));

            return albums;
        }
    }
}
