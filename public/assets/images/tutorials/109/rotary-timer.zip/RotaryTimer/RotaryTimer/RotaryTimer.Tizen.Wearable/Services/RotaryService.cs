﻿using ElmSharp.Wearable;
using RotaryTimer.Tizen.Wearable.Services;
using System;
using RotaryTimer.Interfaces;

[assembly: Xamarin.Forms.Dependency(typeof(RotaryService))]
namespace RotaryTimer.Tizen.Wearable.Services
{
    /// <summary>
    /// Service which provides event handler subscription for Tizen rotary change.
    /// </summary>
    class RotaryService : IRotaryService
    {
        #region properties

        #endregion

        #region methods

        /// <summary>
        /// Subscribes for rotation change.
        /// </summary>
        public RotaryService()
        {

        }

        #endregion
    }
}
