﻿using System;
using System.Globalization;
using Xamarin.Forms;
using RotaryTimer.Utils;

namespace RotaryTimer.Converters
{
    /// <summary>
    /// Converts time values to rotation.
    /// </summary>
    public class TimeValueToIndicatorRotationConverter : IValueConverter
    {
        #region methods

        /// <summary>
        /// Converts time values to rotation value for time unit indicators.
        /// </summary>
        /// <param name="value">Timer setting object.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Indicator type.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>Rotation value.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double indicatorRotation = 0;

            return indicatorRotation;
        }

        /// <summary>
        /// Converts rotation to time values.
        /// Not required by the application, so it is not implemented.
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Optional conversion parameter.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>Setting mode representing converted filename.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new Exception("Not implemented");
        }

        #endregion
    }
}