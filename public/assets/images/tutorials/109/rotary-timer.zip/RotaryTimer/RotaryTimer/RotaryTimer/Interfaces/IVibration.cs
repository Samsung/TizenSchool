﻿namespace RotaryTimer.Interfaces
{
    /// <summary>
    /// Interface implemented by platform specific vibration services.
    /// </summary>
    public interface IVibration
    {
        #region methods

        /// <summary>
        /// Starts vibration.
        /// </summary>
        void Vibrate();

        #endregion
    }
}
