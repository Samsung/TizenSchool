﻿namespace RotaryTimer.Utils
{
    /// <summary>
    /// Available time setting modes.
    /// </summary>
    public enum SettingMode
    {
        /// <summary>
        /// Setting hours mode.
        /// </summary>
        HOURS,

        /// <summary>
        /// Setting minutes mode.
        /// </summary>
        MINUTES,

        /// <summary>
        /// Setting seconds mode.
        /// </summary>
        SECONDS,

        /// <summary>
        /// Setting mode not set.
        /// </summary>
        UNSET
    }
}
