﻿using Xamarin.Forms;

namespace RotaryTimer.Interfaces
{
    /// <summary>
    /// Interface implemented by classes handling navigation over views.
    /// </summary>
    public interface IViewNavigation
    {
        #region methods

        /// <summary>
        /// Returns initial page.
        /// </summary>
        /// <returns>Initial page.</returns>
        NavigationPage GetInitialPage();

        /// <summary>
        /// Changes page to timer page.
        /// </summary>
        void ShowTimerPage();

        /// <summary>
        /// Changes page to the previous one.
        /// </summary>
        void ShowPreviousPage();

        #endregion
    }
}
