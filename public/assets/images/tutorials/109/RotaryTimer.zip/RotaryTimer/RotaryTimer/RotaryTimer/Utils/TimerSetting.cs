﻿namespace RotaryTimer.Utils
{
    /// <summary>
    /// Timer setting class.
    /// </summary>
    public class TimerSetting
    {
        #region properties

        /// <summary>
        /// Hours value.
        /// </summary>
        public int Hours { get; }

        /// <summary>
        /// Minutes value.
        /// </summary>
        public int Minutes { get; }

        /// <summary>
        /// Seconds value.
        /// </summary>
        public int Seconds { get; }

        /// <summary>
        /// Setting mode.
        /// </summary>
        public SettingMode SettingMode { get; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes TimerSetting class instance.
        /// </summary>
        /// <param name="hours">Hours value.</param>
        /// <param name="minutes">Minutes value.</param>
        /// <param name="seconds">Seconds value.</param>
        /// <param name="settingMode">Setting mode.</param>
        public TimerSetting(int hours, int minutes, int seconds, SettingMode settingMode)
        {
            this.Hours = hours;
            this.Minutes = minutes;
            this.Seconds = seconds;
            this.SettingMode = settingMode;
        }

        #endregion
    }
}
