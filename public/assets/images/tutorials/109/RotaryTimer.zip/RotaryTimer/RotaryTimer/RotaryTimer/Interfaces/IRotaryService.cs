﻿using System;

namespace RotaryTimer.Interfaces
{
    /// <summary>
    /// Interface implemented by platform specific rotary service.
    /// </summary>
    public interface IRotaryService
    {
        #region properties

        #endregion
    }
}
