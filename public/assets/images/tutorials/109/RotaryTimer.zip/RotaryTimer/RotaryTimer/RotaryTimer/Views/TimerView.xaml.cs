﻿using System.Windows.Input;
using Xamarin.Forms;

namespace RotaryTimer.Views
{
    /// <summary>
    /// The view which displays timer components.
    /// </summary>
    public partial class TimerView : ContentPage
    {
        #region properties

        /// <summary>
        /// Command setting stop button image.
        /// </summary>
        private ICommand SetStopButtonPressed { get; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes timer view.
        /// </summary>
        public TimerView()
        {
            SetStopButtonPressed = new Command(() => { StopButton.Source = "button_stop_pressed.png"; });
            InitializeComponent();
        }

        #endregion
    }
}
