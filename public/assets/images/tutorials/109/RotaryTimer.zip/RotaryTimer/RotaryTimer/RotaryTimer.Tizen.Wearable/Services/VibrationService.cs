﻿using RotaryTimer.Interfaces;
using RotaryTimer.Tizen.Wearable.Services;
using System.Threading;
using Tizen.System;

[assembly: Xamarin.Forms.Dependency(typeof(VibrationService))]
namespace RotaryTimer.Tizen.Wearable.Services
{
    /// <summary>
    /// Service which provides platform specific vibration functionality.
    /// </summary>
    class VibrationService : IVibration
    {
        #region methods

        /// <summary>
        /// Starts vibrations.
        /// </summary>
        public void Vibrate()
        {
            if (Vibrator.NumberOfVibrators > 0)
            {
                Vibrator vibrator = Vibrator.Vibrators[0];
                vibrator.Vibrate(2000, 70);
                Thread.Sleep(2000);
            }
        }

        #endregion
    }
}
