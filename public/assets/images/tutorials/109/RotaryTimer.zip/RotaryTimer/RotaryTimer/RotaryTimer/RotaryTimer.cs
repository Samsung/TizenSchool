using Xamarin.Forms;
using RotaryTimer.Interfaces;

namespace RotaryTimer
{
    /// <summary>
    /// Main application class.
    /// </summary>
    public class App : Application
    {
        #region methods

        /// <summary>
        /// Initializes application.
        /// </summary>
        public App()
        {
            MainPage = DependencyService.Get<IViewNavigation>().GetInitialPage();
        }

        #endregion
    }
}
