﻿using Xamarin.Forms;
using RotaryTimer.Interfaces;
using RotaryTimer.Views;

[assembly: Dependency(typeof(ViewNavigation))]
namespace RotaryTimer.Views
{
    /// <summary>
    /// Application navigation class.
    /// </summary>
    public class ViewNavigation : IViewNavigation
    {
        #region properties

        /// <summary>
        /// The application's navigation instance.
        /// </summary>
        private NavigationPage Navigation { get; set; }

        #endregion

        #region methods

        /// <summary>
        /// Returns initial page.
        /// </summary>
        /// <returns>Initial page.</returns>
        public NavigationPage GetInitialPage()
        {
            Navigation = new NavigationPage(new SetTimeView());

            return Navigation;
        }

        /// <summary>
        /// Changes page to timer page.
        /// </summary>
        public void ShowTimerPage()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new TimerView());
            });
        }

        /// <summary>
        /// Changes page to the previous one.
        /// </summary>
        public void ShowPreviousPage()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PopAsync();
            });
        }

        #endregion
    }
}
