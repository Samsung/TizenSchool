﻿using Xamarin.Forms;
using RotaryTimer.Interfaces;
using System.Windows.Input;

namespace RotaryTimer.Views
{
    /// <summary>
    /// Setting timer view class.
    /// </summary>
    public partial class SetTimeView : ContentPage
    {
        #region properties

        /// <summary>
        /// Command setting start button image.
        /// </summary>
        public ICommand SetStartButtonPressed { get; }

        #endregion

        #region methods

        /// <summary>
        /// Initializes the view.
        /// </summary>
        public SetTimeView()
        {
            SetStartButtonPressed = new Command<bool>((enabled) =>
            {
                if (enabled)
                {
                    StartButton.Source = "button_start_pressed.png";
                }
            });

            InitializeComponent();
        }

        /// <summary>
        /// Executed on page disappearing.
        /// Sets initial source for start button image.
        /// </summary>
        protected override void OnDisappearing()
        {
            StartButton.Source = "button_start.png";
        }

        #endregion
    }
}
