﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace RotaryTimer.Converters
{
    /// <summary>
    /// Converts integer to string (with leading zero if needed) and back.
    /// </summary>
    public class IntToPadStringConverter : IValueConverter
    {
        #region methods

        /// <summary>
        /// Converts integer value to string.
        /// If value is lower than 10, adds leading "0".
        /// </summary>
        /// <param name="value">Value to convert.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Optional conversion parameter.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>Value converted to string.</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return ((int)value).ToString("00");
        }

        /// <summary>
        /// Converts string to integer value.
        /// </summary>
        /// <param name="value">Value to be converted back.</param>
        /// <param name="targetType">Type of the data binding target property.</param>
        /// <param name="parameter">Optional conversion parameter.</param>
        /// <param name="culture">CultureInfo object allowing culture specific conversion.</param>
        /// <returns>Integer value converted from string.</returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Int32.Parse((string)value);
        }

        #endregion
    }
}

