﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoPlayerLite.Models
{
    public interface IMediaContentAPIs
    {
        Task<IEnumerable<MediaItem>> GetAllVideoItemListAsync();
    }
}
