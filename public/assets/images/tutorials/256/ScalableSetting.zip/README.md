# ScalableSetting
Scalable UI (NUI) based Tizen Setting Application



* To-do

(당장)
- 타이틀 바 UI 정리
- Orietational View 버그 제거
- Orietational View : 2개 View 보일때 5:5 가 아니라 3:7 로
- Unit 적용
- Page 별 타이틀

- Custom Layout -> CustimView (ViewWrapper, ...)


(6.5 M2 이후)

- 불안정한 에니메이션 처리
- 다국어 스트링
- Popup 처리
- Key 처리 (Focus 처리 포함)
- Group ( or Separator ) 추가

- 기능 추가
- internal API wrapper



* issue

1.Textlable과 폰트
   : 앱이 폰트 사이즈를 조정하는게 맞나? Font Metric다루지 않고 영역이나 사이즈 결정해주는 함수 필요
        - Size2D 만 정하면 UIFWㅇ 폰트는 채워서 찍는 기능 필요 -> 특히 다국어 지원을 위해서도필요
        - Single Line 기준으로 구하는 함수 필요
