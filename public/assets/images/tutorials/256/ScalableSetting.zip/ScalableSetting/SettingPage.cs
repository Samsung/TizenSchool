﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SettingPage : ScrollableBase
    {
        protected const string SETTING_LIST_ICON_PATH_CFG = "/list_icon/";


        protected string resDirectory;
        protected View parentView;
        protected readonly int menuLevel;
        public SettingPage(ListItem[] items, View parentview, int level, string resdir)
            : base()
        {
            resDirectory = resdir;
            parentView = parentview;
            menuLevel = level;

            //Create Linear Layout
            LinearLayout linearLayout = new LinearLayout
            {
                LinearOrientation = LinearLayout.Orientation.Vertical,
                CellPadding = new Size2D(10, 10).ToPixel()
            };

            //Create main view
            BackgroundColor = Color.White;
            Size2D = new Size2D(parentView.Size2D.Width - 40.ToPixel(), parentView.Size2D.Height - 40.ToPixel());
            Layout = linearLayout;
            
            //Create custom items and add it to view
            for (int i = 0; i < items.Length; i++)
            {
                Button itemView = SettingItemCreator.Create(items[i], "ItemView_" + i.ToString(), ItemView_Clicked, resDirectory, parentView);
                Add(itemView);
            }
        }

        private void ItemView_Clicked(object sender, ClickedEventArgs e)
        {
            if (menuLevel < 0)
                return;
            var view = parentView as ScalableUI.OrientationalView;
            if (menuLevel != (view.ChildCount - 1))
                return;

            OnClicked(sender);
        }

        protected virtual void OnClicked(object sender)
        {
        }

    }
}
