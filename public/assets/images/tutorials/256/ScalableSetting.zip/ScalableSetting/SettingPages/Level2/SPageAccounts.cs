﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPageAccounts : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, "", "Add Account",""),
        };


        public SPageAccounts(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            /*
                        if (me.Name == "ItemView_0")
                        {

                        }
            */
        }

    }
}
