﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPageSound : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, "", "Sound mode","sound, Mute"),
            new ListItem(1, "", "Notification","General notification_sdk.wav"),
            new ListItem(1, "", "Other sound",""),
            new ListItem(3, "", "Media","Media volume slider"),
            new ListItem(3, "", "Notification","Notification volume slider"),
            new ListItem(3, "", "System","System volume slider"),
        };


        public SPageSound(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            /*
                        if (me.Name == "ItemView_0")
                        {

                        }
            */
        }

    }
}
