﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPCategoryDisplay : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Display","Display"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_wallpapers.png", "Wallpapers","Wallpapers"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_softkey.png", "Soft Keys","Soft Keys"),
        };


        public SPCategoryDisplay(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");


            if (me.Name == "ItemView_0")
            {
                //Add Display Settingpage
                SettingPage settingpage = new SPageDisplay(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_1")
            {
                //Add Wallpapers Settingpage
                SettingPage settingpage = new SPageWallpapers(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_2")
            {
                //Add Soft Keys Settingpage
                SettingPage settingpage = new SPageSoftKeys(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
        }

    }
}
