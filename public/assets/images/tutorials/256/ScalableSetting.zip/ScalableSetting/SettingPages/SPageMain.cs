﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPageMain : SettingPage
    {
        private static readonly ListItem[] ListItems =  {
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Connections","Connections"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Sound","Sound"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Display","Display"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Personal","Personal"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Memory","Memory"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "System","System"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_display.png", "Device","Device")
        };

        public SPageMain(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as Button;
            
            var view = parentView as ScalableUI.OrientationalView;

            Tizen.Log.Debug(nameof(ScalableSetting), $"Item Name : {me.Name}");

            if (me.Name == "ItemView_0")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategoryConnections(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_1")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategorySound(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_2")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategoryDisplay(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_3")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategoryPersonal(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_4")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategoryMemory(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_5")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategorySystem(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
            else if (me.Name == "ItemView_6")
            {
                //Add new Settingpage
                SettingPage settingpage = new SPCategoryDevice(parentView, 1, resDirectory);
                view.Add(settingpage);
            }
        }

    }
}
