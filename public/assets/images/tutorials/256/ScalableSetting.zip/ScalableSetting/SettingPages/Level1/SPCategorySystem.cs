﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPCategorySystem : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_language_and_input.png", "Language and input","Language and input"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_date_and_time.png", "Date and time","Date and time"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_reset.png", "Reset","Reset"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_accessibility.png", "Accessibility","Accessibility"),
        };


        public SPCategorySystem(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            if (me.Name == "ItemView_0")
            {
                //Add LanguageAndInput Settingpage
                SettingPage settingpage = new SPageLanguageAndInput(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_1")
            {
                //Add DateAndTime Settingpage
                SettingPage settingpage = new SPageDateAndTime(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_2")
            {
                //Add Reset Settingpage
                SettingPage settingpage = new SPageReset(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_3")
            {
                //Add Accessibility Settingpage
                SettingPage settingpage = new SPageAccessibility(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
        }

    }
}
