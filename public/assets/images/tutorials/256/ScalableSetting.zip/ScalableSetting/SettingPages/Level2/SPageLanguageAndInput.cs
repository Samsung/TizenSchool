﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPageLanguageAndInput : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, "", "Display language","Engish (United States)"),
            new ListItem(1, "", "Keyboard",""),
            new ListItem(1, "", "Autofill service"),
            new ListItem(1, "", "Voice Control"),
            new ListItem(1, "", "Text-to-speech (TTS)"),
            new ListItem(1, "", "Speech-To-Text (STT)"),
        };


        public SPageLanguageAndInput(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            /*
                        if (me.Name == "ItemView_0")
                        {

                        }
            */
        }

    }
}
