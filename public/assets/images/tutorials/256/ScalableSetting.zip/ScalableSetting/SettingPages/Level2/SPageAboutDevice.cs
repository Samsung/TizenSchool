﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPageAboutDevice : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, "", "Manage certificate", ""),
            new ListItem(1, "", "Legal infomation", ""),
            new ListItem(1, "", "Device Info", ""),
            new ListItem(1, "", "Name", "Tizen"),
            new ListItem(1, "", "Model number", "rpi3"),
            new ListItem(1, "", "Tizen version", "TIZEN 6.5"),
            new ListItem(1, "", "CPU", "BCM2837"),
            new ListItem(1, "", "RAM", "4.0GB"),
            new ListItem(1, "", "Resolution", "1280 x 720"),
            new ListItem(1, "", "Status", "show network status and other infomation."),
        };


        public SPageAboutDevice(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            /*
                        if (me.Name == "ItemView_0")
                        {

                        }
            */
        }

    }
}
