﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SPCategorySound : SettingPage
    {
        private static readonly ListItem[] ListItems =
        {
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_sound_and_notifications.png", "Sound","Sound"),
            new ListItem(1, SETTING_LIST_ICON_PATH_CFG+"settings_notifications.png", "Notifications","Notifications"),
        };


        public SPCategorySound(View parentview, int level, string resdir)
            : base(ListItems, parentview, level, resdir)
        {

        }
        protected override void OnClicked(object sender)
        {
            var me = sender as View;

            Tizen.Log.Debug(nameof(ScalableSetting), $"ItemName : {me.Name}");

            if (me.Name == "ItemView_0")
            {
                //Add Sound Settingpage
                SettingPage settingpage = new SPageSound(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
            else if (me.Name == "ItemView_1")
            {
                //Add Notifications Settingpage
                SettingPage settingpage = new SPageNotifications(parentView, 2, resDirectory);
                parentView.Add(settingpage);
            }
        }

    }
}
