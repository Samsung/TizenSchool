﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.Applications;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class Scene1 : NUIApplication
    {
        private MainView mainView;


        private const int TitleHight = 100;
        protected override void OnCreate()
        {
            base.OnCreate();

            Window window = GetDefaultWindow();
            window.BackgroundColor = Color.White;
            window.KeyEvent += OnKeyEvent;

            // Controls
            Size2D winsize = window.Size;

            PropertyMap titleStyle = new PropertyMap();
            titleStyle.Add("weight", new PropertyValue(600));


#if false
            var buttonRemove = new Button
            {
                BackgroundColor = Color.Transparent,
                TextColor = Color.Black,
                Position = new Position(0f, 0f),
                Size = new Size(100f, 50f),
                Text = "<",
                PointSize = 30
            };
            buttonRemove.Clicked += ButtonRemove_Clicked;
            window.Add(buttonRemove);
#endif

            var title = new TextLabel("Setting")
            {
                Position2D = new Position2D(0, 0),
                Size2D = new Size2D(winsize.Width, TitleHight.ToPixel()),
                //                BackgroundColor = Color.Red,

                VerticalAlignment = VerticalAlignment.Center,
                TextColor = Color.Black,
                PointSize = 50f.DpToPoint(),
                FontStyle = titleStyle,
                Padding = new Extents((ushort)40.ToPixel(), (ushort)40.ToPixel(), (ushort)10.ToPixel(), (ushort)10.ToPixel())
            };
            window.Add(title);

            // Create mainView
            mainView = new MainView(window)
            {
                Position2D = new Position2D(0, TitleHight.ToPixel()),
                Size2D = new Size2D(winsize.Width, winsize.Height - TitleHight.ToPixel()),
                BackgroundColor = new Color(0.8f, 0.8f, 0.8f, 1.0f)
            };
            window.Add(mainView);


            //Add new Settingpage
            SPageMain settingpage = new SPageMain(mainView, 0, DirectoryInfo.Resource);
            mainView.Add(settingpage);
        }


    public void OnKeyEvent(object sender, Window.KeyEventArgs e)
        {
            if (e.Key.State == Key.StateType.Down && (e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "Escape"))
            {
                if (mainView.ChildCount >= 2)
                    mainView.RemoveLastAdded();
                else
                    Exit();
            }
        }
        override protected void OnPause()
        {
            base.OnPause();
        }

        override protected void OnResume()
        {
            base.OnResume();
        }

        override protected void OnTerminate()
        {
            base.OnTerminate();
        }

        override protected void OnAppControlReceived(AppControlReceivedEventArgs e)
        {
            base.OnAppControlReceived(e);
        }
    }
}
