﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class MainView : ScalableUI.OrientationalView
    {
        readonly Window baseWindow;

        public MainView(Window win)
            : base()
        {
            baseWindow = win;
            int winWidth = baseWindow.WindowSize.Width;
            int winHeight = baseWindow.WindowSize.Height;
            if (winWidth > winHeight)
                LandscapeMode = ScalableUI.OrientationalView.Mode.Splitting;
            else
                LandscapeMode = ScalableUI.OrientationalView.Mode.Stacking;

            XPadding = new Extents(20, 20, 20, 20);
            SplittingSpacing = 20;
        }
        public void ToggleMode()
        {
            if (LandscapeMode == ScalableUI.OrientationalView.Mode.Stacking)
                LandscapeMode = ScalableUI.OrientationalView.Mode.Splitting;
            else
                LandscapeMode = ScalableUI.OrientationalView.Mode.Stacking;
        }
    }
}

