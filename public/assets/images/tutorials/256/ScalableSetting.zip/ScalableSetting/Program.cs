﻿using System;
using Tizen.NUI;

namespace ScalableSetting
{
    static class Program
    {

        public static readonly string ItemContentNameIcon = "ItemIcon";
        public static readonly string ItemContentNameTitle = "ItemTitle";
        public static readonly string ItemContentNameDescription = "ItemDescription";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Scene1 Instance = new Scene1();
            Instance.Run(args);
        }
    }
}
