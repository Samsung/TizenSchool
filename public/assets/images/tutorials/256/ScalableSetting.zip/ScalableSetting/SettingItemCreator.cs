﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableSetting
{
    public class SettingItemCreator
    {
        static public Button Create(ListItem item, string name, EventHandler<ClickedEventArgs> onClicked, string resDirectory, View parentView)
        {
            //Create item base view.
            Button itemView = new Button()
            {
                BackgroundColor = new Color(1.0f, 1.0f, 1.0f, 1.0f),
                Name = name
            };

            int itemtype = item.GetItemType();

            if (itemtype == 1) // case 1: IconLable
            {
                //Create item layout responsible for positioning in each item
                ILIconLabel itemLayout = new ILIconLabel(parentView.Size2D.Width - 40.ToPixel());
                itemView.Layout = itemLayout;

                //Crate item icon
                string iconpath = item.GetPath();
                if (iconpath.Length > 0)
                {
                    // TO-DO : Add to check icon path valid
                    ImageView icon = new ImageView(resDirectory + iconpath)
                    {
                        //                            BackgroundColor = Color.Magenta,
                        Name = Program.ItemContentNameIcon
                    };
                    itemView.Add(icon);
                }

                PropertyMap titleStyle = new PropertyMap();
                titleStyle.Add("weight", new PropertyValue(600));

                //Create item title
                TextLabel title = new TextLabel(item.GetLabel())
                {
                    //                        BackgroundColor = Color.Blue,
                    FontStyle = titleStyle,
                    Name = Program.ItemContentNameTitle,
                    VerticalAlignment = VerticalAlignment.Center,
                    PointSize = 30f.DpToPoint()
                };
                itemView.Add(title);

                string strDescription = item.GetDescription();
                if (strDescription != null)
                {
                    TextLabel description = new TextLabel(strDescription)
                    {
                        //                            BackgroundColor = Color.Green,
                        Name = Program.ItemContentNameDescription,
                        VerticalAlignment = VerticalAlignment.Center,
                        PointSize = 24f.DpToPoint()
                    };
                    itemView.Add(description);
                }

                itemView.Clicked += onClicked;
            }
            else if (itemtype == 2)
            {
                //Create item layout responsible for positioning in each item
                ILCheckLabel itemLayout = new ILCheckLabel(parentView.Size2D.Width - 40.ToPixel());
                itemView.Layout = itemLayout;

                //Crate item icon
                CheckBox check = new CheckBox()
                {
                    Name = Program.ItemContentNameIcon
                };
                itemView.Add(check);

                PropertyMap titleStyle = new PropertyMap();
                titleStyle.Add("weight", new PropertyValue(600));

                //Create item title
                TextLabel title = new TextLabel(item.GetLabel())
                {
                    Name = Program.ItemContentNameTitle,
                    FontStyle = titleStyle,
                    PointSize = 30f.DpToPoint()
                };
                itemView.Add(title);

                string strDescription = item.GetDescription();
                if (strDescription != null)
                {
                    TextLabel description = new TextLabel(strDescription)
                    {
                        Name = Program.ItemContentNameDescription,
                        PointSize = 24f.DpToPoint()

                    };
                    itemView.Add(description);
                }

                itemView.Clicked += onClicked;
            }
            else if (itemtype == 3)
            {
                //Create item layout responsible for positioning in each item
                ILLabelSlider itemLayout = new ILLabelSlider(parentView.Size2D.Width - 40.ToPixel());
                itemView.Layout = itemLayout;

                PropertyMap titleStyle = new PropertyMap();
                titleStyle.Add("weight", new PropertyValue(600));

                //Create item title
                TextLabel title = new TextLabel(item.GetLabel())
                {
                    Name = Program.ItemContentNameTitle,
                    FontStyle = titleStyle,
                    PointSize = 30f.DpToPoint()

                };
                itemView.Add(title);

                Slider slider = new Slider()
                {
                    Name = Program.ItemContentNameDescription,

                    TrackThickness = 2,
                    BgTrackColor = new Color(0, 0, 0, 0.1f),
                    SlidedTrackColor = new Color(0.05f, 0.63f, 0.9f, 1),
                    ThumbSize = new Size(30, 30),

                    Direction = Slider.DirectionType.Horizontal,
                    MinValue = 0,
                    MaxValue = 100,
                    CurrentValue = 10
                };
                itemView.Add(slider);

                itemView.Clicked += onClicked;
            }

            return itemView;
        }
    }
}
