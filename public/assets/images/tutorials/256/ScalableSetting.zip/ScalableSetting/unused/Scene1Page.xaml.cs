﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableSetting
{
    public partial class Scene1Page : View
    {
        public Scene1Page()
        {
            InitializeComponent();
        }
    }
}
