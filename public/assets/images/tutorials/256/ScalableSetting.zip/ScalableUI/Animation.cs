﻿using System;
using System.Threading.Tasks;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableUI
{
    public class Animation
    {
        public static Task AnimateTo(View view, string property, object value)
        {
            var taskSource = new TaskCompletionSource<object>();
            var animation = new Tizen.NUI.Animation(20);

            void Finished(object sender, EventArgs e)
            {
                animation.Finished -= Finished;
                taskSource.SetResult(null);

                animation.Dispose();
                animation = null;
            }

            animation.DefaultAlphaFunction = new AlphaFunction(AlphaFunction.BuiltinFunctions.EaseInOut);
            animation.AnimateTo(view, property, value);
            animation.Finished += Finished;
            animation.Play();

            return taskSource.Task;
        }
    }
}
