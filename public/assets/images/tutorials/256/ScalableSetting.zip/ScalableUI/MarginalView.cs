﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableUI
{
    public class MarginalView : View
    {
        private static Size MinBreakpointSize { get; } = new Size(1024, 720);
        private static Size MaxBreakpointSize { get; } = new Size(4096, 2160);

        private static Size WindowSize => Window.Instance.WindowSize;

        private static bool IsLandscape => WindowSize.Width > WindowSize.Height;

        private static List<float> GetBreakpoints(float min, float max, float margin)
        {
            var breakpoints = new List<float>();
            float lastBreakpoint = min;

            while (lastBreakpoint < max)
            {
                breakpoints.Add(lastBreakpoint);
                lastBreakpoint = lastBreakpoint * (1 + margin);
            }

            return breakpoints;
        }

        private static Size GetSize(float margin)
        {
            float min = IsLandscape ? MinBreakpointSize.Width : MinBreakpointSize.Height;
            float max = IsLandscape ? MaxBreakpointSize.Width : MaxBreakpointSize.Height;
            var breakpoints = GetBreakpoints(min, max, margin);

            float limit = WindowSize.Width;
            float breakpoint = breakpoints.Where(x => x <= limit).Last();

            LogToDebug(breakpoints, limit, breakpoint, margin);

            // MarginalLayout controls only width margins, height always equals window size
            return new Size(breakpoint, WindowSize.Height);
        }

        private static void LogToDebug(IEnumerable<float> breakpoints, float limit, float breakpoint, float margin)
        {
            var breakpoints__ = breakpoints.Select(x => Convert.ToInt32(x).ToString());
            double effectiveMarginPixels = limit - breakpoint;
            double effectiveMarginPercent = Math.Round(effectiveMarginPixels / limit, 2);
            Tizen.Log.Debug(nameof(ScalableUI), $"Window size {WindowSize.Width} x {WindowSize.Height} px");
            Tizen.Log.Debug(nameof(ScalableUI), $"Horizontal breakpoints [{string.Join(",", breakpoints__)}] px, Selected {breakpoint} px is below {WindowSize.Width} px");
            Tizen.Log.Debug(nameof(ScalableUI), $"MaxMargin = {margin}, effective margin = {effectiveMarginPercent} ({effectiveMarginPixels} px)");
        }

        private float maxMargin;
        public float MaxMargin
        {
            get => maxMargin;
            set
            {
                maxMargin = value;

                Size = GetSize(maxMargin);

                PositionUsesPivotPoint = true;
                ParentOrigin = Tizen.NUI.ParentOrigin.Center;
                PivotPoint = Tizen.NUI.PivotPoint.Center;
            }
        }
    }
}
