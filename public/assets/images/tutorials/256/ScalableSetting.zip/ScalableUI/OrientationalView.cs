﻿using System.Threading.Tasks;
using System.Linq;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableUI
{
    public class OrientationalView : Tizen.NUI.BaseComponents.View
    {
        public enum Mode
        {
            Stacking,
            Splitting,
        };

        public Extents XPadding;

        public Mode LandscapeMode { get; set; } = Mode.Stacking;

        public int SplittingSpacing { get; set; } = 0;

        public OrientationalView()
        {
            //Size2D = Window.Instance.Size;
            //PositionUsesPivotPoint = true;
            //ParentOrigin = Tizen.NUI.ParentOrigin.Center;
            //PivotPoint = Tizen.NUI.PivotPoint.Center;
        }

        public override void Add(View child)
        {
            child.PositionUsesPivotPoint = false;
            child.Hide();
            base.Add(child);

            if (LandscapeMode == Mode.Stacking)
            {
                AddStacking(child);
            }
            else if (LandscapeMode == Mode.Splitting)
            {
                AddSplitting(child);
            }
        }

        public override async void Remove(View child)
        {
            if (LandscapeMode == Mode.Stacking)
            {
                await RemoveStacking(child);
            }
            else if (LandscapeMode == Mode.Splitting)
            {
                await RemoveSplitting(child);
            }

            base.Remove(child);
        }

        public void RemoveLastAdded()
        {
            if (Children.Any())
            {
                var last = Children.Last();
                Remove(last);
            }
        }

        private async void AddSplitting(View child)
        {
            if (Children.Count == 1)
            {
                int width = Size2D.Width - (XPadding.Start + XPadding.End);
                int height = Size2D.Height - (XPadding.Top + XPadding.Bottom);

                // show child behind right edge
                child.Size2D = new Size2D(width, height);
                child.Position2D = new Position2D(Size2D.Width, XPadding.Top);
                child.Show();

                // slide left onto the vieport
                await Animation.AnimateTo(child, "PositionX", (int)XPadding.Start);
            }
            else if (Children.Count == 2)
            {
                int width = (Size2D.Width - (XPadding.Start + XPadding.End + SplittingSpacing)) / 2;
                int height = Size2D.Height - (XPadding.Top + XPadding.Bottom);

                var prev = Children.Skip(Children.Count - 2).First();

                // reduce width
                await Animation.AnimateTo(prev, "SizeWidth", width);
                // FIX ME: animating SizeWidth does animate background, but not content => thus, required to reassign size
                prev.Size2D = new Size2D(width, height);

                // show child behind right edge
                child.Size2D = new Size2D(width, height);
                child.Position2D = new Position2D(Size2D.Width, XPadding.Top);
                child.Show();

                // slide left onto the viewport
                await Animation.AnimateTo(child, "PositionX", XPadding.Start + width + SplittingSpacing);
            }
            else
            {
                int width = (Size2D.Width - (XPadding.Start + XPadding.End + SplittingSpacing)) / 2;
                int height = Size2D.Height - (XPadding.Top + XPadding.Bottom);

                var first = Children.Skip(Children.Count - 3).First();
                var prev = Children.Skip(Children.Count - 2).First();

                // slide left out of the viewport
                await Animation.AnimateTo(first, "PositionX", -width);
                first.Hide();

                // slide left from right
                await Animation.AnimateTo(prev, "PositionX", (int)XPadding.Start);

                // show child behind right edge
                child.Size2D = new Size2D(width, height);
                child.Position2D = new Position2D(Size2D.Width, XPadding.Top);
                child.Show();

                // slide left onto the viewport
                await Animation.AnimateTo(child, "PositionX", XPadding.Start + width + SplittingSpacing);
            }
        }

        private async Task RemoveSplitting(View child)
        {
            if (Children.Count == 1)
            {
                // slide right out of the viewport
                await Animation.AnimateTo(child, "PositionX", Size2D.Width);
            }
            else if (Children.Count == 2)
            {
                int width = Size2D.Width - (XPadding.Start + XPadding.End);
                int height = Size2D.Height - (XPadding.Top + XPadding.Bottom);

                var first = Children.First();
                var last = Children.Last();

                // slide right out of the viewport
                await Animation.AnimateTo(last, "PositionX", Size2D.Width);

                // increase width
                await Animation.AnimateTo(first, "SizeWidth", width);
                // FIX ME: animating SizeWidth does animate background, but not content => thus, required to reassign size
                first.Size2D = new Size2D(width, height);
            }
            else
            {
                int width = (Size2D.Width - (XPadding.Start + XPadding.End + SplittingSpacing)) / 2;

                var first = Children.Skip(Children.Count - 3).First();
                var prev = Children.Skip(Children.Count - 2).First();
                var last = Children.Last();

                // slide right out of the viewport
                await Animation.AnimateTo(last, "PositionX", Size2D.Width);
                last.Hide();

                // slide from left to right
                await Animation.AnimateTo(prev, "PositionX", XPadding.Start + width + SplittingSpacing);

                // slide right onto the viewport
                first.Show();
                await Animation.AnimateTo(first, "PositionX", (int)XPadding.Start);
            }
        }

        private async void AddStacking(View child)
        {
            int width = Size2D.Width - (XPadding.Start + XPadding.End);
            int height = Size2D.Height - (XPadding.Top + XPadding.Bottom);

            if (ChildCount > 1)
            {
                var prev = Children.Skip(Children.Count - 2).First();

                // fade out current item
                await Animation.AnimateTo(prev, "Opacity", 0.0f);
                prev.Hide();
            }

            // show next item behind the screen
            child.Size2D = new Size2D(width, height);
            child.Position2D = new Position2D(Size2D.Width, XPadding.Top);
            child.Show();

            // animate next item to correct position
            await Animation.AnimateTo(child, "PositionX", (int)XPadding.Start);
        }

        private async Task RemoveStacking(View child)
        {
            var last = Children.Last();
            await Animation.AnimateTo(last, "PositionX", Size2D.Width);
            last.Hide();

            var prev = Children.Skip(Children.Count - 2).First();
            if (prev != null)
            {
                prev.Show();
                await Animation.AnimateTo(prev, "Opacity", 1.0f);
            }
        }
    }
}
