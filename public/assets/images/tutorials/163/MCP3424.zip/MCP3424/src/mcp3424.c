#include "mcp3424.h"

typedef struct mcp3424
{
	peripheral_i2c_h i2c;
	uint8_t SettingsRegister;
	int DataLength;
	uint8_t BusNumber;
} mcp3424;

static mcp3424 adc =
{
		.i2c = NULL,
		.SettingsRegister = 0x10,
		.DataLength = 0,
		.BusNumber = 0x1
};

int mcp3424_open(uint8_t address)
{
	return peripheral_i2c_open(adc.BusNumber, address, &adc.i2c);
}

static void mcp3424_write_settings_register()
{
	peripheral_i2c_write(adc.i2c, &adc.SettingsRegister, 1);
}

int mcp3424_open_with_settings(uint8_t address, gain gain, sample_rate sampleRate, channel channel)
{
	if (sampleRate == _18Bit)
    {
		adc.DataLength = 3;
    }
	else
	{
		adc.DataLength = 2;
	}

	// Calculating settings register value
	adc.SettingsRegister = adc.SettingsRegister | gain | sampleRate | channel;

	int err = mcp3424_open(address);
	if(err == 0)
	{
		mcp3424_write_settings_register();
	}

	return err;
}

int mcp3424_read_value()
{
	uint8_t *bytes = malloc(adc.DataLength * sizeof(uint8_t));
	memset(bytes, 0, adc.DataLength * sizeof(uint8_t));

	peripheral_i2c_read(adc.i2c, bytes, adc.DataLength);

    if (adc.DataLength == 2)
    {
        return (((int8_t)bytes[0]) << 8) | bytes[1];
    }
    else
    {
        return ((int8_t)bytes[0] << 16) | (bytes[1] << 8) | bytes[2];
    }
}

void mcp3424_change_channel(channel channel)
{
	// Calculating settings register value
    adc.SettingsRegister = adc.SettingsRegister | channel;

    mcp3424_write_settings_register();
}
