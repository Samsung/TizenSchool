#ifndef _MCP3424_H_
#define _MCP3424_H_

#include <tizen.h>
#include <peripheral_io.h>
#include <Ecore.h>

// Gain selection.
typedef enum
{
    _X1 = 0x0,
    _X2 = 0x1,
    _X4 = 0x2,
    _X8 = 0x3
} gain;

// Sample rate selection.
typedef enum
{
    _12Bit = 0x0,
    _14Bit = 0x4,
    _16Bit = 0x8,
    _18Bit = 0xC
} sample_rate;

// Channel selection.
typedef enum
{
    _CH1 = 0x0,
    _CH2 = 0x20,
    _CH3 = 0x40,
    _CH4 = 0x60
} channel;

int mcp3424_open(uint8_t address);
int mcp3424_open_with_settings(uint8_t address, gain gain, sample_rate sampleRate, channel channel);
int mcp3424_read_value();
void mcp3424_change_channel(channel channel);

#endif // _MCP3424_H_
